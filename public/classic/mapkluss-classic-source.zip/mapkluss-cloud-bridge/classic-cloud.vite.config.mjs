import { defineConfig } from 'vite';
export default defineConfig({ publicDir: false, build: { rollupOptions: {
  input: 'src/classicCloudBridge.ts', output: { entryFileNames: 'classic-cloud-api.js' }
} } });
