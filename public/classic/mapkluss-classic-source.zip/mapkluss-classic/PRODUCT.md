# MapKluss Classic

Audience: Minecraft map-art builders familiar with MapartCraft.
Intent: preserve the original page structure, controls and conversion workflow,
while using MapKluss fonts, dark surfaces, green actions and violet navigation.
This is a separate /classic/ application, not a Studio display mode.
Scope: existing MapartCraft palette, presets, NBT/map.dat export, materials and
online preview, with MapKluss color matching, dithering, 2D/3D Litematic and
Two-layer Companion bundles added in the existing settings/downloads area.
No brushes or new cloud integrations.
Success: original workflows verified on desktop and mobile, document overflow
only for deliberately enlarged previews,
working downloads, visible upstream credit and downloadable GPL source.
