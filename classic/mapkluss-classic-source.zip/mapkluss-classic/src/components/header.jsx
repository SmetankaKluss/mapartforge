// MapKluss modification, 2026-09-23: fork navigation; original generator unchanged.
import { Link } from 'react-router-dom';
import { useLayoutEffect, useState } from 'react';
import { applyClassicTheme, CLASSIC_THEMES, readClassicTheme } from '../classicThemes';
import './header.css';

export default function Header({ getLocaleString, countryCode }) {
  const [theme, setTheme] = useState(readClassicTheme);
  useLayoutEffect(() => applyClassicTheme(theme), [theme]);
  const languagePath = ![undefined, 'en'].includes(countryCode) ? `${countryCode}/` : '';
  return (
    <div className="header">
      <h3>
        <Link to={`/${languagePath}faq`}>{getLocaleString('FAQ/FAQ')}</Link>
        <a href="https://youtu.be/j-4RXPkJKU8" target="_blank" rel="noopener noreferrer">{getLocaleString('FAQ/VIDEO-TUTORIAL')}</a>
        <a href="https://github.com/rebane2001/mapartcraft" target="_blank" rel="noopener noreferrer">MapartCraft</a>
        <a href="/classic/mapkluss-classic-source.zip" download>{countryCode === 'ru' ? 'Исходный код' : 'Source code'}</a>
        <label className="classicThemeSelector">
          <span>{countryCode === 'ru' ? 'Тема' : 'Theme'}</span>
          <select value={theme} onChange={event => {
            applyClassicTheme(event.target.value, true);
            setTheme(event.target.value);
          }}>
            {CLASSIC_THEMES.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}
          </select>
        </label>
        <a className="studioLink" href="/">{countryCode === 'ru' ? 'Редактор MapKluss' : 'MapKluss editor'} ↗</a>
      </h3>
    </div>
  );
}
