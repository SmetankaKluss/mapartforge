export const MAX_MAP_SIDE = 16;
export const MAX_MAP_TILES = 64;
export const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
export const MAX_IMAGE_SIDE = 8192;
export const MAX_IMAGE_PIXELS = 16_777_216;

export function validMapGrid(wide, tall) {
  return Number.isInteger(wide) && Number.isInteger(tall)
    && wide >= 1 && tall >= 1
    && wide <= MAX_MAP_SIDE && tall <= MAX_MAP_SIDE
    && wide * tall <= MAX_MAP_TILES;
}
