// MapKluss modification, 2026-09-25. GPL-3.0-only.
const key = 'mapkluss-classic-dithering';
export function readDitherSettings() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(key)) || {}; } catch { /* unavailable storage */ }
  return {
    optionValue_dithering: Number.isInteger(saved.optionValue_dithering) && saved.optionValue_dithering >= 0 && saved.optionValue_dithering <= 13 ? saved.optionValue_dithering : 11,
    optionValue_bnScale: [1, 2].includes(saved.optionValue_bnScale) ? saved.optionValue_bnScale : 1,
    optionValue_ditheringIntensity: Number.isFinite(saved.optionValue_ditheringIntensity) ? Math.max(0, Math.min(100, saved.optionValue_ditheringIntensity)) : 100,
  };
}
export function saveDitherSettings(patch) {
  try { localStorage.setItem(key, JSON.stringify({ ...readDitherSettings(), ...patch })); } catch { /* unavailable storage */ }
}
