// MapKluss modification, 2026-09-23: independent route, metadata and presentation.
import React, { useEffect } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Switch, Route, useLocation } from "react-router-dom";

import FAQ from "./components/faq";
import Root from "./components/root";

import "./index.css";
import "./classic.css";

function LanguageMetadata() {
  const { pathname } = useLocation();
  useEffect(() => {
    const language = pathname.split('/').filter(Boolean)[0];
    document.documentElement.lang = language && language !== 'faq' ? language : 'en';
  }, [pathname]);
  return null;
}

ReactDOM.render(
  <React.StrictMode>
    <Router basename="/classic">
      <LanguageMetadata />
      <Switch>
        <Route path="/:countryCode?/faq" component={FAQ} />
        <Route path="/:countryCode?" component={Root} />
      </Switch>
    </Router>
  </React.StrictMode>,
  document.getElementById("root")
);
