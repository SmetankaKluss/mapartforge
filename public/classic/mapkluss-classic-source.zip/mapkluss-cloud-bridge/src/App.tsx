import React, { useState, useCallback, useRef, useMemo, useEffect, useLayoutEffect } from 'react';
import { type SelectionMask, selectAllMask, invertMask, countSelected } from './lib/selectionMask';
import type { MagicWandMatchMode } from './lib/selectionMask';
import { VERSION } from './version';
import { ImageUpload } from './components/ImageUpload';
import type { ImageUploadHandle } from './components/ImageUpload';
import { PreviewCanvas } from './components/PreviewCanvas';
import type { PaintTool, PaintBlock, TextLayerMeta } from './components/previewCanvasShared';
import { BlockPickerPopup } from './components/BlockPickerPopup';
import { SPRITE_URL } from './components/BlockCanvas';
import { CompareView } from './components/CompareView';
import { MaterialsList } from './components/MaterialsList';
import { Controls } from './components/Controls';
import { Adjustments } from './components/Adjustments';
import { PaletteEditor } from './components/PaletteEditor';
import { ExportPanel } from './components/ExportPanel';
import type { DitheringMode, KlussParams } from './lib/dithering';
import { buildComputedPalette, DEFAULT_KLUSS_PARAMS } from './lib/dithering';
import type { ComputedPalette } from './lib/dithering';
import { gridPixelWidth, gridPixelHeight, gridScale } from './lib/types';
import type { MapGrid } from './lib/types';
import { buildPaletteFromSelection, COLOUR_ROWS, DEFAULT_SELECTION } from './lib/paletteBlocks';
import type { BlockSelection } from './lib/paletteBlocks';
import { MINECRAFT_VERSIONS, getVersionLabel, type MinecraftVersion } from './lib/versionPresets';
import { sanitizeSelectionForPlatform } from './lib/platformMode';
import type { PlatformMode } from './lib/platformMode';
import {
  SUPPRESSION_TARGET_VERSIONS,
  coerceBuildTechniqueForPlatform,
  editorBuildMode,
  isPlatformLockedForBuildTechnique,
  normalizeRestoredBuildState,
  resolveEditorBuildMode,
  type BuildTechnique,
  type EditorBuildMode,
} from './lib/buildTechnique';
import {
  isSuppressionSafeBlockName,
  sanitizeSelectionForSuppression,
  sanitizeSuppressionSupportBlock,
} from './lib/suppressionPalette';
import { DEFAULT_ADJUSTMENTS, normalizeAdjustments } from './lib/adjustments';
import type { ImageAdjustments } from './lib/adjustments';
import { DEFAULT_COLOR_MATCH, coerceColorMatchMode } from './lib/colorMatch';
import type { ColorMatchMode } from './lib/colorMatch';
import { saveSettings, loadSettings, clearSettings } from './lib/localStorage';
import type { SavedSettings } from './lib/localStorage';
import { loadShare } from './lib/share';
import { decodePalette, PALETTE_PARAM } from './lib/paletteShare';
import { getExampleById } from './lib/examples';
import { downloadPng } from './lib/exportPng';
import { exportLitematicHybrid } from './lib/exportLitematic';
import { downloadExportBlob } from './lib/exportDownload';
import { NumInput } from './components/NumInput';
import { CropModal } from './components/CropModal';
import { lazy, Suspense } from 'react';
const PerspectiveModal = lazy(() => import('./components/PerspectiveModal').then(m => ({ default: m.PerspectiveModal })));
const GifModal = lazy(() => import('./components/GifModal').then(m => ({ default: m.GifModal })));
import { NewCanvasModal } from './components/NewCanvasModal';
import { LayersPanel } from './components/LayersPanel';
import type { Layer, LayerGroup } from './lib/layers';
import { createLayer, compositeLayersToImageData, mergeLayersDown, mergeVisible, scaleImageData } from './lib/layers';
import { renderTextLayer } from './lib/textRender';
import { deserializeProject, downloadProject, serializeFullProject, deserializeFullProject, imageDataToBase64, base64ToImageData } from './lib/projectFile';
import type { FullProjectSettings } from './lib/projectFile';
import { saveProject, loadProject } from './lib/projectStorage';
import { estimateAutosaveSnapshotBytes, useEditorAutosave } from './lib/editorAutosave';
import { SaveProjectModal } from './components/SaveProjectModal';
import { ProjectsPanel } from './components/ProjectsPanel';
import { CloudArtsPanel } from './components/CloudArtsPanel';
import { CloudSaveModal } from './components/CloudSaveModal';
import { ContinueInMinecraftPrompt, type MinecraftContinuationSource } from './components/ContinueInMinecraftPrompt';
import { createTour, markTourOfferDismissed, shouldAutoStart } from './lib/tour';
import type { TourType } from './lib/tour';
import { TourSelector } from './components/TourSelector';
import { useLocale } from './lib/useLocale';
import type { PatternDefinition } from './lib/patternTool';
import { createDefaultPattern, parsePatternDefinition } from './lib/patternTool';
import type { GradientStop } from './lib/gradientTool';
import { PatternEditorPopup } from './components/PatternEditorPopup';
import { importMapDat, MapDatImportError } from './lib/importMapDat';
import { GifFilmstrip } from './components/GifFilmstrip';
import { decodeGif } from './lib/gifDecoder';
import type { GifFrames } from './lib/gifDecoder';
import type { GifProject, GifFrameConfig } from './lib/gifProject';
import { makeThumbnail, imageDataToHtmlImage } from './lib/gifProject';
import { BuildTrackerModal } from './components/BuildTrackerModal';
import type { SessionMaterial } from './lib/buildSession';
import { computeSessionMaterials } from './lib/sessionMaterials';
import { IconGlyph } from './components/IconGlyph';
import { mkIcons } from './components/mkIcons';
import { LensController } from './components/LensController';
import { ThemeSelector } from './components/ThemeSelector';
import { UpdateBannerTicker } from './components/UpdateBannerTicker';
import { buildFinalPreview } from './lib/finalPreview';
import type { PreviewMode } from './lib/preview3d';
import { applyPageMeta, defaultSocialImageUrl } from './lib/meta';
import { attachCompanionImportToArt, downloadCompanionArtVersionProjectJson, downloadCompanionProjectJson, getCompanionScanImport, getCurrentCompanionAuthUser, getCurrentCompanionSessionUser, saveCompanionArt, setCompanionFavorite } from './lib/companionCloud';
import type { ArtPrivacy } from './lib/companionTypes';
import 'driver.js/dist/driver.css';
import './App.css';
import { trackEvent } from './lib/analytics';
import { SUPPORT_URL } from './lib/supportPrompt';
import {
  MAX_CANVAS_ZOOM,
  MIN_CANVAS_ZOOM,
  canStartCanvasPan,
  canvasZoomFromWheel,
  canvasZoomToSlider,
  clampCanvasZoom,
  hasCanvasPanStarted,
  sliderToCanvasZoom,
} from './lib/canvasViewport';
import { detachEditorUrlFromCloudSource } from './lib/editorCloudSession';

const ANNOUNCEMENT = {
  id: 'mapkluss-editor-1-35-0-classic-cloud',
  url: '/classic/',
};

const SHOW_PATTERN_BLOCKS = false;

function readStoredFlag(key: string): boolean {
  try {
    return localStorage.getItem(key) === '1';
  } catch {
    return false;
  }
}

function writeStoredFlag(key: string, value: boolean): void {
  try {
    localStorage.setItem(key, value ? '1' : '0');
  } catch {
    // The editor remains fully usable when storage is blocked or unavailable.
  }
}

function isInteractiveKeyboardTarget(target: EventTarget | null): boolean {
  return target instanceof Element
    && Boolean(target.closest('input, textarea, select, button, a, [contenteditable="true"], [role="button"]'));
}

// Support blocks for 3D staircase (nbt name → sprite coords + label)
const SUPPORT_BLOCKS_PALETTE = [
  { nbt: 'stone',        csId: 9,  blockId: 4,  ru: 'Камень',       en: 'Stone' },
  { nbt: 'cobblestone',  csId: 9,  blockId: 0,  ru: 'Булыжник',    en: 'Cobble' },
  { nbt: 'deepslate',    csId: 58, blockId: 0,  ru: 'Глубинный',   en: 'Deepslate' },
  { nbt: 'smooth_stone', csId: 9,  blockId: 18, ru: 'Гладкий',     en: 'Smooth' },
  { nbt: 'granite',      csId: 8,  blockId: 7,  ru: 'Гранит',      en: 'Granite' },
  { nbt: 'diorite',      csId: 12, blockId: 1,  ru: 'Диорит',      en: 'Diorite' },
  { nbt: 'andesite',     csId: 9,  blockId: 9,  ru: 'Андезит',     en: 'Andesite' },
  { nbt: 'dirt',         csId: 8,  blockId: 3,  ru: 'Земля',       en: 'Dirt' },
  { nbt: 'oak_planks',   csId: 11, blockId: 1,  ru: 'Дуб',         en: 'Oak' },
  { nbt: 'netherrack',   csId: 34, blockId: 0,  ru: 'Незерак',     en: 'Netherrack' },
  { nbt: 'blackstone',   csId: 28, blockId: 9,  ru: 'Чернит',      en: 'Blackstone' },
] as const;

const getSupportModeTitles = (t: (ru: string, en: string) => string): Record<1 | 2 | 3, string> => ({
  1: t('1 блок только под плавающими блоками (песок, гравий, лишайник…)', '1 block under floating blocks (sand, gravel, moss…)'),
  2: t('Зависит от оттенка: переходные оттенки получают 2, плоские — 1', 'Depends on shade: gradients get 2, flat get 1'),
  3: t('2 блока под каждым блоком арта', '2 blocks under each art block'),
});

const SUPPORT_MODE_LABELS: Record<1 | 2, string> = {
  1: 'Crit.',
  2: 'Opt.',
};

const MAX_HISTORY = 20;

interface HistoryEntry {
  layerState: LayerState;
  blockSelection: BlockSelection;
  mapMode: '2d' | '3d';
  minecraftVersion: MinecraftVersion;
}

interface LayerState {
  layers: Layer[];
  activeLayerId: string;
  groups: LayerGroup[];
}

function snapshotLayerState(state: LayerState): LayerState {
  return {
    layers: state.layers.map(layer => ({ ...layer })),
    activeLayerId: state.activeLayerId,
    groups: state.groups.map(group => ({ ...group })),
  };
}

interface AppNotice {
  message: string;
  tone: 'info' | 'error';
}

function makeInitialLayerState(): LayerState {
  const l = createLayer('Слой 1');
  return { layers: [l], activeLayerId: l.id, groups: [] };
}

const DITHERING_LABELS: Record<DitheringMode, string> = {
  'none':            'None',
  'floyd-steinberg': 'Floyd–Steinberg',
  'stucki':          'Stucki',
  'jjn':             'JJN',
  'atkinson':        'Atkinson',
  'blue-noise':      'Blue Noise',
  'yliluoma2':       'Yliluoma #2',
  'kluss':           'KlussDither',
};
const ALL_MODES: DitheringMode[] = ['none', 'floyd-steinberg', 'stucki', 'jjn', 'atkinson', 'blue-noise', 'yliluoma2', 'kluss'];

function coerceDitheringMode(mode: unknown): DitheringMode {
  return ALL_MODES.includes(mode as DitheringMode) ? mode as DitheringMode : 'blue-noise';
}

/** Returns true if the layer ref's imageData has at least one non-transparent pixel. */
function activeLayerHasContent(ref: React.MutableRefObject<{ imageData: ImageData | null } | undefined>): boolean {
  const img = ref.current?.imageData;
  if (!img) return false;
  for (let i = 3; i < img.data.length; i += 4) {
    if (img.data[i] > 0) return true;
  }
  return false;
}

// Predefined brush sizes — all odd → half-integer radius → perfect circles, no protrusions
const BRUSH_SIZES = [1, 3, 5, 7, 9, 11, 13, 17, 21, 25, 31, 37, 43];

/** Convert ImageData to an HTMLImageElement for processing. Used to restore source from saved originalData. */
function imageDataToSourceImage(data: ImageData): Promise<HTMLImageElement> {
  return new Promise(resolve => {
    const canvas = document.createElement('canvas');
    canvas.width = data.width;
    canvas.height = data.height;
    const ctx = canvas.getContext('2d')!;
    ctx.putImageData(data, 0, 0);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(img); // fallback: resolve even if load fails
    img.src = canvas.toDataURL('image/png');
  });
}

async function loadHtmlImage(url: string): Promise<HTMLImageElement> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to load image: ${url} (${response.status})`);
  }
  const blob = await response.blob();
  const objectUrl = URL.createObjectURL(blob);
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error(`Failed to decode image: ${url}`));
    };
    img.src = objectUrl;
  });
}

function imageToImageData(img: HTMLImageElement): ImageData {
  const width = img.naturalWidth || img.width;
  const height = img.naturalHeight || img.height;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not create canvas context for image import.');
  ctx.drawImage(img, 0, 0, width, height);
  return ctx.getImageData(0, 0, width, height);
}

export default function App() {
  const { lang, toggle: toggleLang, t } = useLocale();

  useEffect(() => {
    applyPageMeta({
      title: t(
        'Генератор Minecraft map art, Litematic и MAP.DAT | MapKluss',
        'Minecraft Map Art Generator, Litematic & MAP.DAT Export | MapKluss',
      ),
      description: t(
        'MapKluss — браузерный генератор Minecraft map art. Загружай изображения, настраивай палитру и дизеринг, проверяй 2D/3D preview и экспортируй Litematic, MAP.DAT и материалы.',
        'MapKluss is a browser-based Minecraft map art generator. Upload images, tune palette and dithering, preview 2D or 3D stair results, and export Litematic, MAP.DAT, and materials.',
      ),
      url: window.location.origin,
      image: defaultSocialImageUrl(window.location.origin),
      schema: [
        {
          '@context': 'https://schema.org',
          '@type': 'WebSite',
          name: 'MapKluss',
          url: window.location.origin,
        },
        {
          '@context': 'https://schema.org',
          '@type': 'SoftwareApplication',
          name: 'MapKluss',
          applicationCategory: 'MultimediaApplication',
          operatingSystem: 'Web',
          url: window.location.origin,
          image: defaultSocialImageUrl(window.location.origin),
          description: t(
            'Браузерный генератор Minecraft map art с экспортом Litematic, MAP.DAT и списком материалов.',
            'Browser-based Minecraft map art generator with Litematic, MAP.DAT, and materials export.',
          ),
          offers: {
            '@type': 'Offer',
            price: '0',
            priceCurrency: 'USD',
          },
        },
      ],
    });
  }, [lang, t]);

  // ── Restore persisted settings — lazy init runs exactly once on mount ─
  const [saved] = useState<Partial<SavedSettings>>(() => loadSettings());
  const restoredSavedBuild = useMemo(() => normalizeRestoredBuildState({
    mapMode: saved.mapMode ?? '2d',
    buildTechnique: saved.buildTechnique,
    minecraftVersion: (saved.minecraftVersion as MinecraftVersion | undefined) ?? '26.2',
    platformMode: saved.platformMode ?? 'java',
    blockSelection: saved.blockSelection ?? DEFAULT_SELECTION,
  }), [saved]);

  const [sourceImage, setSourceImage]   = useState<HTMLImageElement | null>(null);
  const [originalData, setOriginalData] = useState<ImageData | null>(null);
  const imageUploadRef = useRef<ImageUploadHandle>(null);

  // ── Layer system ─────────────────────────────────────────────────────────────
  const [layerState, setLayerState] = useState<LayerState>(makeInitialLayerState);
  const layers = layerState.layers;
  const activeLayerId = layerState.activeLayerId;
  const activeLayer = layers.find(l => l.id === activeLayerId) ?? layers[0];
  const layerGroups = layerState.groups;
  // imageData = active layer's imageData (for painting tools + display in Phase 1)
  const imageData: ImageData | null = activeLayer?.imageData ?? null;
  // When set, runProcess result will target this layer instead of activeLayerId
  const processTargetLayerIdRef = useRef<string | null>(null);

  // setImageData wrapper — updates active layer without touching other layers
  // dirty=true    — layer painted by user (always allowed)
  // fromProcess=true — result from runProcess worker (blocked if target isDirty)
  function setImageData(data: ImageData | null, dirty = false, fromProcess = false) {
    // Capture and clear ref synchronously BEFORE setState (Strict Mode runs updaters twice)
    const capturedTargetId = processTargetLayerIdRef.current;
    processTargetLayerIdRef.current = null;
    setLayerState(prev => {
      const targetId = capturedTargetId ?? prev.activeLayerId;
      const targetLayer = prev.layers.find(l => l.id === targetId);
      // Never overwrite a manually-edited layer with a fresh auto-process result
      // (dirty=true path = dithering-change with alpha mask preservation — still allowed)
      if (targetLayer?.locked && (dirty || fromProcess)) return prev;
      if (fromProcess && !dirty && targetLayer?.isDirty) return prev;
      const rasterizeText = Boolean(dirty && targetLayer?.isText);
      return {
        ...prev,
        layers: prev.layers.map(l =>
          l.id === targetId
            ? { ...l, imageData: data, isDirty: dirty, isText: rasterizeText ? false : l.isText, text: rasterizeText ? undefined : l.text }
            : l,
        ),
      };
    });
  }

  // ── Artist mode toggle ────────────────────────────────────────────────────────
  const [editorMode, setEditorMode] = useState<'simple' | 'artist'>(
    () => (localStorage.getItem('mapartforge-editor-mode') as 'simple' | 'artist' | null) ?? 'simple',
  );
  // The compact workbench is the standard editor layout. Side panels may still
  // be resized independently without ever taking the canvas below its safe width.
  const workbenchMode = true;
  const [panelWidths, setPanelWidths] = useState(() => {
    try {
      const stored = JSON.parse(localStorage.getItem('mapkluss-editor-panel-widths') ?? '{}') as Partial<{ left: number; right: number }>;
      return {
        left: typeof stored.left === 'number' ? stored.left : 300,
        right: typeof stored.right === 'number' ? stored.right : 340,
      };
    } catch {
      return { left: 300, right: 340 };
    }
  });
  const panelResizeRef = useRef<{ side: 'left' | 'right'; startX: number; startWidth: number; otherWidth: number; pointerId: number } | null>(null);
  const [paletteFocus, setPaletteFocus] = useState<{ csId: number; blockId: number; token: number } | null>(null);
  const [splitPos, setSplitPos] = useState(50);
  // The comparison divider is useful on demand, but must never cover a fresh canvas.
  const [showSplitLine, setShowSplitLine] = useState(false);
  const [showGrid, setShowGrid]         = useState(false);
  const [zoom, setZoom]                 = useState(100);
  const VALID_VERSIONS = MINECRAFT_VERSIONS;
  const [minecraftVersion, setMinecraftVersion] = useState<MinecraftVersion>(
    VALID_VERSIONS.includes(restoredSavedBuild.minecraftVersion) ? restoredSavedBuild.minecraftVersion : '26.2'
  );
  const [platformMode, setPlatformMode] = useState<PlatformMode>(restoredSavedBuild.platformMode);
  const [compareMode, setCompareMode]   = useState(false);
  const [compareLeft,  setCompareLeft]  = useState<DitheringMode>('floyd-steinberg');
  const [compareRight, setCompareRight] = useState<DitheringMode>('yliluoma2');
  const [compareData, setCompareData]   = useState<{ left: ImageData; right: ImageData } | null>(null);
  const [mapMode, setMapMode]           = useState<'2d' | '3d'>(restoredSavedBuild.mapMode);
  const [buildTechnique, setBuildTechnique] = useState<BuildTechnique>(
    restoredSavedBuild.buildTechnique,
  );
  const standardBuildSnapshotRef = useRef<{
    minecraftVersion: MinecraftVersion;
    platformMode: PlatformMode;
    blockSelection: BlockSelection;
    supportBlock: string;
  } | null>(null);
  const [staircaseMode, setStaircaseMode] = useState<'classic' | 'optimized'>(saved.staircaseMode ?? 'optimized');
  const [textureMode, setTextureMode]   = useState<'pixel' | 'block'>('pixel');
  const [dithering, setDithering]       = useState<DitheringMode>(coerceDitheringMode(saved.dithering));
  const [intensity, setIntensity]       = useState(saved.intensity ?? 100);
  const [bnScale, setBnScale]           = useState(saved.bnScale ?? (saved.dithering ? 2 : 1));
  const [klussParams, setKlussParams]   = useState<KlussParams>(saved.klussParams ?? DEFAULT_KLUSS_PARAMS);
  const [mapGrid, setMapGrid]           = useState<MapGrid>(saved.mapGrid ?? { wide: 1, tall: 1 });
  const [processing, setProcessing]     = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [showShadeWarnings, setShowShadeWarnings] = useState(false);
  const [blockSelection, setBlockSelection] = useState<BlockSelection>(restoredSavedBuild.blockSelection);
  const [adjustments, setAdjustments]   = useState<ImageAdjustments>(normalizeAdjustments(saved.adjustments));
  const [colorMatch, setColorMatch]     = useState<ColorMatchMode>(coerceColorMatchMode(saved.colorMatch ?? DEFAULT_COLOR_MATCH));
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showTourSelector, setShowTourSelector] = useState(false);
  const [tourSelectorIsWelcome, setTourSelectorIsWelcome] = useState(false);
  const [suppressAutoTour] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return Boolean(
      params.get('cloudFolder') ||
      params.get('companionImport') ||
      params.get('artVersion') ||
      params.get('art'),
    );
  });
  const [showPerspective, setShowPerspective] = useState(false);
  const [previewMode, setPreviewMode] = useState<PreviewMode>('schematic3d');
  const [gifFrames, setGifFrames] = useState<GifFrames | null>(null);
  const [gifProject, setGifProject] = useState<GifProject | null>(null);
  const [trackerMaterials, setTrackerMaterials] = useState<SessionMaterial[] | null>(null);
  const [showProjectsPanel, setShowProjectsPanel] = useState(false);
  const [showCloudArtsPanel, setShowCloudArtsPanel] = useState(false);
  const [showCloudSaveModal, setShowCloudSaveModal] = useState(false);
  const [saveThumbnail, setSaveThumbnail] = useState<string | null>(null);
  const [showAdjustments, setShowAdjustments] = useState(true);
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const [activeTool, setActiveTool]     = useState<PaintTool | null>(null);
  const [paintBlock, setPaintBlock]     = useState<PaintBlock | null>(null);
  const [selectionMask, setSelectionMask] = useState<SelectionMask | null>(null);
  const [magicWandTolerance, setMagicWandTolerance] = useState<number>(0.04);
  const [magicWandContiguous, setMagicWandContiguous] = useState(true);
  const [magicWandMode, setMagicWandMode] = useState<MagicWandMatchMode>('similar');
  const [patternBlocks, setPatternBlocks] = useState<PaintBlock[]>([]);
  const [showPatternPicker, setShowPatternPicker] = useState<number | null>(null); // index of open picker
  const [brushSize, setBrushSize]       = useState<number>(1);

  // Pattern-tile tool state
  const [savedPatterns, setSavedPatterns] = useState<PatternDefinition[]>(() => [createDefaultPattern()]);
  const [activePatternId, setActivePatternId] = useState<string>(() => savedPatterns[0]?.id ?? '');
  const [showPatternEditor, setShowPatternEditor] = useState(false);
  const [patternAnchorMode, setPatternAnchorMode] = useState<'canvas' | 'brush'>('canvas');
  const activePattern = savedPatterns.find(p => p.id === activePatternId) ?? savedPatterns[0] ?? null;
  void setActivePatternId; // reserved for future multi-pattern selection UI

  function exportPattern(p: PatternDefinition) {
    const json = JSON.stringify(p, null, 2);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
    a.download = `${p.name.replace(/[^a-zа-я0-9_-]/gi, '_')}.json`;
    a.click();
  }

  function importPattern(file: File) {
    file.text().then(text => {
      try {
        const p = parsePatternDefinition(JSON.parse(text));
        if (!p) throw new Error('invalid pattern');
        const imported = { ...p, id: crypto.randomUUID() };
        setSavedPatterns(prev => [...prev, imported]);
        setActivePatternId(imported.id);
        showAppNotice(t('Паттерн импортирован.', 'Pattern imported.'));
      } catch {
        showAppNotice(t('Не удалось импортировать паттерн: проверь JSON и размер до 16×16.', 'Could not import pattern: check the JSON and the 16×16 size limit.'), 'error');
      }
    });
  }

  // Gradient tool state
  const [gradientStops, setGradientStops] = useState<GradientStop[]>([]);
  const [gradientDithering, setGradientDithering] = useState<'none' | 'ordered'>('ordered');
  const [showGradientStopPicker, setShowGradientStopPicker] = useState<number | null>(null);
  const [showGradientAddPicker, setShowGradientAddPicker] = useState(false);
  const [showBlockPicker, setShowBlockPicker]   = useState(false);
  const [viewBanner,    setViewBanner]    = useState(false);
  const [paletteBanner, setPaletteBanner] = useState(false);
  const [appNotice, setAppNotice] = useState<AppNotice | null>(null);
  const [showAnnouncement, setShowAnnouncement] = useState(() => {
    const force = new URLSearchParams(window.location.search).get('announcement') === '1';
    return force || localStorage.getItem('mapkluss_seen_announcement') !== ANNOUNCEMENT.id;
  });
  const [supportBlock,  setSupportBlock]  = useState('stone');
  const [supportMode,   setSupportMode]   = useState<1 | 2 | 3>(2);
  const [resetDefaultsPending, setResetDefaultsPending] = useState(false);
  const resetDefaultsTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [showCropModal, setShowCropModal] = useState(false);
  const [showNewCanvasModal, setShowNewCanvasModal] = useState(false);
  const [sourceHasAlpha, setSourceHasAlpha] = useState(false);
  const [bgMode, setBgMode] = useState<'color' | 'transparent'>('color');
  const [bgColor, setBgColor] = useState('#ffffff');

  const moveGradientStop = useCallback((originalIndex: number, direction: -1 | 1) => {
    setGradientStops(previous => {
      const order = previous.map((stop, index) => ({ stop, index })).sort((a, b) => a.stop.t - b.stop.t);
      const position = order.findIndex(item => item.index === originalIndex);
      const targetPosition = position + direction;
      if (position < 0 || targetPosition < 0 || targetPosition >= order.length) return previous;
      const targetIndex = order[targetPosition].index;
      const next = previous.map(stop => ({ ...stop }));
      const currentT = next[originalIndex].t;
      next[originalIndex].t = next[targetIndex].t;
      next[targetIndex].t = currentT;
      return next;
    });
  }, [setGradientStops]);
  const bgModeRef  = useRef<'color' | 'transparent'>('color');
  const bgColorRef = useRef('#ffffff');
  bgModeRef.current  = bgMode;
  bgColorRef.current = bgColor;
  // Always holds the originally-uploaded image so crop modal can re-crop from source
  const uploadedImageRef = useRef<HTMLImageElement | null>(null);
  // Raw file for color-accurate bitmap creation (bypasses ICC profile correction)
  const uploadedFileRef  = useRef<File | null>(null);
  const workerRef     = useRef<Worker | null>(null);
  const workerJobSeqRef = useRef(0);
  const activeWorkerJobIdRef = useRef<number | null>(null);
  const cancelTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // When re-processing a manually-edited layer, store the alpha mask here so it can
  // be re-applied after the worker returns (preserves deletions/transparency edits).
  const pendingAlphaMaskRef = useRef<Uint8Array | null>(null);
  const [showCancel, setShowCancel] = useState(false);
  const [cloudUserEmail, setCloudUserEmail] = useState<string | null>(null);
  const [cloudSaving, setCloudSaving] = useState(false);
  const [cloudMenuOpen, setCloudMenuOpen] = useState(false);
  const cloudMenuButtonRef = useRef<HTMLButtonElement | null>(null);
  const [cloudMenuStyle, setCloudMenuStyle] = useState<React.CSSProperties>({});
  const [currentCloudArtId, setCurrentCloudArtId] = useState<string | null>(null);
  const [loadedCloudVersionId, setLoadedCloudVersionId] = useState<string | null>(null);
  const [currentCloudImportId, setCurrentCloudImportId] = useState<string | null>(null);
  const [currentCloudTitle, setCurrentCloudTitle] = useState<string>('');
  const [currentCloudPrivacy, setCurrentCloudPrivacy] = useState<ArtPrivacy>('unlisted');
  const [minecraftContinuation, setMinecraftContinuation] = useState<{
    source: MinecraftContinuationSource;
    minecraftVersion: MinecraftVersion;
  } | null>(null);
  const minecraftContinuationDismissedRef = useRef(false);

  const showAppNotice = useCallback((message: string, tone: AppNotice['tone'] = 'info') => {
    setAppNotice({ message, tone });
  }, [setAppNotice]);

  useEffect(() => {
    if (!appNotice) return;
    const timer = window.setTimeout(() => setAppNotice(null), appNotice.tone === 'error' ? 5200 : 3200);
    return () => window.clearTimeout(timer);
  }, [appNotice]);

  useEffect(() => {
    if (!import.meta.env.DEV) return;
    const source = new URLSearchParams(window.location.search).get('minecraftContinue');
    if (source === 'export' || source === 'cloud') {
      setMinecraftContinuation({ source, minecraftVersion });
    }
  }, [minecraftVersion]);

  const refreshCloudUser = useCallback(async () => {
    const user = await getCurrentCompanionAuthUser();
    setCloudUserEmail(user?.email ?? null);
  }, [setCloudUserEmail]);

  useEffect(() => {
    void refreshCloudUser();
  }, [refreshCloudUser]);

  useLayoutEffect(() => {
    if (!cloudMenuOpen) return;

    const positionMenu = () => {
      const button = cloudMenuButtonRef.current;
      if (!button) return;
      const rect = button.getBoundingClientRect();
      const margin = 8;
      const menuWidth = Math.min(336, Math.max(190, window.innerWidth - margin * 2));
      const left = Math.min(
        Math.max(margin, rect.right - menuWidth),
        Math.max(margin, window.innerWidth - menuWidth - margin),
      );
      const arrowX = Math.min(Math.max(rect.left + rect.width / 2 - left - 5, 12), menuWidth - 22);
      setCloudMenuStyle({
        top: Math.round(rect.bottom + 7),
        left: Math.round(left),
        width: menuWidth,
        ['--cloud-menu-arrow-x' as string]: `${Math.round(arrowX)}px`,
      });
    };

    positionMenu();
    window.addEventListener('resize', positionMenu);
    window.addEventListener('scroll', positionMenu, true);
    return () => {
      window.removeEventListener('resize', positionMenu);
      window.removeEventListener('scroll', positionMenu, true);
    };
  }, [cloudMenuOpen]);

  useEffect(() => {
    const nextUrl = new URL(window.location.href);
    if (nextUrl.searchParams.get('cloudFolder') !== '1') return;
    nextUrl.searchParams.delete('cloudFolder');
    window.history.replaceState(null, '', nextUrl.toString());
    setShowCloudArtsPanel(true);
  }, []);

  useEffect(() => {
    if (!import.meta.env.DEV) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('cloudSavePreview') !== '1') return;
    setShowCloudSaveModal(true);
  }, []);

  useEffect(() => {
    if (!import.meta.env.DEV) return;
    const params = new URLSearchParams(window.location.search);
    const previewMode = params.get('buildTrackerModalPreview');
    if (previewMode !== '1' && previewMode !== 'done') return;

    const data = new Uint8ClampedArray([
      128, 128, 128, 255,
      95, 140, 64, 255,
      212, 199, 165, 255,
      64, 64, 72, 255,
    ]);
    const image = new ImageData(data, 2, 2);
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map((layer, index) =>
        index === 0 ? { ...layer, imageData: image, isDirty: true } : layer,
      ),
    }));
    setMapGrid({ wide: 1, tall: 1 });
    setTrackerMaterials([
      { nbtName: 'minecraft:stone', displayName: 'Stone', count: 2 },
      { nbtName: 'minecraft:grass_block', displayName: 'Grass Block', count: 1 },
      { nbtName: 'minecraft:sand', displayName: 'Sand', count: 1 },
    ]);
  }, []);

  const previewSectionRef = useRef<HTMLElement>(null);
  const canvasAreaRef = useRef<HTMLDivElement>(null);
  const pendingZoomAnchorRef = useRef<{ clientX: number; clientY: number; xRatio: number; yRatio: number } | null>(null);
  const canvasPanRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    startScrollLeft: number;
    startScrollTop: number;
    moved: boolean;
    forcedBySpace: boolean;
  } | null>(null);
  const suppressCanvasClickRef = useRef(false);
  const suppressCanvasClickTimerRef = useRef<number | null>(null);
  const [undoStack, setUndoStack] = useState<HistoryEntry[]>([]);
  const [redoStack, setRedoStack] = useState<HistoryEntry[]>([]);
  const [mobileTab, setMobileTab] = useState<'settings' | 'palette' | 'export'>('settings');
  const [tabletRightOpen, setTabletRightOpen] = useState(false);
  const [leftPanelCollapsed, setLeftPanelCollapsed] = useState(
    () => readStoredFlag('mapkluss-left-panel-collapsed'),
  );
  const [rightPanelCollapsed, setRightPanelCollapsed] = useState(
    () => readStoredFlag('mapkluss-right-panel-collapsed'),
  );
  const [isCanvasPanning, setIsCanvasPanning] = useState(false);
  const [isSpacePanActive, setIsSpacePanActive] = useState(false);
  const spacePanRef = useRef(false);

  useEffect(() => {
    writeStoredFlag('mapkluss-left-panel-collapsed', leftPanelCollapsed);
  }, [leftPanelCollapsed]);

  useEffect(() => {
    writeStoredFlag('mapkluss-right-panel-collapsed', rightPanelCollapsed);
  }, [rightPanelCollapsed]);

  // Ref for originalData so handleMapGridChange can scale it without adding to deps
  const originalDataRef = useRef<ImageData | null>(null);
  originalDataRef.current = originalData;

  // Always-current ref — updated each render so callbacks never see stale state
  const latestRef = useRef<{
    imageData: ImageData | null;
    blockSelection: BlockSelection;
    layers: Layer[];
    activeLayerId: string;
    groups: LayerGroup[];
    mapMode: '2d' | '3d';
    staircaseMode: 'classic' | 'optimized';
    platformMode: PlatformMode;
    minecraftVersion: MinecraftVersion;
    buildTechnique: BuildTechnique;
  }>({
    imageData: null,
    blockSelection: sanitizeSelectionForPlatform(DEFAULT_SELECTION, platformMode),
    layers: layerState.layers,
    activeLayerId: layerState.activeLayerId,
    groups: layerState.groups,
    mapMode,
    staircaseMode,
    platformMode,
    minecraftVersion,
    buildTechnique,
  });
  latestRef.current = {
    imageData,
    blockSelection,
    layers,
    activeLayerId: layerState.activeLayerId,
    groups: layerState.groups,
    mapMode,
    staircaseMode,
    platformMode,
    minecraftVersion,
    buildTechnique,
  };

  const normalizeIncomingBuildState = useCallback((
    selection: BlockSelection,
    requestedMapMode: '2d' | '3d',
  ) => {
    const current = latestRef.current;
    return normalizeRestoredBuildState({
      mapMode: requestedMapMode,
      buildTechnique: current.buildTechnique,
      minecraftVersion: current.minecraftVersion,
      platformMode: current.platformMode,
      blockSelection: selection,
    });
  }, []);

  // Ref to active layer — used in callbacks to check if layer has real content
  const activeLayerRef = useRef<typeof activeLayer>(activeLayer);
  activeLayerRef.current = activeLayer;

  const ensureActiveLayerEditable = useCallback(() => {
    const current = latestRef.current;
    const layer = current.layers.find(item => item.id === current.activeLayerId);
    if (!layer?.locked) return true;
    showAppNotice(t('Слой заблокирован. Сними блокировку, чтобы редактировать его.', 'This layer is locked. Unlock it to edit.'), 'info');
    return false;
  }, [showAppNotice, t]);

  // Ref with all current state needed for export shortcuts (avoids stale closures)
  const exportRef = useRef({ imageData, dithering, mapGrid, activePalette: null as unknown as ReturnType<typeof buildComputedPalette>, blockSelection, mapMode, staircaseMode, layers: layerState.layers });


  // ── Auto-save settings to localStorage ──────────────────────────────────
  useEffect(() => { saveSettings({ dithering }); }, [dithering]);
  useEffect(() => { saveSettings({ intensity }); }, [intensity]);
  useEffect(() => { saveSettings({ mapGrid }); }, [mapGrid]);
  useEffect(() => { saveSettings({ blockSelection }); }, [blockSelection]);
  useEffect(() => { saveSettings({ adjustments }); }, [adjustments]);
  useEffect(() => { saveSettings({ colorMatch }); }, [colorMatch]);
  useEffect(() => { saveSettings({ mapMode }); }, [mapMode]);
  useEffect(() => { saveSettings({ staircaseMode }); }, [staircaseMode]);
  useEffect(() => { saveSettings({ bnScale }); }, [bnScale]);
  useEffect(() => { saveSettings({ klussParams }); }, [klussParams]);
  useEffect(() => { saveSettings({ minecraftVersion }); }, [minecraftVersion]);
  useEffect(() => { saveSettings({ platformMode }); }, [platformMode]);
  useEffect(() => { saveSettings({ buildTechnique }); }, [buildTechnique]);
  useEffect(() => {
    setBlockSelection(prev => sanitizeSelectionForPlatform(prev, platformMode));
    setBuildTechnique(previous => coerceBuildTechniqueForPlatform(previous, platformMode));
  }, [platformMode]);
  useEffect(() => { localStorage.setItem('mapartforge-editor-mode', editorMode); }, [editorMode]);
  useEffect(() => { localStorage.setItem('mapkluss-editor-panel-widths', JSON.stringify(panelWidths)); }, [panelWidths]);
  useEffect(() => {
    const keepCanvasReachable = () => {
      if (window.innerWidth < 1100) return;
      setPanelWidths(current => {
        const minimumCanvas = 440;
        const resizers = 16;
        const availablePanels = window.innerWidth - minimumCanvas - resizers;
        const leftMaximum = Math.max(280, Math.min(520, availablePanels - 300));
        const left = Math.max(280, Math.min(leftMaximum, current.left));
        const rightMaximum = Math.max(300, Math.min(560, availablePanels - left));
        const right = Math.max(300, Math.min(rightMaximum, current.right));
        return left === current.left && right === current.right ? current : { left, right };
      });
    };
    window.addEventListener('resize', keepCanvasReachable);
    keepCanvasReachable();
    return () => window.removeEventListener('resize', keepCanvasReachable);
  }, []);
  const updatePanelWidth = useCallback((side: 'left' | 'right', requestedWidth: number, otherWidth: number) => {
    const minimum = side === 'left' ? 280 : 300;
    const maximum = side === 'left' ? 520 : 560;
    const minimumCanvas = 440;
    const resizers = 16;
    const canvasSafeMaximum = window.innerWidth - otherWidth - minimumCanvas - resizers;
    return Math.max(minimum, Math.min(maximum, canvasSafeMaximum, requestedWidth));
  }, []);
  const handlePanelResizeStart = useCallback((side: 'left' | 'right', event: React.PointerEvent<HTMLDivElement>) => {
    if (window.innerWidth < 1100) return;
    const currentWidth = side === 'left' ? panelWidths.left : panelWidths.right;
    const otherWidth = side === 'left' ? panelWidths.right : panelWidths.left;
    panelResizeRef.current = { side, startX: event.clientX, startWidth: currentWidth, otherWidth, pointerId: event.pointerId };
    event.currentTarget.setPointerCapture(event.pointerId);
    document.body.classList.add('panel-resizing');
  }, [panelWidths]);
  const handlePanelResizeMove = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    const session = panelResizeRef.current;
    if (!session || session.pointerId !== event.pointerId) return;
    const delta = event.clientX - session.startX;
    const requestedWidth = session.side === 'left'
      ? session.startWidth + delta
      : session.startWidth - delta;
    const nextWidth = updatePanelWidth(session.side, requestedWidth, session.otherWidth);
    setPanelWidths(current => session.side === 'left'
      ? { ...current, left: nextWidth }
      : { ...current, right: nextWidth });
  }, [updatePanelWidth]);
  const handlePanelResizeEnd = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    if (panelResizeRef.current?.pointerId !== event.pointerId) return;
    panelResizeRef.current = null;
    document.body.classList.remove('panel-resizing');
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  }, []);
  const handlePanelResizeKeyDown = useCallback((side: 'left' | 'right', event: React.KeyboardEvent<HTMLDivElement>) => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const min = side === 'left' ? 280 : 300;
    const max = side === 'left' ? 520 : 560;
    const step = event.shiftKey ? 32 : 16;
    setPanelWidths(current => {
      const currentWidth = side === 'left' ? current.left : current.right;
      const otherWidth = side === 'left' ? current.right : current.left;
      const direction = side === 'left'
        ? (event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0)
        : (event.key === 'ArrowLeft' ? 1 : event.key === 'ArrowRight' ? -1 : 0);
      const requested = event.key === 'Home' ? min : event.key === 'End' ? max : currentWidth + direction * step;
      const nextWidth = updatePanelWidth(side, requested, otherWidth);
      return side === 'left' ? { ...current, left: nextWidth } : { ...current, right: nextWidth };
    });
  }, [updatePanelWidth]);
  useEffect(() => {
    if (editorMode === 'artist') return;
    if (activeTool === 'move' || activeTool === 'select-rect' || activeTool === 'select-lasso'
      || activeTool === 'select-magic' || activeTool === 'select-pixel'
      || activeTool === 'pattern' || activeTool === 'pattern-tile' || activeTool === 'gradient') {
      setActiveTool(null);
      setSelectionMask(null);
    }
  }, [activeTool, editorMode]);

  // Per-layer settings: restore mapMode/staircaseMode/dithering when active layer changes
  const layersRef = useRef(layers);
  layersRef.current = layers;
  useEffect(() => {
    const layer = layersRef.current.find(l => l.id === activeLayerId);
    if (!layer) return;
    setMapMode(buildTechnique === 'suppression_two_layer' ? '3d' : (layer.mapMode ?? '2d'));
    setStaircaseMode(layer.staircaseMode ?? 'optimized');
    if (layer.dithering !== undefined) setDithering(coerceDitheringMode(layer.dithering));
    setSelectionMask(null);
    if (layer.sourceImage !== undefined) setSourceImage(layer.sourceImage);
    if ('sourceFile' in layer) uploadedFileRef.current = layer.sourceFile ?? null;
    if ('sourceUploadedImage' in layer) uploadedImageRef.current = layer.sourceUploadedImage ?? null;
  }, [activeLayerId, buildTechnique]);

  // Push current state onto undo stack before a tracked action
  const pushToHistory = useCallback(() => {
    const current = latestRef.current;
    setUndoStack(prev => {
      const next = [...prev, {
        layerState: snapshotLayerState({
          layers: current.layers,
          activeLayerId: current.activeLayerId,
          groups: current.groups,
        }),
        blockSelection: current.blockSelection,
        mapMode: current.mapMode,
        minecraftVersion: current.minecraftVersion,
      }];
      return next.length > MAX_HISTORY ? next.slice(1) : next;
    });
    setRedoStack([]);
  // latestRef is a stable ref, setters are stable
  }, []);

  const handleUndo = useCallback(() => {
    setUndoStack(prev => {
      if (prev.length === 0) return prev;
      const entry = prev[prev.length - 1];
      const cur = latestRef.current;
      setRedoStack(r => [...r, {
        layerState: snapshotLayerState({ layers: cur.layers, activeLayerId: cur.activeLayerId, groups: cur.groups }),
        blockSelection: cur.blockSelection,
        mapMode: cur.mapMode,
        minecraftVersion: cur.minecraftVersion,
      }]);
      const restored = normalizeIncomingBuildState(entry.blockSelection, entry.mapMode);
      setLayerState(snapshotLayerState(entry.layerState));
      setSelectionMask(null);
      setMapMode(restored.mapMode);
      setMinecraftVersion(entry.minecraftVersion);
      setBlockSelection(restored.blockSelection);
      return prev.slice(0, -1);
    });
  }, [normalizeIncomingBuildState]);

  const handleRedo = useCallback(() => {
    setRedoStack(prev => {
      if (prev.length === 0) return prev;
      const entry = prev[prev.length - 1];
      const cur = latestRef.current;
      setUndoStack(u => {
        const next = [...u, {
          layerState: snapshotLayerState({ layers: cur.layers, activeLayerId: cur.activeLayerId, groups: cur.groups }),
          blockSelection: cur.blockSelection,
          mapMode: cur.mapMode,
          minecraftVersion: cur.minecraftVersion,
        }];
        return next.length > MAX_HISTORY ? next.slice(1) : next;
      });
      const restored = normalizeIncomingBuildState(entry.blockSelection, entry.mapMode);
      setLayerState(snapshotLayerState(entry.layerState));
      setSelectionMask(null);
      setMapMode(restored.mapMode);
      setMinecraftVersion(entry.minecraftVersion);
      setBlockSelection(restored.blockSelection);
      return prev.slice(0, -1);
    });
  }, [normalizeIncomingBuildState]);

  // Keyboard shortcuts for undo/redo + export — effect registered below,
  // after handleExportPng/handleExportLitematic are declared.

  // Stable ref so keyboard handler can call handleDeleteSelection without forward-ref TDZ
  const handleDeleteSelectionRef = useRef<(() => void) | null>(null);

  // Keyboard shortcuts for paint tools (E / B / F / Escape) + view toggles (Z / O)
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (isInteractiveKeyboardTarget(e.target)) return;
      if (!imageData) return;
      switch (e.code) {
        case 'KeyE': setActiveTool(t => t === 'eyedropper' ? null : 'eyedropper'); break;
        case 'KeyB': if (ensureActiveLayerEditable()) setActiveTool(t => t === 'brush' ? null : 'brush'); break;
        case 'KeyF': if (ensureActiveLayerEditable()) setActiveTool(t => t === 'fill' ? null : 'fill'); break;
        case 'KeyX': if (ensureActiveLayerEditable()) setActiveTool(t => t === 'eraser' ? null : 'eraser'); break;
        case 'KeyT': if (ensureActiveLayerEditable()) setActiveTool(t => t === 'text' ? null : 'text'); break;
        case 'KeyR': if (editorMode === 'artist') setActiveTool(t => t === 'select-rect' ? null : 'select-rect'); break;
        case 'KeyL': if (editorMode === 'artist') setActiveTool(t => t === 'select-lasso' ? null : 'select-lasso'); break;
        case 'KeyW': if (editorMode === 'artist') setActiveTool(t => t === 'select-magic' ? null : 'select-magic'); break;
        case 'KeyP': if (editorMode === 'artist' && ensureActiveLayerEditable()) setActiveTool(t => t === 'pattern-tile' ? null : 'pattern-tile'); break;
        case 'KeyG': if (editorMode === 'artist' && ensureActiveLayerEditable()) setActiveTool(t => t === 'gradient' ? null : 'gradient'); break;
        case 'KeyV': if (editorMode === 'artist' && ensureActiveLayerEditable()) setActiveTool(t => t === 'move' ? null : 'move'); break;
        case 'Delete':
        case 'Backspace': if (editorMode === 'artist' && selectionMask) { handleDeleteSelectionRef.current?.(); } break;
        case 'Escape':
          if (selectionMask && editorMode === 'artist') { setSelectionMask(null); return; }
          setActiveTool(null);
          break;
        case 'KeyZ': setShowGrid(g => !g); break;
        case 'KeyO': if (!compareMode) setSplitPos(50); break;
      }
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [imageData, compareMode, editorMode, selectionMask, ensureActiveLayerEditable]);


  const modeShades = (mapMode === '2d') ? [1] : [0, 1, 2];

  // When adjustments are disabled, use zero adjustments for processing
  const effectiveAdjustments = showAdjustments ? adjustments : DEFAULT_ADJUSTMENTS;

  const activePalette = useMemo<ComputedPalette>(
    () => buildComputedPalette(buildPaletteFromSelection(blockSelection, modeShades, minecraftVersion, platformMode), colorMatch),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [blockSelection, mapMode, minecraftVersion, platformMode, colorMatch],
  );


  const selectedPixelCount = useMemo(() => selectionMask ? countSelected(selectionMask) : 0, [selectionMask]);
  const activeLayerLocked = Boolean(activeLayer?.locked);
  const activeToolUi = (() => {
    switch (activeTool) {
      case 'eyedropper': return { icon: mkIcons.eyedropper, name: t('Пипетка', 'Eyedropper'), key: 'E', hint: t('Клик: взять блок. Shift + ЛКМ: брать по ходу курсора.', 'Click: sample a block. Shift + LMB: sample along the cursor.') };
      case 'brush': return { icon: mkIcons.brush, name: t('Кисть', 'Brush'), key: 'B', hint: t('Рисуй выбранным блоком. Shift + клик — прямая линия.', 'Paint with the selected block. Shift + click draws a straight line.') };
      case 'fill': return { icon: mkIcons.fill, name: t('Заливка', 'Fill'), key: 'F', hint: t('Заполни связанную область выбранным блоком.', 'Fill a connected area with the selected block.') };
      case 'eraser': return { icon: mkIcons.eraser, name: t('Ластик', 'Eraser'), key: 'X', hint: t('Удали пиксели активного слоя.', 'Erase pixels from the active layer.') };
      case 'text': return { icon: mkIcons.text, name: t('Текст', 'Text'), key: 'T', hint: t('Кликни по холсту, введи текст и размести его. Затем перетаскивай и меняй размер.', 'Click the canvas, type and place text. Then drag it or resize it.') };
      case 'move': return { icon: mkIcons.move, name: t('Перемещение слоя', 'Move layer'), key: 'V', hint: t('Сдвинь активный слой. Space + ЛКМ двигает только холст.', 'Move the active layer. Space + LMB pans only the canvas.') };
      case 'select-rect': return { icon: mkIcons.selectRect, name: t('Прямоугольное выделение', 'Rectangular selection'), key: 'R', hint: t('Shift добавляет область, Alt вычитает.', 'Shift adds to the selection, Alt subtracts.') };
      case 'select-lasso': return { icon: mkIcons.lasso, name: t('Лассо', 'Lasso'), key: 'L', hint: t('Обведи область вручную. Shift добавляет, Alt вычитает.', 'Draw a freeform selection. Shift adds, Alt subtracts.') };
      case 'select-magic': return { icon: mkIcons.wand, name: t('Волшебная палочка', 'Magic wand'), key: 'W', hint: t('Выдели похожие цвета или прозрачность.', 'Select similar colors or transparency.') };
      case 'pattern-tile': return { icon: mkIcons.pattern, name: t('Паттерн-кисть', 'Pattern brush'), key: 'P', hint: t('Выбери блок, настрой сетку и рисуй повторяющимся паттерном.', 'Choose a block, edit the grid, then paint a repeating pattern.') };
      case 'gradient': return { icon: mkIcons.gradient, name: t('Градиент', 'Gradient'), key: 'G', hint: t('Протяни линию от первого цвета к последнему.', 'Drag a line from the first color to the last.') };
      default: return { icon: mkIcons.select, name: t('Курсор', 'Cursor'), key: 'Esc', hint: t('Клик — действия с блоком, перетаскивание — навигация по арту.', 'Click for block actions, drag to navigate the art.') };
    }
  })();
  const toolUsesSharedPaintBlock = activeTool === 'eyedropper' || activeTool === 'brush' || activeTool === 'fill';

  // exportRef is updated below, after compositeImageData is computed

  function handleCancelProcessing() {
    activeWorkerJobIdRef.current = null;
    workerRef.current?.terminate();
    workerRef.current = null;
    if (cancelTimerRef.current) { clearTimeout(cancelTimerRef.current); cancelTimerRef.current = null; }
    setShowCancel(false);
    setProcessing(false);
    setProcessingProgress(0);
  }

  const runProcess = useCallback((
    img: HTMLImageElement,
    mode: DitheringMode,
    grid: MapGrid,
    intens: number,
    compare: boolean,
    cmpLeft: DitheringMode,
    cmpRight: DitheringMode,
    palette: ComputedPalette,
    adj: ImageAdjustments,
    bn: number,
    kp: KlussParams,
  ) => {
    // Terminate any running worker and clear pending cancel timer
    activeWorkerJobIdRef.current = null;
    workerRef.current?.terminate();
    if (cancelTimerRef.current) { clearTimeout(cancelTimerRef.current); cancelTimerRef.current = null; }

    setProcessing(true);
    setProcessingProgress(0);
    setShowCancel(false);

    const w = gridPixelWidth(grid);
    const h = gridPixelHeight(grid);

    // Show cancel button after 500 ms
    cancelTimerRef.current = setTimeout(() => setShowCancel(true), 500);

    const worker = new Worker(
      new URL('./workers/processor.worker.ts', import.meta.url),
      { type: 'module' },
    );
    const jobId = ++workerJobSeqRef.current;
    activeWorkerJobIdRef.current = jobId;
    workerRef.current = worker;

    function done() {
      if (activeWorkerJobIdRef.current === jobId) activeWorkerJobIdRef.current = null;
      if (cancelTimerRef.current) { clearTimeout(cancelTimerRef.current); cancelTimerRef.current = null; }
      setShowCancel(false);
      setProcessing(false);
      setProcessingProgress(0);
      if (workerRef.current === worker) workerRef.current = null;
    }

    worker.onmessage = (e: MessageEvent) => {
      const msg = e.data;
      if (msg.jobId !== jobId || activeWorkerJobIdRef.current !== jobId || workerRef.current !== worker) return;
      if (msg.type === 'progress') {
        setProcessingProgress(msg.pct as number);
      } else if (msg.type === 'result') {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const mk = (d: any) => new ImageData(new Uint8ClampedArray(d.buffer as ArrayBuffer), w, h);
        const processed = mk(msg.processedData);
        // Guard: never overwrite a manually-edited (dirty) layer with processed results
        const targetId = processTargetLayerIdRef.current ?? latestRef.current.activeLayerId;
        const targetLayer = latestRef.current.layers.find(l => l.id === targetId);
        if (targetLayer?.isDirty && !pendingAlphaMaskRef.current) {
          processTargetLayerIdRef.current = null;
          setOriginalData(mk(msg.originalData));
          done();
          return;
        }
        const alphaMask = pendingAlphaMaskRef.current;
        pendingAlphaMaskRef.current = null;
        if (alphaMask) {
          // Re-apply the alpha channel from before re-processing (preserves deleted background)
          for (let i = 0; i < alphaMask.length; i++) {
            processed.data[i * 4 + 3] = alphaMask[i];
          }
          setImageData(processed, true, true);  // keep dirty — manual edits still present
        } else {
          setImageData(processed, false, true);  // fresh process, not dirty
        }
        setOriginalData(mk(msg.originalData));
        trackEvent('map_generated', {
          compare_mode: false,
          output_variant: 'single',
          map_mode: latestRef.current.mapMode,
          staircase_mode: latestRef.current.mapMode === '3d' ? latestRef.current.staircaseMode : undefined,
          dithering: mode,
          map_wide: grid.wide,
          map_tall: grid.tall,
          intensity: intens,
          bn_scale: bn,
          palette_size: palette.colors.length,
          platform_mode: latestRef.current.platformMode,
          source_width: img.naturalWidth,
          source_height: img.naturalHeight,
        });
        done();
      } else if (msg.type === 'compare_result') {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const mk = (d: any) => new ImageData(new Uint8ClampedArray(d.buffer as ArrayBuffer), w, h);
        setCompareData({ left: mk(msg.leftData), right: mk(msg.rightData) });
        setOriginalData(mk(msg.originalData));
        trackEvent('map_generated', {
          compare_mode: true,
          output_variant: 'compare',
          map_mode: latestRef.current.mapMode,
          staircase_mode: latestRef.current.mapMode === '3d' ? latestRef.current.staircaseMode : undefined,
          compare_left: cmpLeft,
          compare_right: cmpRight,
          map_wide: grid.wide,
          map_tall: grid.tall,
          intensity: intens,
          bn_scale: bn,
          palette_size: palette.colors.length,
          platform_mode: latestRef.current.platformMode,
          source_width: img.naturalWidth,
          source_height: img.naturalHeight,
        });
        done();
      } else if (msg.type === 'error') {
        console.error('Processor worker error:', msg.message);
        showAppNotice(t('Не удалось обработать изображение.', 'Could not process the image.'), 'error');
        done();
      }
    };
    worker.onerror = () => {
      if (activeWorkerJobIdRef.current === jobId && workerRef.current === worker) {
        showAppNotice(t('Не удалось обработать изображение.', 'Could not process the image.'), 'error');
        done();
      }
    };

    // Create transferable bitmap, then dispatch to worker.
    // Use raw File if available to bypass ICC profile color correction.
    const bitmapSource: ImageBitmapSource = uploadedFileRef.current ?? img;
    createImageBitmap(bitmapSource, { colorSpaceConversion: 'none' }).then(bitmap => {
      // If a newer runProcess call superseded this one, discard
      if (workerRef.current !== worker || activeWorkerJobIdRef.current !== jobId) { bitmap.close(); return; }
      if (compare) {
        worker.postMessage(
          { type: 'compare', jobId, bitmap, width: w, height: h, intensity: intens / 100, leftMode: cmpLeft, rightMode: cmpRight, palette, adjustments: adj, bnScale: bn, klussParams: kp },
          [bitmap],
        );
      } else {
        worker.postMessage(
          { type: 'process', jobId, bitmap, options: { dithering: mode, width: w, height: h, intensity: intens / 100, bnScale: bn, palette, adjustments: adj, klussParams: kp, bgMode: bgModeRef.current, bgColor: bgColorRef.current } },
          [bitmap],
        );
      }
    }).catch(() => {
      if (activeWorkerJobIdRef.current === jobId && workerRef.current === worker) {
        showAppNotice(t('Не удалось подготовить изображение для обработки.', 'Could not prepare the image for processing.'), 'error');
        done();
      }
    });
  }, [showAppNotice, t]);

  const handleImageLoaded = useCallback((img: HTMLImageElement, file?: File) => {
    uploadedImageRef.current = img;   // save original for crop modal
    uploadedFileRef.current  = file ?? null;
    // Detect transparency by sampling pixels at reduced scale
    const tc = document.createElement('canvas');
    tc.width  = Math.min(img.naturalWidth,  64);
    tc.height = Math.min(img.naturalHeight, 64);
    const tctx = tc.getContext('2d')!;
    tctx.drawImage(img, 0, 0, tc.width, tc.height);
    const td = tctx.getImageData(0, 0, tc.width, tc.height).data;
    let hasAlpha = false;
    for (let i = 3; i < td.length; i += 4) { if (td[i] < 255) { hasAlpha = true; break; } }
    setSourceHasAlpha(hasAlpha);
    if (!hasAlpha) { setBgMode('color'); bgModeRef.current = 'color'; }
    setOriginalData(null);
    setCompareData(null);
    setSourceImage(img);
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === prev.activeLayerId ? { ...l, sourceImage: img, sourceFile: file ?? null, sourceUploadedImage: img } : l),
    }));
    setSplitPos(50);
    setUndoStack([]);
    setRedoStack([]);
    runProcess(img, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
  }, [dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams, runProcess, setSourceHasAlpha, setBgMode]);

  // ── GIF Project handlers ─────────────────────────────────────────────────────

  const handleOpenAsGifProject = useCallback(async (frames: ImageData[], initialConfig: GifFrameConfig) => {
    const thumbnails = frames.map(f => makeThumbnail(f, 80));
    const configs: GifFrameConfig[] = frames.map(() => ({ ...initialConfig }));
    setGifProject({ frames, thumbnails, currentIndex: 0, configs });
    setGifFrames(null);
    // Load frame 0 into editor
    const img = await imageDataToHtmlImage(frames[0]);
    uploadedFileRef.current = null;
    handleImageLoaded(img);
  }, [handleImageLoaded]);

  const handleGifFrameSelect = useCallback(async (index: number) => {
    if (!gifProject) return;
    // Save current frame's config
    const currentConfig: GifFrameConfig = {
      dithering, intensity, mapMode, staircaseMode, adjustments, bnScale, klussParams, blockSelection,
    };
    const updatedConfigs = [...gifProject.configs];
    updatedConfigs[gifProject.currentIndex] = currentConfig;

    setGifProject(prev => prev ? { ...prev, configs: updatedConfigs, currentIndex: index } : prev);

    // Load new frame's config
    const newConfig = updatedConfigs[index];
    const normalizedBuild = normalizeIncomingBuildState(newConfig.blockSelection, newConfig.mapMode);
    setDithering(coerceDitheringMode(newConfig.dithering));
    setIntensity(newConfig.intensity);
    setMapMode(normalizedBuild.mapMode);
    setMinecraftVersion(normalizedBuild.minecraftVersion);
    setStaircaseMode(newConfig.staircaseMode);
    setAdjustments(newConfig.adjustments);
    setBnScale(newConfig.bnScale);
    setKlussParams(newConfig.klussParams ?? DEFAULT_KLUSS_PARAMS);
    setBlockSelection(normalizedBuild.blockSelection);

    // Load new frame into editor
    const img = await imageDataToHtmlImage(gifProject.frames[index]);
    uploadedFileRef.current = null;
    uploadedImageRef.current = img;
    setSourceImage(img);
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === prev.activeLayerId ? { ...l, sourceImage: img, sourceFile: null, sourceUploadedImage: img } : l),
    }));
    setUndoStack([]);
    setRedoStack([]);
    const cfgShades = normalizedBuild.mapMode === '2d' ? [1] : [0, 1, 2];
    const pal = buildComputedPalette(buildPaletteFromSelection(
      normalizedBuild.blockSelection,
      cfgShades,
      normalizedBuild.minecraftVersion,
      normalizedBuild.platformMode,
    ), colorMatch);
    runProcess(img, coerceDitheringMode(newConfig.dithering), mapGrid, newConfig.intensity, compareMode, compareLeft, compareRight, pal, newConfig.adjustments, newConfig.bnScale, newConfig.klussParams ?? DEFAULT_KLUSS_PARAMS);
  }, [gifProject, dithering, intensity, mapMode, staircaseMode, adjustments, bnScale, klussParams, blockSelection, colorMatch, mapGrid, compareMode, compareLeft, compareRight, normalizeIncomingBuildState, runProcess]);

  const handleGifProjectConfigChange = useCallback((index: number, partial: Partial<GifFrameConfig>) => {
    setGifProject(prev => {
      if (!prev) return prev;
      const configs = [...prev.configs];
      configs[index] = { ...configs[index], ...partial };
      return { ...prev, configs };
    });
  }, []);

  const handleCloseGifProject = useCallback(() => {
    setGifProject(null);
  }, []);

  const handleExportGifLitematicPack = useCallback(async () => {
    if (!gifProject) return;
    const { buildLitematicBytes } = await import('./lib/exportLitematic');
    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();
    for (let i = 0; i < gifProject.frames.length; i++) {
      const frame = gifProject.frames[i];
      const cfg = gifProject.configs[i];
      const cfgShades = cfg.mapMode === '2d' ? [1] : [0, 1, 2];
      const pal = buildComputedPalette(buildPaletteFromSelection(cfg.blockSelection, cfgShades, minecraftVersion, platformMode), colorMatch);
      const w = gridPixelWidth(mapGrid);
      const h = gridPixelHeight(mapGrid);
      // Let `processImage` perform the final map-grid reduction. Pre-scaling
      // here would bypass the exact linear-light resampler used everywhere
      // else, making GIF Litematic frames less faithful than still images.
      const bitmap = await createImageBitmap(frame, { colorSpaceConversion: 'none' });
      const { processImage } = await import('./lib/processor');
      const result = await processImage(bitmap, { dithering: coerceDitheringMode(cfg.dithering), width: w, height: h, intensity: cfg.intensity / 100, bnScale: cfg.bnScale, palette: pal, adjustments: cfg.adjustments, klussParams: cfg.klussParams ?? DEFAULT_KLUSS_PARAMS });
      bitmap.close();
      const pad = String(i + 1).padStart(3, '0');
      const structure = cfg.mapMode === '3d' ? 'staircase' : 'flat';
      const bytes = await buildLitematicBytes(result.processed, pal, cfg.blockSelection, `frame_${pad}`, structure, undefined, cfg.staircaseMode);
      zip.file(`frame_${pad}.litematic`, bytes);
    }
    const blob = await zip.generateAsync({ type: 'blob' });
    downloadExportBlob(blob, 'gif_mapart.zip');
  }, [gifProject, minecraftVersion, platformMode, colorMatch, mapGrid]);

  const handleCropApply = useCallback((croppedImg: HTMLImageElement) => {
    setShowCropModal(false);
    uploadedFileRef.current = null;   // use cropped image, not original file
    uploadedImageRef.current = croppedImg;
    setOriginalData(null);
    setCompareData(null);
    setSourceImage(croppedImg);
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === prev.activeLayerId ? { ...l, sourceImage: croppedImg, sourceFile: null, sourceUploadedImage: croppedImg } : l),
    }));
    setSplitPos(50);
    setUndoStack([]);
    setRedoStack([]);
    runProcess(croppedImg, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
  }, [dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams, runProcess, setShowCropModal]);

  const handleCreateBlankCanvas = useCallback((
    bg: { r: number; g: number; b: number; a: number } | null,
    grid: MapGrid,
  ) => {
    trackEvent('blank_canvas_created', { map_wide: grid.wide, map_tall: grid.tall, has_background: Boolean(bg) });
    setShowNewCanvasModal(false);
    const width  = gridPixelWidth(grid);
    const height = gridPixelHeight(grid);
    const data   = new ImageData(width, height);
    if (bg) {
      for (let i = 0; i < data.data.length; i += 4) {
        data.data[i]     = bg.r;
        data.data[i + 1] = bg.g;
        data.data[i + 2] = bg.b;
        data.data[i + 3] = bg.a;
      }
    }
    setMapGrid(grid);
    setSourceImage(null);
    uploadedImageRef.current = null;
    uploadedFileRef.current  = null;
    setOriginalData(null);
    setCompareData(null);
    setUndoStack([]);
    setRedoStack([]);
    // Reset to single fresh layer with blank canvas data
    const newLayer = createLayer('Слой 1');
    newLayer.imageData = data;
    setLayerState({ layers: [newLayer], activeLayerId: newLayer.id, groups: [] });
  }, [setShowNewCanvasModal]);

  const handleDitheringChange = useCallback((mode: DitheringMode) => {
    setDithering(mode);
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === prev.activeLayerId ? { ...l, dithering: mode } : l),
    }));
    if (sourceImage && activeLayerHasContent(activeLayerRef)) {
      if (activeLayerRef.current?.isDirty) {
        // Layer was manually edited — re-process but re-apply the current alpha mask afterwards
        const img = activeLayerRef.current.imageData;
        if (img) {
          const mask = new Uint8Array(img.width * img.height);
          for (let i = 0; i < mask.length; i++) mask[i] = img.data[i * 4 + 3];
          pendingAlphaMaskRef.current = mask;
        }
      }
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, mode, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [sourceImage, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams, runProcess]);

  const handleMapGridChange = useCallback((grid: MapGrid) => {
    setMapGrid(grid);
    const newW = gridPixelWidth(grid);
    const newH = gridPixelHeight(grid);
    // Scale all layers to new dimensions before re-processing
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => {
        if (!l.imageData) return l; // empty layers stay empty
        const scaleX = newW / l.imageData.width;
        const scaleY = newH / l.imageData.height;
        return {
          ...l,
          imageData: scaleImageData(l.imageData, newW, newH),
          // Keep the editable text bounds aligned with its raster preview after
          // a map-size change. This also preserves non-square grid changes.
          text: l.text
            ? {
              ...l.text,
              x: l.text.x * scaleX,
              y: l.text.y * scaleY,
              scaleX: l.text.scaleX * scaleX,
              scaleY: l.text.scaleY * scaleY,
            }
            : undefined,
        };
      }),
    }));
    // Undo entries contain ImageData at old dimensions — clear to avoid size mismatch
    setUndoStack([]);
    setRedoStack([]);
    setSelectionMask(null);
    // Scale originalData (compare preview) to new dimensions
    if (originalDataRef.current) {
      setOriginalData(scaleImageData(originalDataRef.current, newW, newH));
    }
    // Re-process only the ACTIVE non-dirty layer — only if one exists
    if (sourceImage) {
      const activeId = latestRef.current.activeLayerId;
      const srcLayer = latestRef.current.layers.find(l => l.id === activeId && !l.isDirty);
      if (srcLayer) {
        processTargetLayerIdRef.current = srcLayer.id;
        runProcess(sourceImage, dithering, grid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
      }
    }
  }, [sourceImage, dithering, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams, runProcess]);

  const handleIntensityChange = useCallback((v: number) => setIntensity(v), []);

  const handleIntensityCommit = useCallback((v: number) => {
    setIntensity(v);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, v, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [sourceImage, dithering, mapGrid, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams, runProcess]);

  const handleBnScaleChange = useCallback((v: number) => {
    setBnScale(v);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, v, klussParams);
    }
  }, [sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, klussParams, runProcess]);

  const handleKlussParamsChange = useCallback((kp: KlussParams) => {
    setKlussParams(kp);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, kp);
    }
  }, [sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, runProcess]);

  const handleCompareModeChange = useCallback((enabled: boolean) => {
    setCompareMode(enabled);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, enabled, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [sourceImage, dithering, mapGrid, intensity, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams, runProcess]);

  const handleCompareSideChange = useCallback((side: 'left' | 'right', mode: DitheringMode) => {
    if (side === 'left') {
      setCompareLeft(mode);
      if (sourceImage) {
        processTargetLayerIdRef.current = latestRef.current.activeLayerId;
        runProcess(sourceImage, dithering, mapGrid, intensity, true, mode, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
      }
    } else {
      setCompareRight(mode);
      if (sourceImage) {
        processTargetLayerIdRef.current = latestRef.current.activeLayerId;
        runProcess(sourceImage, dithering, mapGrid, intensity, true, compareLeft, mode, activePalette, effectiveAdjustments, bnScale, klussParams);
      }
    }
  }, [sourceImage, dithering, mapGrid, intensity, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams, runProcess]);

  const handleSelectionChange = useCallback((sel: BlockSelection) => {
    const safeSelection = buildTechnique === 'suppression_two_layer'
      ? sanitizeSelectionForSuppression(sel, minecraftVersion, platformMode)
      : sel;
    pushToHistory();
    setBlockSelection(safeSelection);
    const shades = mapMode === '2d' ? [1] : [0, 1, 2];
    const newPalette = buildComputedPalette(buildPaletteFromSelection(safeSelection, shades, minecraftVersion, platformMode), colorMatch);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, newPalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, effectiveAdjustments, mapMode, bnScale, klussParams, minecraftVersion, platformMode, colorMatch, buildTechnique, pushToHistory, runProcess]);

  const handleBuildModeChange = useCallback((mode: EditorBuildMode) => {
    const enteringSuppression = mode === 'suppression_two_layer' && buildTechnique !== 'suppression_two_layer';
    const leavingSuppression = mode !== 'suppression_two_layer' && buildTechnique === 'suppression_two_layer';
    if (enteringSuppression) {
      standardBuildSnapshotRef.current = { minecraftVersion, platformMode, blockSelection, supportBlock };
    }
    const resolved = resolveEditorBuildMode(mode, minecraftVersion);
    const restored = leavingSuppression ? standardBuildSnapshotRef.current : null;
    const nextVersion = restored?.minecraftVersion ?? resolved.minecraftVersion;
    const nextPlatform = mode === 'suppression_two_layer' ? 'java' : (restored?.platformMode ?? platformMode);
    const nextSelection = mode === 'suppression_two_layer'
      ? sanitizeSelectionForSuppression(blockSelection, nextVersion, nextPlatform)
      : (restored?.blockSelection ?? blockSelection);

    trackEvent('map_mode_applied', { map_mode: mode });
    setMapMode(resolved.mapMode);
    setBuildTechnique(resolved.buildTechnique);
    setMinecraftVersion(nextVersion);
    setPlatformMode(nextPlatform);
    setBlockSelection(nextSelection);
    if (enteringSuppression) setSupportBlock(sanitizeSuppressionSupportBlock(supportBlock));
    if (leavingSuppression && restored) setSupportBlock(restored.supportBlock);
    if (leavingSuppression) standardBuildSnapshotRef.current = null;
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === prev.activeLayerId ? { ...l, mapMode: resolved.mapMode } : l),
    }));
    const shades = resolved.mapMode === '2d' ? [1] : [0, 1, 2];
    const newPalette = buildComputedPalette(buildPaletteFromSelection(nextSelection, shades, nextVersion, nextPlatform), colorMatch);
    if (sourceImage && activeLayerHasContent(activeLayerRef)) {
      if (activeLayerRef.current?.isDirty) {
        const img = activeLayerRef.current.imageData;
        if (img) {
          const mask = new Uint8Array(img.width * img.height);
          for (let i = 0; i < mask.length; i++) mask[i] = img.data[i * 4 + 3];
          pendingAlphaMaskRef.current = mask;
        }
      }
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, newPalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, blockSelection, effectiveAdjustments, bnScale, klussParams, minecraftVersion, platformMode, colorMatch, buildTechnique, supportBlock, runProcess, setSupportBlock]);

  const handlePlatformModeChange = useCallback((next: PlatformMode) => {
    if (isPlatformLockedForBuildTechnique(buildTechnique)) return;
    setPlatformMode(next);
  }, [buildTechnique]);

  const handleMinecraftVersionChange = useCallback((version: MinecraftVersion) => {
    setMinecraftVersion(version);
    setBlockSelection(previous => buildTechnique === 'suppression_two_layer'
      ? sanitizeSelectionForSuppression(previous, version, platformMode)
      : sanitizeSelectionForPlatform(DEFAULT_SELECTION, platformMode));
  }, [buildTechnique, platformMode]);

  const handleStaircaseModeChange = useCallback((mode: 'classic' | 'optimized') => {
    trackEvent('staircase_mode_applied', { staircase_mode: mode });
    setStaircaseMode(mode);
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === prev.activeLayerId ? { ...l, staircaseMode: mode } : l),
    }));
  }, []);

  const handleColorMatchChange = useCallback((mode: ColorMatchMode) => {
    trackEvent('color_match_changed', { color_match: mode });
    setColorMatch(mode);
    if (sourceImage) {
      const shades = mapMode === '2d' ? [1] : [0, 1, 2];
      const newPalette = buildComputedPalette(buildPaletteFromSelection(blockSelection, shades, minecraftVersion, platformMode), mode);
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, newPalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [sourceImage, mapMode, blockSelection, minecraftVersion, platformMode, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, effectiveAdjustments, bnScale, klussParams, runProcess]);

  const handleAdjChange = useCallback((adj: ImageAdjustments) => {
    setAdjustments(adj);
  }, []);

  const handleAdjCommit = useCallback((adj: ImageAdjustments) => {
    setAdjustments(adj);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, adj, bnScale, klussParams);
    }
  }, [sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, bnScale, klussParams, runProcess]);

  const handleToggleSection = useCallback((key: string) => {
    setCollapsedSections(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const handleToggleAdjustments = useCallback(() => {
    setShowAdjustments(prev => {
      const next = !prev;
      if (sourceImage) {
        const adj = next ? adjustments : DEFAULT_ADJUSTMENTS;
        processTargetLayerIdRef.current = latestRef.current.activeLayerId;
        runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, adj, bnScale, klussParams);
      }
      return next;
    });
  }, [adjustments, sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, bnScale, klussParams, runProcess]);

  // Reprocess when background mode or color changes
  useEffect(() => {
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, activePalette, effectiveAdjustments, bnScale, klussParams);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bgMode, bgColor]);

  const handleRemoveBlock = useCallback((csId: number) => {
    pushToHistory();
    setPaletteFocus(current => current?.csId === csId ? null : current);
    const next: BlockSelection = { ...blockSelection, [csId]: [] };
    setBlockSelection(next);
    const shades = mapMode === '2d' ? [1] : [0, 1, 2];
    const newPalette = buildComputedPalette(buildPaletteFromSelection(next, shades, minecraftVersion, platformMode), colorMatch);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, newPalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [blockSelection, mapMode, sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, effectiveAdjustments, bnScale, klussParams, minecraftVersion, platformMode, colorMatch, pushToHistory, runProcess]);

  const handleReplaceBlock = useCallback((previousCsId: number, previousBlockId: number, nextCsId: number, nextBlockId: number) => {
    if (previousCsId === nextCsId && previousBlockId === nextBlockId) return;
    const targetRow = COLOUR_ROWS.find(candidate => candidate.csId === nextCsId);
    if (!targetRow?.blocks.some(block => block.blockId === nextBlockId)) return;
    pushToHistory();
    setPaletteFocus({ csId: nextCsId, blockId: nextBlockId, token: Date.now() });
    const next: BlockSelection = {
      ...blockSelection,
      [previousCsId]: previousCsId === nextCsId ? [nextBlockId] : [],
      [nextCsId]: [nextBlockId],
    };
    setBlockSelection(next);
    trackEvent('material_replaced', { color_group: previousCsId, previous_block_id: previousBlockId, next_color_group: nextCsId, next_block_id: nextBlockId });
    const shades = mapMode === '2d' ? [1] : [0, 1, 2];
    const newPalette = buildComputedPalette(buildPaletteFromSelection(next, shades, minecraftVersion, platformMode), colorMatch);
    if (sourceImage) {
      processTargetLayerIdRef.current = latestRef.current.activeLayerId;
      runProcess(sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, newPalette, effectiveAdjustments, bnScale, klussParams);
    }
  }, [blockSelection, mapMode, sourceImage, dithering, mapGrid, intensity, compareMode, compareLeft, compareRight, effectiveAdjustments, bnScale, klussParams, minecraftVersion, platformMode, colorMatch, pushToHistory, runProcess]);

  const handleFocusPaletteBlock = useCallback((csId: number, blockId: number) => {
    setPaletteFocus({ csId, blockId, token: Date.now() });
  }, []);

  const handleImageUpdate = useCallback((data: ImageData) => {
    if (!ensureActiveLayerEditable()) return;
    pushToHistory();
    setImageData(data, true);  // manual paint → mark dirty
  }, [ensureActiveLayerEditable, pushToHistory]);

  const handleTextBeginEdit = useCallback(() => {
    if (!ensureActiveLayerEditable()) return;
    pushToHistory();
  }, [ensureActiveLayerEditable, pushToHistory]);

  const handleTextUpdate = useCallback((meta: TextLayerMeta) => {
    if (!ensureActiveLayerEditable()) return;
    setLayerState(prev => {
      const active = prev.layers.find(layer => layer.id === prev.activeLayerId);
      if (!active?.isText) return prev;
      const layerWidth = active.imageData?.width ?? gridPixelWidth(mapGrid);
      const layerHeight = active.imageData?.height ?? gridPixelHeight(mapGrid);
      const imageData = renderTextLayer(meta, layerWidth, layerHeight);
      const title = meta.value.trim().replace(/\s+/g, ' ').slice(0, 28) || t('Текст', 'Text');
      return {
        ...prev,
        layers: prev.layers.map(layer => layer.id === prev.activeLayerId
          ? { ...layer, name: `${t('Текст', 'Text')} — ${title}`, imageData, isText: true, text: meta, isDirty: true }
          : layer),
      };
    });
  }, [ensureActiveLayerEditable, mapGrid, t]);

  const handleTextCreate = useCallback((meta: TextLayerMeta) => {
    if (!ensureActiveLayerEditable()) return;
    pushToHistory();
    setLayerState(prev => {
      const layerWidth = gridPixelWidth(mapGrid);
      const layerHeight = gridPixelHeight(mapGrid);
      const title = meta.value.trim().replace(/\s+/g, ' ').slice(0, 28) || t('Текст', 'Text');
      const layer = createLayer(`${t('Текст', 'Text')} — ${title}`, renderTextLayer(meta, layerWidth, layerHeight), true);
      layer.text = meta;
      layer.isDirty = true;
      const currentIndex = prev.layers.findIndex(item => item.id === prev.activeLayerId);
      const insertAt = currentIndex >= 0 ? currentIndex + 1 : prev.layers.length;
      return {
        ...prev,
        layers: [...prev.layers.slice(0, insertAt), layer, ...prev.layers.slice(insertAt)],
        activeLayerId: layer.id,
      };
    });
  }, [ensureActiveLayerEditable, mapGrid, pushToHistory, t]);

  // ── Selection operations ─────────────────────────────────────────────────────

  const handleDeleteSelection = useCallback(() => {
    if (!imageData || !selectionMask) return;
    if (!ensureActiveLayerEditable()) return;
    pushToHistory();
    const buf = new ImageData(new Uint8ClampedArray(imageData.data), imageData.width, imageData.height);
    for (let i = 0; i < selectionMask.length; i++) {
      if (!selectionMask[i]) continue;
      buf.data[i * 4] = 0; buf.data[i * 4 + 1] = 0; buf.data[i * 4 + 2] = 0; buf.data[i * 4 + 3] = 0;
    }
    setImageData(buf, true);  // manual edit → dirty
  }, [imageData, selectionMask, ensureActiveLayerEditable, pushToHistory]);
  handleDeleteSelectionRef.current = handleDeleteSelection;

  const handleFillSelection = useCallback(() => {
    if (!imageData || !selectionMask || !paintBlock || paintBlock.baseId === -1) return;
    if (!ensureActiveLayerEditable()) return;
    const color = activePalette.colors.find(c => c.baseId === paintBlock.baseId && c.shade === paintBlock.shade)
      ?? activePalette.colors.find(c => c.baseId === paintBlock.baseId);
    if (!color) return;
    pushToHistory();
    const buf = new ImageData(new Uint8ClampedArray(imageData.data), imageData.width, imageData.height);
    for (let i = 0; i < selectionMask.length; i++) {
      if (!selectionMask[i]) continue;
      buf.data[i * 4] = color.r; buf.data[i * 4 + 1] = color.g; buf.data[i * 4 + 2] = color.b; buf.data[i * 4 + 3] = 255;
    }
    setImageData(buf, true);  // manual edit → dirty
  }, [imageData, selectionMask, paintBlock, activePalette, ensureActiveLayerEditable, pushToHistory]);

  const handleInvertSelection = useCallback(() => {
    if (!imageData) return;
    setSelectionMask(prev => prev ? invertMask(prev, imageData.width, imageData.height) : selectAllMask(imageData.width, imageData.height));
  }, [imageData]);

  const handleMoveSelectionToLayer = useCallback(() => {
    if (!imageData || !selectionMask) return;
    if (!ensureActiveLayerEditable()) return;
    pushToHistory();
    const w = imageData.width, h = imageData.height;
    const newLayerData = new ImageData(w, h);
    const erasedData = new ImageData(new Uint8ClampedArray(imageData.data), w, h);
    for (let i = 0; i < selectionMask.length; i++) {
      if (!selectionMask[i]) continue;
      newLayerData.data[i * 4]     = imageData.data[i * 4];
      newLayerData.data[i * 4 + 1] = imageData.data[i * 4 + 1];
      newLayerData.data[i * 4 + 2] = imageData.data[i * 4 + 2];
      newLayerData.data[i * 4 + 3] = imageData.data[i * 4 + 3];
      erasedData.data[i * 4]     = 0;
      erasedData.data[i * 4 + 1] = 0;
      erasedData.data[i * 4 + 2] = 0;
      erasedData.data[i * 4 + 3] = 0;
    }
    const newLayer = createLayer('Выделение', newLayerData);
    newLayer.isDirty = true;  // manually created — must not be overwritten by runProcess
    setLayerState(prev => {
      const idx = prev.layers.findIndex(l => l.id === prev.activeLayerId);
      const updated = prev.layers.map(l => l.id === prev.activeLayerId ? { ...l, imageData: erasedData, isDirty: true } : l);
      const insertAt = idx >= 0 ? idx + 1 : updated.length;
      const newLayers = [...updated.slice(0, insertAt), newLayer, ...updated.slice(insertAt)];
      return { ...prev, layers: newLayers, activeLayerId: newLayer.id };
    });
    setSelectionMask(null);
  }, [imageData, selectionMask, ensureActiveLayerEditable, pushToHistory]);

  // ── Layer management ─────────────────────────────────────────────────────────

  const handleAddLayer = useCallback(() => {
    pushToHistory();
    setLayerState(prev => {
      const w = gridPixelWidth(mapGrid);
      const h = gridPixelHeight(mapGrid);
      const l = createLayer(`Слой ${prev.layers.length + 1}`, new ImageData(w, h));
      return { ...prev, layers: [...prev.layers, l], activeLayerId: l.id };
    });
  }, [mapGrid, pushToHistory]);

  const handleDeleteLayer = useCallback((id: string) => {
    if (latestRef.current.layers.length <= 1) return;
    pushToHistory();
    setLayerState(prev => {
      if (prev.layers.length <= 1) return prev; // always keep at least 1
      const newLayers = prev.layers.filter(l => l.id !== id);
      const newActive = prev.activeLayerId === id
        ? (newLayers[newLayers.length - 1]?.id ?? '')
        : prev.activeLayerId;
      return { ...prev, layers: newLayers, activeLayerId: newActive };
    });
  }, [pushToHistory]);

  const handleRenameLayer = useCallback((id: string, name: string) => {
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === id ? { ...l, name } : l),
    }));
  }, []);

  const handleToggleLayerVisible = useCallback((id: string) => {
    pushToHistory();
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === id ? { ...l, visible: !l.visible } : l),
    }));
  }, [pushToHistory]);

  const handleMoveLayerUp = useCallback((id: string) => {
    const index = latestRef.current.layers.findIndex(layer => layer.id === id);
    if (index < 0 || index >= latestRef.current.layers.length - 1) return;
    pushToHistory();
    setLayerState(prev => {
      const idx = prev.layers.findIndex(l => l.id === id);
      if (idx >= prev.layers.length - 1) return prev;
      const next = [...prev.layers];
      [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
      return { ...prev, layers: next };
    });
  }, [pushToHistory]);

  const handleMoveLayerDown = useCallback((id: string) => {
    const index = latestRef.current.layers.findIndex(layer => layer.id === id);
    if (index <= 0) return;
    pushToHistory();
    setLayerState(prev => {
      const idx = prev.layers.findIndex(l => l.id === id);
      if (idx <= 0) return prev;
      const next = [...prev.layers];
      [next[idx], next[idx - 1]] = [next[idx - 1], next[idx]];
      return { ...prev, layers: next };
    });
  }, [pushToHistory]);

  const handleOpacityChange = useCallback((id: string, opacity: number) => {
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === id ? { ...l, opacity } : l),
    }));
  }, []);

  const handleToggleLock = useCallback((id: string) => {
    pushToHistory();
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(l => l.id === id ? { ...l, locked: !l.locked } : l),
    }));
  }, [pushToHistory]);

  const handleMoveLayer = useCallback((fromIdx: number, toIdx: number) => {
    if (fromIdx === toIdx) return;
    pushToHistory();
    setLayerState(prev => {
      const display = [...prev.layers].reverse();
      if (fromIdx < 0 || fromIdx >= display.length || toIdx < 0 || toIdx >= display.length) return prev;
      const moved = display.splice(fromIdx, 1)[0];
      display.splice(toIdx, 0, moved);
      return { ...prev, layers: display.reverse() };
    });
  }, [pushToHistory]);

  const handleMergeDown = useCallback(() => {
    const activeIndex = latestRef.current.layers.findIndex(layer => layer.id === latestRef.current.activeLayerId);
    if (activeIndex <= 0) return;
    pushToHistory();
    setLayerState(prev => {
      const w = gridPixelWidth(mapGrid);
      const h = gridPixelHeight(mapGrid);
      const newLayers = mergeLayersDown(prev.layers, prev.activeLayerId, w, h);
      const mergedIdx = prev.layers.findIndex(l => l.id === prev.activeLayerId);
      const newActive = newLayers[Math.max(0, mergedIdx - 1)]?.id ?? newLayers[0]?.id ?? prev.activeLayerId;
      return { ...prev, layers: newLayers, activeLayerId: newActive };
    });
  }, [mapGrid, pushToHistory]);

  const handleMergeVisible = useCallback(() => {
    if (latestRef.current.layers.filter(layer => layer.visible && layer.imageData).length <= 1) return;
    pushToHistory();
    setLayerState(prev => {
      const w = gridPixelWidth(mapGrid);
      const h = gridPixelHeight(mapGrid);
      const newLayers = mergeVisible(prev.layers, w, h);
      const firstVisible = newLayers.find(l => l.visible && l.imageData);
      return { ...prev, layers: newLayers, activeLayerId: firstVisible?.id ?? prev.activeLayerId };
    });
  }, [mapGrid, pushToHistory]);

  const handleCreateGroup = useCallback((layerIds: string[]) => {
    if (layerIds.length === 0) return;
    pushToHistory();
    const groupId = `group-${Date.now()}`;
    const newGroup: LayerGroup = { id: groupId, name: 'Группа', visible: true, collapsed: false };
    setLayerState(prev => ({
      ...prev,
      groups: [...prev.groups, newGroup],
      layers: prev.layers.map(l => layerIds.includes(l.id) ? { ...l, groupId } : l),
    }));
  }, [pushToHistory]);

  const handleToggleGroupCollapse = useCallback((groupId: string) => {
    setLayerState(prev => ({
      ...prev,
      groups: prev.groups.map(g => g.id === groupId ? { ...g, collapsed: !g.collapsed } : g),
    }));
  }, []);

  const handleDeleteGroup = useCallback((groupId: string) => {
    pushToHistory();
    setLayerState(prev => ({
      ...prev,
      groups: prev.groups.filter(g => g.id !== groupId),
      layers: prev.layers.map(l => l.groupId === groupId ? { ...l, groupId: null } : l),
    }));
  }, [pushToHistory]);

  // ── Export shortcuts (stable — uses exportRef for fresh state) ───────────
  const handleExportPng = useCallback(() => {
    const { imageData: img, dithering: d, mapGrid: g } = exportRef.current;
    if (!img) return;
    downloadPng(img, `MapartForge_${g.wide}x${g.tall}_${d}.png`);
  }, []);

  const handleExportLitematic = useCallback(() => {
    const { activePalette: ap, blockSelection: sel, layers: exportLayers } = exportRef.current;
    const visLayers = exportLayers.filter(l => l.visible && l.imageData);
    if (visLayers.length === 0) return;
    const groups: Record<number, number[]> = {};
    for (const [k, v] of Object.entries(sel)) { groups[Number(k)] = v as number[]; }
    exportLitematicHybrid(visLayers.map(l => ({
      imageData: l.imageData!,
      mapMode: l.mapMode ?? '2d',
      staircaseMode: l.staircaseMode ?? 'optimized',
    })), ap, groups, 'MapartForge');
  }, []);

  // ── Project save / load ──────────────────────────────────────────────────────

  const applyProjectJsonRef = useRef<(json: string, successMessage?: string) => Promise<boolean>>(async () => false);

  const handleSaveProject = useCallback(() => {
    const settings: FullProjectSettings = {
      dithering,
      intensity,
      blockSelection: blockSelection as Record<string, number[]>,
      adjustments,
      colorMatch,
      mapMode,
      staircaseMode,
      bnScale,
      klussParams,
      originalDataB64: originalDataRef.current ? imageDataToBase64(originalDataRef.current) : undefined,
      minecraftVersion,
      platformMode,
      buildTechnique,
      supportBlock,
      supportMode,
    };
    const json = serializeFullProject(layers, activeLayerId, mapGrid, settings, layerGroups);
    const name = `MapKluss_${mapGrid.wide}x${mapGrid.tall}_${new Date().toISOString().slice(0,10)}.mapkluss`;
    downloadProject(json, name);
  }, [activeLayerId, adjustments, blockSelection, bnScale, buildTechnique, colorMatch, dithering, intensity, klussParams, layerGroups, layers, mapGrid, mapMode, minecraftVersion, platformMode, staircaseMode, supportBlock, supportMode]);

  const projectFileInputRef = useRef<HTMLInputElement | null>(null);
  const handleLoadProject = useCallback(() => {
    // Create hidden file input on demand
    if (!projectFileInputRef.current) {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.mapkluss,application/json';
      input.onchange = () => {
        const file = input.files?.[0];
        if (!file) return;
        file.text().then(async json => {
          const loaded = await applyProjectJsonRef.current(json, t('Проект загружен.', 'Project loaded.'));
          if (!loaded) {
            showAppNotice(t('Не удалось загрузить проект: файл повреждён или несовместим.', 'Could not load project: file is damaged or incompatible.'), 'error');
          }
        });
      };
      projectFileInputRef.current = input;
    }
    projectFileInputRef.current.value = '';
    projectFileInputRef.current.click();
  }, [showAppNotice, t]);

  // Keyboard shortcuts: 1-9 select dithering, C toggles compare mode
  // (declared here, after handleDitheringChange / handleCompareModeChange, to avoid TDZ)
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) return;
      if (e.code.startsWith('Digit')) {
        const idx = Number(e.key) - 1;
        if (idx >= 0 && idx < ALL_MODES.length) { handleDitheringChange(ALL_MODES[idx]); return; }
      }
      if (!imageData) return;
      if (e.code === 'KeyC') handleCompareModeChange(!compareMode);
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [imageData, compareMode, handleDitheringChange, handleCompareModeChange]);

  // Keyboard shortcuts for undo/redo + export
  // (declared here, after handleExportPng/handleExportLitematic, to avoid TDZ)
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!e.ctrlKey && !e.metaKey) return;
      if (isInteractiveKeyboardTarget(e.target)) return;
      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyA' && editorMode === 'artist' && imageData) {
        e.preventDefault();
        setSelectionMask(selectAllMask(imageData.width, imageData.height));
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyD' && editorMode === 'artist') {
        e.preventDefault();
        setSelectionMask(null);
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyI' && editorMode === 'artist' && imageData) {
        e.preventDefault();
        handleInvertSelection();
        return;
      }
      if (!e.shiftKey && e.code === 'KeyZ') { e.preventDefault(); handleUndo(); return; }
      if (e.code === 'KeyY' || (e.shiftKey && e.code === 'KeyZ')) { e.preventDefault(); handleRedo(); return; }
      if (!e.shiftKey && e.code === 'KeyS') { e.preventDefault(); handleExportPng(); return; }
      if (e.shiftKey && e.code === 'KeyS') { e.preventDefault(); handleExportLitematic(); return; }
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [handleUndo, handleRedo, handleExportPng, handleExportLitematic, editorMode, imageData, handleInvertSelection]);

  // ── Reset all settings to defaults ───────────────────────────────────────
  const handleResetDefaults = useCallback(() => {
    clearSettings();
    const normalizedBuild = normalizeIncomingBuildState(
      sanitizeSelectionForPlatform(DEFAULT_SELECTION, latestRef.current.platformMode),
      '2d',
    );
    setDithering('floyd-steinberg');
    setIntensity(100);
    setBnScale(2);
    setMapGrid({ wide: 1, tall: 1 });
    setBlockSelection(normalizedBuild.blockSelection);
    setAdjustments(DEFAULT_ADJUSTMENTS);
    setColorMatch(DEFAULT_COLOR_MATCH);
    setMapMode(normalizedBuild.mapMode);
    setMinecraftVersion(normalizedBuild.minecraftVersion);
    if (sourceImage) {
      const shades = normalizedBuild.mapMode === '2d' ? [1] : [0, 1, 2];
      const palette = buildComputedPalette(buildPaletteFromSelection(
        normalizedBuild.blockSelection,
        shades,
        normalizedBuild.minecraftVersion,
        normalizedBuild.platformMode,
      ), DEFAULT_COLOR_MATCH);
      runProcess(sourceImage, 'floyd-steinberg', { wide: 1, tall: 1 }, 100, compareMode, compareLeft, compareRight, palette, DEFAULT_ADJUSTMENTS, 2, DEFAULT_KLUSS_PARAMS);
    }
  }, [sourceImage, compareMode, compareLeft, compareRight, normalizeIncomingBuildState, runProcess]);

  // ── Load from ?palette= URL param (runs once on mount) ───────────────────
  // ?share= and ?example= take priority because they restore their own settings.
  useEffect(() => {
    const params   = new URLSearchParams(window.location.search);
    const shareId  = params.get('share');
    const exampleId = params.get('example');
    const paletteQ = params.get(PALETTE_PARAM);
    if (shareId || exampleId || params.get('companionImport') || params.get('artVersion') || params.get('art') || !paletteQ) return;
    const sel = decodePalette(paletteQ);
    if (!sel) return;
    setBlockSelection(normalizeIncomingBuildState(sel, latestRef.current.mapMode).blockSelection);
    setPaletteBanner(true);
  }, [normalizeIncomingBuildState]);

  // ── Load from ?share= URL param (runs once on mount) ──────────────────────
  // Using a ref to prevent double-execution in React StrictMode
  const linkLoadedRef = useRef(false);
  useEffect(() => {
    if (linkLoadedRef.current) return;
    const params = new URLSearchParams(window.location.search);
    const linkId = params.get('share');
    if (params.get('companionImport') || params.get('artVersion') || params.get('art') || !linkId) return;
    linkLoadedRef.current = true;

    loadShare(linkId).then(result => {
      if (!result) return;
      const s = result.settings;
      // Restore settings
      if (s.dithering)       setDithering(coerceDitheringMode(s.dithering));
      if (s.intensity != null)  setIntensity(s.intensity);
      if (s.bnScale != null)    setBnScale(s.bnScale);
      if (s.mapGrid)         setMapGrid(s.mapGrid);
      const normalizedBuild = normalizeRestoredBuildState({
        mapMode: s.mapMode ?? '2d',
        buildTechnique: s.buildTechnique,
        minecraftVersion: s.minecraftVersion ?? '1.21.4',
        platformMode: s.platformMode ?? 'java',
        blockSelection: s.blockSelection ?? DEFAULT_SELECTION,
      });
      setBlockSelection(normalizedBuild.blockSelection);
      if (s.adjustments)     setAdjustments(normalizeAdjustments(s.adjustments));
      if (s.colorMatch)      setColorMatch(coerceColorMatchMode(s.colorMatch));
      setMapMode(normalizedBuild.mapMode);
      setMinecraftVersion(normalizedBuild.minecraftVersion);
      setPlatformMode(normalizedBuild.platformMode);
      setBuildTechnique(normalizedBuild.buildTechnique);
      setSupportBlock(normalizedBuild.buildTechnique === 'suppression_two_layer'
        ? sanitizeSuppressionSupportBlock(s.supportBlock ?? 'stone')
        : (s.supportBlock ?? 'stone'));
      if (s.supportMode === 1 || s.supportMode === 2 || s.supportMode === 3) {
        setSupportMode(s.supportMode);
      }
      if (s.staircaseMode) setStaircaseMode(s.staircaseMode);
      standardBuildSnapshotRef.current = null;

      // Load source image from storage
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        setSourceImage(img);
        setViewBanner(true);
        setUndoStack([]);
        setRedoStack([]);
        const shades = normalizedBuild.mapMode === '2d' ? [1] : [0, 1, 2];
        const palette = buildComputedPalette(
          buildPaletteFromSelection(
            normalizedBuild.blockSelection,
            shades,
            normalizedBuild.minecraftVersion,
            normalizedBuild.platformMode,
          ),
          coerceColorMatchMode(s.colorMatch),
        );
        runProcess(
          img,
          s.dithering       ?? 'floyd-steinberg',
          s.mapGrid         ?? { wide: 1, tall: 1 },
          s.intensity       ?? 100,
          false,
          'floyd-steinberg',
          'yliluoma2',
          palette,
          s.adjustments     ?? DEFAULT_ADJUSTMENTS,
          s.bnScale         ?? 2,
          DEFAULT_KLUSS_PARAMS,
        );
      };
      img.src = result.imageUrl;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Load from ?example= URL param (runs once on mount) ───────────────────
  // Runs after ?share= priority check; examples are static and do not use Supabase.
  const exampleLoadedRef = useRef(false);
  useEffect(() => {
    if (exampleLoadedRef.current) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('share') || params.get('companionImport') || params.get('artVersion') || params.get('art')) return;
    const example = getExampleById(params.get('example'));
    if (!example) return;
    exampleLoadedRef.current = true;

    const { trySettings } = example;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const current = latestRef.current;
      const normalizedBuild = normalizeRestoredBuildState({
        mapMode: trySettings.mapMode,
        buildTechnique: 'standard',
        minecraftVersion: current.minecraftVersion,
        platformMode: current.platformMode,
        blockSelection: current.blockSelection,
      });
      uploadedFileRef.current = null;
      uploadedImageRef.current = img;
      setSourceImage(img);
      setOriginalData(null);
      setCompareData(null);
      setDithering(trySettings.dithering);
      setIntensity(trySettings.intensity);
      setMapGrid(trySettings.mapGrid);
      setMapMode(normalizedBuild.mapMode);
      setMinecraftVersion(normalizedBuild.minecraftVersion);
      setPlatformMode(normalizedBuild.platformMode);
      setBuildTechnique(normalizedBuild.buildTechnique);
      setBlockSelection(normalizedBuild.blockSelection);
      standardBuildSnapshotRef.current = null;
      setStaircaseMode(trySettings.staircaseMode);
      setBnScale(trySettings.bnScale);
      setViewBanner(true);
      setUndoStack([]);
      setRedoStack([]);
      setLayerState(prev => ({
        ...prev,
        layers: prev.layers.map(l => l.id === prev.activeLayerId ? {
          ...l,
          sourceImage: img,
          sourceFile: null,
          sourceUploadedImage: img,
          dithering: trySettings.dithering,
          mapMode: normalizedBuild.mapMode,
          staircaseMode: trySettings.staircaseMode,
          isDirty: false,
        } : l),
      }));
      const shades = normalizedBuild.mapMode === '2d' ? [1] : [0, 1, 2];
      const palette = buildComputedPalette(buildPaletteFromSelection(
        normalizedBuild.blockSelection,
        shades,
        normalizedBuild.minecraftVersion,
        normalizedBuild.platformMode,
      ), colorMatch);
      runProcess(
        img,
        trySettings.dithering,
        trySettings.mapGrid,
        trySettings.intensity,
        false,
        compareLeft,
        compareRight,
        palette,
        effectiveAdjustments,
        trySettings.bnScale,
        klussParams,
      );
    };
    img.src = example.originalUrl;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const switchTourStep = useCallback((tab: 'settings' | 'palette' | 'export') => {
    setMobileTab(tab);
    const tablet = window.matchMedia('(min-width: 768px) and (max-width: 1099px)').matches;
    if (tab === 'settings') {
      setLeftPanelCollapsed(false);
      if (tablet) setTabletRightOpen(false);
    } else {
      setRightPanelCollapsed(false);
      if (tablet) setTabletRightOpen(true);
    }
  }, []);

  // ── Onboarding tour ───────────────────────────────────────────────────────
  const startTour = useCallback((tourType: TourType) => {
    setCollapsedSections(previous => ({
      ...previous,
      'map-grid': false,
      'map-mode': false,
      dithering: false,
      adjustments: false,
    }));
    const tutorialType = `tour_${tourType.replace('-', '_')}`;
    trackEvent('tutorial_opened', { tutorial_type: tutorialType, lang });
    createTour(tourType, {
      lang,
      switchTab: switchTourStep,
      onComplete: completedTour => trackEvent('tutorial_completed', { tutorial_type: `tour_${completedTour.replace('-', '_')}`, lang }),
      onDismiss: dismissedTour => trackEvent('tutorial_dismissed', { tutorial_type: `tour_${dismissedTour.replace('-', '_')}`, lang }),
    }).drive();
  }, [lang, switchTourStep]);
  useEffect(() => {
    if (suppressAutoTour || showAnnouncement) return;
    if (shouldAutoStart()) {
      const timer = setTimeout(() => {
        setTourSelectorIsWelcome(true);
        setShowTourSelector(true);
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [showAnnouncement, suppressAutoTour]);

  const closeTourSelector = useCallback(() => {
    markTourOfferDismissed();
    setShowTourSelector(false);
    setTourSelectorIsWelcome(false);
  }, []);

  // ── Import map.dat ────────────────────────────────────────────────────────
  const handleDatFile = useCallback(async (file: File) => {
    try {
      const importedImageData = await importMapDat(file);
      // Set the grid to 1×1 (one map = 128×128)
      setMapGrid({ wide: 1, tall: 1 });
      // Put the imported imageData directly into the active layer (skip re-processing)
      setLayerState(prev => ({
        ...prev,
        layers: prev.layers.map(l =>
          l.id === prev.activeLayerId
            ? { ...l, imageData: importedImageData, isDirty: true, sourceImage: undefined }
            : l
        ),
      }));
      setImageData(importedImageData);
    } catch (e) {
      const msg = e instanceof MapDatImportError ? e.message : t('Не удалось прочитать map.dat.', 'Failed to read map.dat.');
      showAppNotice(msg, 'error');
    }
  }, [showAppNotice, t]);

  // ── Import GIF ───────────────────────────────────────────────────────────
  const handleGifFile = useCallback(async (file: File) => {
    try {
      const decoded = await decodeGif(file);
      setGifFrames(decoded);
    } catch (e) {
      showAppNotice(t('Не удалось прочитать GIF.', 'Could not read GIF.') + ' ' + String(e), 'error');
    }
  }, [showAppNotice, t]);

  const baseScale    = gridScale(mapGrid);
  const zoomFactor   = zoom / 100;
  const displayScale = Math.max(1, baseScale * zoomFactor);
  const rasterScale  = Math.max(1, Math.min(8, Math.round(displayScale)));
  const pw = gridPixelWidth(mapGrid);
  const ph = gridPixelHeight(mapGrid);

  // Composite of all visible layers — used for export and MaterialsList
  const compositeImageData: ImageData | null = useMemo(() => {
    const hasAny = layers.some(l => l.visible && l.imageData);
    if (!hasAny) return null;
    return compositeLayersToImageData(layers, pw, ph);
  }, [layers, pw, ph]);
  const previewLayers = useMemo(() => layers
    .filter(layer => layer.visible && layer.imageData)
    .map(layer => ({
      imageData: layer.imageData!,
      mapMode: layer.mapMode ?? '2d',
      staircaseMode: layer.staircaseMode ?? 'optimized',
    })), [layers]);

  const finalPreview = useMemo(() => buildFinalPreview(previewLayers, activePalette), [previewLayers, activePalette]);
  const previewImageData = finalPreview?.displayImage ?? compositeImageData;

  // Composite of all visible layers EXCEPT the active one — shown as backdrop during painting
  const otherLayersData: ImageData | null = useMemo(() => {
    const others = layers.filter(l => l.id !== activeLayerId && l.visible && l.imageData);
    if (others.length === 0) return null;
    return compositeLayersToImageData(others, pw, ph);
  }, [layers, activeLayerId, pw, ph]);

  const sessionMaterials = useMemo<SessionMaterial[]>(() => {
    if (!compositeImageData) return [];
    return computeSessionMaterials(compositeImageData, activePalette, blockSelection, mapGrid);
  }, [compositeImageData, activePalette, blockSelection, mapGrid]);

  // Keep exportRef current (uses composite so Ctrl+Shift+S exports all visible layers)
  exportRef.current = { imageData: previewImageData, dithering, mapGrid, activePalette, blockSelection, mapMode, staircaseMode, layers };

  const hasContent = compositeImageData !== null || compareData !== null;

  const updateCanvasZoom = useCallback((nextValue: number, point?: { clientX: number; clientY: number }) => {
    const nextZoom = clampCanvasZoom(Math.round(nextValue * 10) / 10);
    if (Math.abs(nextZoom - zoom) < 0.01) return;

    const area = canvasAreaRef.current;
    const canvas = area?.querySelector<HTMLCanvasElement>('.map-canvas');
    if (area && canvas && hasContent) {
      const areaRect = area.getBoundingClientRect();
      const canvasRect = canvas.getBoundingClientRect();
      const clientX = point?.clientX ?? areaRect.left + area.clientWidth / 2;
      const clientY = point?.clientY ?? areaRect.top + area.clientHeight / 2;
      pendingZoomAnchorRef.current = {
        clientX,
        clientY,
        xRatio: canvasRect.width > 0 ? (clientX - canvasRect.left) / canvasRect.width : 0.5,
        yRatio: canvasRect.height > 0 ? (clientY - canvasRect.top) / canvasRect.height : 0.5,
      };
    } else {
      pendingZoomAnchorRef.current = null;
    }
    setZoom(nextZoom);
  }, [hasContent, zoom]);

  useLayoutEffect(() => {
    const anchor = pendingZoomAnchorRef.current;
    const area = canvasAreaRef.current;
    if (!anchor || !area) return;
    const canvas = area.querySelector<HTMLCanvasElement>('.map-canvas');
    if (!canvas) return;
    const canvasRect = canvas.getBoundingClientRect();
    area.scrollLeft += canvasRect.left + anchor.xRatio * canvasRect.width - anchor.clientX;
    area.scrollTop += canvasRect.top + anchor.yRatio * canvasRect.height - anchor.clientY;
    pendingZoomAnchorRef.current = null;
  }, [zoom]);

  const canvasWheelHandlerRef = useRef<(event: WheelEvent) => void>(() => undefined);
  canvasWheelHandlerRef.current = (event) => {
    const area = canvasAreaRef.current;
    if (!area || !hasContent || (!event.ctrlKey && !event.metaKey)) return;
    event.preventDefault();
    updateCanvasZoom(
      canvasZoomFromWheel(zoom, event.deltaY, event.deltaMode, area.clientHeight),
      { clientX: event.clientX, clientY: event.clientY },
    );
  };

  useEffect(() => {
    const area = canvasAreaRef.current;
    if (!area) return;
    const onWheel = (event: WheelEvent) => canvasWheelHandlerRef.current(event);
    area.addEventListener('wheel', onWheel, { passive: false });
    return () => area.removeEventListener('wheel', onWheel);
  }, []);

  useEffect(() => {
    const stopSpacePan = () => {
      spacePanRef.current = false;
      setIsSpacePanActive(false);
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.code !== 'Space' || !hasContent || isInteractiveKeyboardTarget(event.target)) return;
      event.preventDefault();
      if (spacePanRef.current) return;
      spacePanRef.current = true;
      setIsSpacePanActive(true);
    };
    const handleKeyUp = (event: KeyboardEvent) => {
      if (event.code === 'Space') stopSpacePan();
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', stopSpacePan);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', stopSpacePan);
    };
  }, [hasContent]);

  const handleCanvasPointerDown = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    if (suppressCanvasClickTimerRef.current !== null) {
      window.clearTimeout(suppressCanvasClickTimerRef.current);
      suppressCanvasClickTimerRef.current = null;
    }
    suppressCanvasClickRef.current = false;
    const target = event.target instanceof Element ? event.target : null;
    const forcedBySpace = spacePanRef.current;
    if (
      !hasContent
      || !canStartCanvasPan(activeTool !== null, compareMode, forcedBySpace)
      || event.pointerType === 'touch'
      || event.button !== 0
      || event.altKey
      || target?.closest('.split-divider, button, input, select, textarea, a, [role="button"]')
    ) return;

    if (forcedBySpace) {
      event.preventDefault();
      event.stopPropagation();
    }

    canvasPanRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      startScrollLeft: event.currentTarget.scrollLeft,
      startScrollTop: event.currentTarget.scrollTop,
      moved: false,
      forcedBySpace,
    };
  }, [activeTool, compareMode, hasContent]);

  const handleCanvasPointerMove = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    const pan = canvasPanRef.current;
    if (!pan || pan.pointerId !== event.pointerId) return;
    if (pan.forcedBySpace) event.stopPropagation();
    const dx = event.clientX - pan.startX;
    const dy = event.clientY - pan.startY;
    if (!pan.moved && hasCanvasPanStarted(pan.startX, pan.startY, event.clientX, event.clientY)) {
      pan.moved = true;
      // Capturing on pointerdown retargets an ordinary click to the viewport;
      // wait until this gesture is definitely a pan so block clicks still pin.
      event.currentTarget.setPointerCapture(event.pointerId);
      event.currentTarget.classList.add('canvas-area-panning');
      event.currentTarget.dispatchEvent(new CustomEvent('mapkluss:viewport-pan-start'));
      setIsCanvasPanning(true);
    }
    if (!pan.moved) return;
    event.preventDefault();
    event.currentTarget.scrollLeft = pan.startScrollLeft - dx;
    event.currentTarget.scrollTop = pan.startScrollTop - dy;
  }, []);

  const finishCanvasPan = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    const pan = canvasPanRef.current;
    if (!pan || pan.pointerId !== event.pointerId) return;
    if (pan.forcedBySpace) event.stopPropagation();
    suppressCanvasClickRef.current = pan.moved;
    if (pan.moved) {
      event.currentTarget.dispatchEvent(new CustomEvent('mapkluss:viewport-pan-end', {
        detail: { clientX: event.clientX, clientY: event.clientY },
      }));
      // Some browsers omit click after a drag. Bound the suppression so it can
      // never swallow the user's next deliberate click.
      suppressCanvasClickTimerRef.current = window.setTimeout(() => {
        suppressCanvasClickRef.current = false;
        suppressCanvasClickTimerRef.current = null;
      }, 250);
    }
    canvasPanRef.current = null;
    event.currentTarget.classList.remove('canvas-area-panning');
    setIsCanvasPanning(false);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
  }, []);

  const handleCanvasClickCapture = useCallback((event: React.MouseEvent<HTMLDivElement>) => {
    if (!suppressCanvasClickRef.current) return;
    suppressCanvasClickRef.current = false;
    if (suppressCanvasClickTimerRef.current !== null) {
      window.clearTimeout(suppressCanvasClickTimerRef.current);
      suppressCanvasClickTimerRef.current = null;
    }
    event.preventDefault();
    event.stopPropagation();
  }, []);

  const buildCurrentCloudProjectJson = useCallback(() => {
    const settings: FullProjectSettings = {
      dithering,
      intensity,
      blockSelection: blockSelection as Record<string, number[]>,
      adjustments,
      colorMatch,
      mapMode,
      staircaseMode,
      bnScale,
      klussParams,
      originalDataB64: originalDataRef.current ? imageDataToBase64(originalDataRef.current) : undefined,
      minecraftVersion,
      platformMode,
      buildTechnique,
      supportBlock,
      supportMode,
    };
    return serializeFullProject(layers, activeLayerId, mapGrid, settings, layerGroups);
  }, [activeLayerId, adjustments, blockSelection, bnScale, buildTechnique, colorMatch, dithering, intensity, klussParams, layerGroups, layers, mapGrid, mapMode, minecraftVersion, platformMode, staircaseMode, supportBlock, supportMode]);

  const handleCloudSignInFromEditor = useCallback(async () => {
    setShowCloudArtsPanel(true);
    showAppNotice(t('Войди в аккаунт MapKluss в папке артов.', 'Sign in to MapKluss from the arts folder.'));
  }, [showAppNotice, t]);

  const handleSaveCurrentArtToCloud = useCallback(async () => {
    if (cloudSaving) return;
    const outputImage = previewImageData ?? compositeImageData;
    if (!outputImage) {
      showAppNotice(t('Сначала загрузи или создай арт.', 'Create or load an art first.'), 'error');
      return;
    }

    setCloudSaving(true);
    try {
      const user = await getCurrentCompanionSessionUser();
      if (!user) {
        setCloudSaving(false);
        await handleCloudSignInFromEditor();
        return;
      }
      setCloudUserEmail(user.email);

      setShowCloudSaveModal(true);
    } catch (err) {
      console.error('Cloud save preparation failed', err);
      showAppNotice(err instanceof Error ? err.message : t('Не удалось подготовить сохранение в облако.', 'Could not prepare Cloud save.'), 'error');
    } finally {
      setCloudSaving(false);
    }
  }, [cloudSaving, compositeImageData, handleCloudSignInFromEditor, previewImageData, showAppNotice, t, setCloudSaving, setCloudUserEmail]);

  const handleConfirmCloudSave = useCallback(async ({ title, privacy }: { title: string; privacy: ArtPrivacy }) => {
    if (cloudSaving) return;
    const outputImage = previewImageData ?? compositeImageData;
    if (!outputImage) {
      showAppNotice(t('Сначала загрузи или создай арт.', 'Create or load an art first.'), 'error');
      return;
    }

    setCloudSaving(true);
    const saveKind = currentCloudArtId ? 'update' : 'create';
    try {
      setShowCloudSaveModal(false);
      await new Promise<void>(resolve => window.requestAnimationFrame(() => resolve()));
      const projectJson = buildCurrentCloudProjectJson();
      const manifest = await saveCompanionArt({
        artId: currentCloudArtId ?? undefined,
        title,
        privacy,
        projectJson,
        // Keep Cloud construction artifacts byte-for-byte aligned with the
        // same composite buffer used by local exports. The preview may use a
        // display-specific buffer, but must not change Two-layer tile hashes.
        imageData: compositeImageData ?? outputImage,
        previewImageData: outputImage,
        grid: mapGrid,
        mode: mapMode,
        staircaseMode,
        supportBlock,
        supportMode,
        palette: activePalette,
        blockSelection,
        minecraftVersion,
        dithering,
        intensity,
        bnScale,
        klussParams,
        platformMode,
        buildTechnique,
      });

      void setCompanionFavorite(manifest.artId, true).catch(favoriteError => {
        console.warn('Failed to add saved cloud art to favorites', favoriteError);
      });
      let importAttached = true;
      if (currentCloudImportId) {
        try {
          await attachCompanionImportToArt(currentCloudImportId, manifest.artId);
        } catch (attachError) {
          importAttached = false;
          console.warn('Failed to attach import to saved cloud art', attachError);
        }
      }

      setCurrentCloudArtId(manifest.artId);
      setCurrentCloudTitle(manifest.title);
      setCurrentCloudPrivacy(manifest.privacy);
      window.history.replaceState(null, '', detachEditorUrlFromCloudSource(window.location.href));
      trackEvent('cloud_save_completed', {
        save_kind: saveKind,
        privacy,
        map_mode: mapMode,
        map_wide: mapGrid.wide,
        map_tall: mapGrid.tall,
        source_kind: currentCloudImportId ? 'companion_import' : 'editor',
        import_attached: importAttached,
        save_total_ms: manifest.saveTiming ? Math.round(manifest.saveTiming.totalMs / 100) * 100 : undefined,
        save_generation_ms: manifest.saveTiming ? Math.round(manifest.saveTiming.generationMs / 100) * 100 : undefined,
        save_hash_ms: manifest.saveTiming ? Math.round(manifest.saveTiming.hashMs / 100) * 100 : undefined,
        save_prepare_ms: manifest.saveTiming ? Math.round(manifest.saveTiming.prepareMs / 100) * 100 : undefined,
        save_upload_ms: manifest.saveTiming ? Math.round(manifest.saveTiming.uploadMs / 100) * 100 : undefined,
        save_finalize_ms: manifest.saveTiming ? Math.round(manifest.saveTiming.finalizeMs / 100) * 100 : undefined,
        artifact_count: manifest.saveTiming?.artifactCount,
        payload_kib: manifest.saveTiming ? Math.ceil(manifest.saveTiming.totalBytes / 1024) : undefined,
      });
      showAppNotice(importAttached
        ? t('Арт сохранён в облако.', 'Art saved to Cloud.')
        : t(
            'Арт сохранён, но запись импорта пока не привязалась. Обнови страницу Cloud и попробуй ещё раз.',
            'The art was saved, but the import record was not linked yet. Refresh Cloud and try again.',
          ), importAttached ? 'info' : 'error');
      setMinecraftContinuation({ source: 'cloud', minecraftVersion });
      minecraftContinuationDismissedRef.current = false;
    } catch (err) {
      console.error('Cloud save failed', err);
      trackEvent('cloud_save_failed', { save_kind: saveKind, failure_stage: 'save' });
      showAppNotice(err instanceof Error ? err.message : t('Не удалось сохранить арт в облако.', 'Could not save art to Cloud.'), 'error');
    } finally {
      setCloudSaving(false);
    }
  }, [activePalette, blockSelection, bnScale, buildCurrentCloudProjectJson, buildTechnique, cloudSaving, compositeImageData, currentCloudArtId, currentCloudImportId, dithering, intensity, klussParams, mapGrid, mapMode, minecraftVersion, platformMode, previewImageData, showAppNotice, staircaseMode, supportBlock, supportMode, t, setCloudSaving, setCurrentCloudArtId, setCurrentCloudTitle, setCurrentCloudPrivacy, setMinecraftContinuation]);

  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Control') setShowShadeWarnings(true);
    }
    function handleKeyUp(e: KeyboardEvent) {
      if (e.key === 'Control') setShowShadeWarnings(false);
    }
    function handleBlur() {
      setShowShadeWarnings(false);
    }
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', handleBlur);
    };
  }, []);

  // ── Project history (IndexedDB) ──────────────────────────────────────────────
  // Declared after compositeImageData to avoid TDZ in the thumbnail handler.

  const handleOpenSaveModal = useCallback(() => {
    if (!compositeImageData) {
      setSaveThumbnail(null);
      setShowSaveModal(true);
      return;
    }
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 128;
      canvas.height = 128;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const tmpCanvas = document.createElement('canvas');
        tmpCanvas.width = compositeImageData.width;
        tmpCanvas.height = compositeImageData.height;
        const tmpCtx = tmpCanvas.getContext('2d');
        if (tmpCtx) {
          tmpCtx.putImageData(compositeImageData, 0, 0);
          ctx.drawImage(tmpCanvas, 0, 0, 128, 128);
        }
      }
      setSaveThumbnail(canvas.toDataURL('image/png'));
    } catch (err) {
      console.error('Thumbnail generation failed', err);
      setSaveThumbnail(null);
    }
    setShowSaveModal(true);
  }, [compositeImageData]);

  const handleSaveProjectToHistory = useCallback(async (name: string) => {
    try {
      const settings: FullProjectSettings = {
        dithering,
        intensity,
        blockSelection: blockSelection as Record<string, number[]>,
        adjustments,
        colorMatch,
        mapMode,
        staircaseMode,
        bnScale,
        klussParams,
        originalDataB64: originalDataRef.current ? imageDataToBase64(originalDataRef.current) : undefined,
        minecraftVersion,
        platformMode,
        buildTechnique,
        supportBlock,
        supportMode,
      };
      const data = serializeFullProject(layers, activeLayerId, mapGrid, settings, layerGroups);
      const id = Date.now().toString();
      await saveProject({ id, name, timestamp: Date.now(), thumbnail: saveThumbnail ?? '', data });
      showAppNotice(t('Проект сохранён в истории.', 'Project saved to history.'));
    } catch (err) {
      console.error('Failed to save project to history', err);
      showAppNotice(t('Не удалось сохранить проект в историю.', 'Could not save project to history.'), 'error');
    }
  }, [layers, activeLayerId, layerGroups, mapGrid, dithering, intensity, blockSelection, adjustments, colorMatch, mapMode, staircaseMode, bnScale, klussParams, minecraftVersion, platformMode, buildTechnique, supportBlock, supportMode, saveThumbnail, showAppNotice, t]);

  const handleLoadProjectFromHistory = useCallback(async (id: string) => {
    try {
      const stored = await loadProject(id);
      if (!stored) { console.error('Project not found:', id); return; }
      const result = deserializeFullProject(stored.data);
      if (!result) { console.error('Failed to deserialize project', id); return; }
      const restoredBuild = normalizeRestoredBuildState({
        mapMode: result.settings.mapMode,
        buildTechnique: result.settings.buildTechnique,
        minecraftVersion: result.settings.minecraftVersion ?? '1.21.4',
        platformMode: result.settings.platformMode ?? 'java',
        blockSelection: result.settings.blockSelection as BlockSelection,
      });
      setMapGrid(result.grid);
      // Mark all layers dirty so runProcess never overwrites restored content.
      // Also stamp per-layer mapMode/staircaseMode/dithering so the useEffect([activeLayerId])
      // that syncs these fields from the active layer reads the correct saved values.
      // If originalDataB64 was saved, we can allow reprocessing (isDirty=false)
      // Otherwise mark dirty to prevent accidental overwrites during load
      const canReprocess = !!result.settings.originalDataB64;
      const restoredLayers = result.layers.map(l => ({
        ...l,
        isDirty: l.isDirty ?? !canReprocess,
        mapMode: restoredBuild.buildTechnique === 'suppression_two_layer' ? '3d' : (l.mapMode ?? restoredBuild.mapMode),
        staircaseMode: l.staircaseMode ?? result.settings.staircaseMode,
        dithering: coerceDitheringMode(l.dithering ?? result.settings.dithering),
      }));
      setLayerState({ layers: restoredLayers, activeLayerId: result.activeLayerId, groups: result.groups });
      setDithering(coerceDitheringMode(result.settings.dithering));
      setIntensity(result.settings.intensity);
      setBlockSelection(restoredBuild.blockSelection);
      setAdjustments(normalizeAdjustments(result.settings.adjustments));
      setColorMatch(coerceColorMatchMode(result.settings.colorMatch));
      setMapMode(restoredBuild.mapMode);
      setStaircaseMode(result.settings.staircaseMode);
      setBnScale(result.settings.bnScale);
      setKlussParams(result.settings.klussParams ?? DEFAULT_KLUSS_PARAMS);
      setMinecraftVersion(restoredBuild.minecraftVersion);
      setPlatformMode(restoredBuild.platformMode);
      setBuildTechnique(restoredBuild.buildTechnique);
      setSupportBlock(restoredBuild.buildTechnique === 'suppression_two_layer'
        ? sanitizeSuppressionSupportBlock(result.settings.supportBlock ?? 'stone')
        : (result.settings.supportBlock ?? 'stone'));
      setSupportMode(result.settings.supportMode ?? 2);

      // Restore originalData (pre-dithering image) if it was saved, and create virtual sourceImage for reprocessing
      if (result.settings.originalDataB64) {
        const w = result.grid.wide * 128;
        const h = result.grid.tall * 128;
        const restoredOriginalData = base64ToImageData(result.settings.originalDataB64, w, h);
        setOriginalData(restoredOriginalData);
        // Create virtual source image for reprocessing when settings change
        const sourceImg = await imageDataToSourceImage(restoredOriginalData);
        setSourceImage(sourceImg);
      } else {
        setSourceImage(null);
        setOriginalData(null);
      }

      setCompareData(null);
      setUndoStack([]);
      setRedoStack([]);
      setShowProjectsPanel(false);
      showAppNotice(t('Проект открыт из истории.', 'Project opened from history.'));
    } catch (err) {
      console.error('Failed to load project from history', err);
      showAppNotice(t('Не удалось открыть проект из истории.', 'Could not open project from history.'), 'error');
    }
  }, [showAppNotice, t, setSupportBlock, setSupportMode]);

  const applyProjectJsonToEditor = useCallback(async (json: string, successMessage?: string) => {
    const full = deserializeFullProject(json);
    if (full) {
      const restoredBuild = normalizeRestoredBuildState({
        mapMode: full.settings.mapMode,
        buildTechnique: full.settings.buildTechnique,
        minecraftVersion: full.settings.minecraftVersion ?? '1.21.4',
        platformMode: full.settings.platformMode ?? 'java',
        blockSelection: full.settings.blockSelection as BlockSelection,
      });
      setMapGrid(full.grid);
      const canReprocess = !!full.settings.originalDataB64;
      const restoredLayers = full.layers.map(layer => ({
        ...layer,
        isDirty: layer.isDirty ?? !canReprocess,
        mapMode: restoredBuild.buildTechnique === 'suppression_two_layer' ? '3d' : (layer.mapMode ?? restoredBuild.mapMode),
        staircaseMode: layer.staircaseMode ?? full.settings.staircaseMode,
        dithering: coerceDitheringMode(layer.dithering ?? full.settings.dithering),
      }));
      setLayerState({ layers: restoredLayers, activeLayerId: full.activeLayerId, groups: full.groups });
      setDithering(coerceDitheringMode(full.settings.dithering));
      setIntensity(full.settings.intensity);
      setBlockSelection(restoredBuild.blockSelection);
      setAdjustments(normalizeAdjustments(full.settings.adjustments));
      setColorMatch(coerceColorMatchMode(full.settings.colorMatch));
      setMapMode(restoredBuild.mapMode);
      setStaircaseMode(full.settings.staircaseMode);
      setBnScale(full.settings.bnScale);
      setKlussParams(full.settings.klussParams ?? DEFAULT_KLUSS_PARAMS);
      setMinecraftVersion(restoredBuild.minecraftVersion);
      setPlatformMode(restoredBuild.platformMode);
      setBuildTechnique(restoredBuild.buildTechnique);
      setSupportBlock(restoredBuild.buildTechnique === 'suppression_two_layer'
        ? sanitizeSuppressionSupportBlock(full.settings.supportBlock ?? 'stone')
        : (full.settings.supportBlock ?? 'stone'));
      setSupportMode(full.settings.supportMode ?? 2);

      if (full.settings.originalDataB64) {
        const width = full.grid.wide * 128;
        const height = full.grid.tall * 128;
        const restoredOriginalData = base64ToImageData(full.settings.originalDataB64, width, height);
        setOriginalData(restoredOriginalData);
        const sourceImg = await imageDataToSourceImage(restoredOriginalData);
        uploadedFileRef.current = null;
        uploadedImageRef.current = sourceImg;
        setSourceImage(sourceImg);
      } else {
        uploadedFileRef.current = null;
        uploadedImageRef.current = null;
        setSourceImage(null);
        setOriginalData(null);
      }

      setCompareData(null);
      setUndoStack([]);
      setRedoStack([]);
      if (successMessage) showAppNotice(successMessage);
      return true;
    }

    const basic = deserializeProject(json);
    if (!basic) return false;

    uploadedFileRef.current = null;
    uploadedImageRef.current = null;
    setMapGrid(basic.grid);
    setLayerState({ layers: basic.layers, activeLayerId: basic.activeLayerId, groups: [] });
    setSourceImage(null);
    setOriginalData(null);
    setCompareData(null);
    setUndoStack([]);
    setRedoStack([]);
    if (successMessage) showAppNotice(successMessage);
    return true;
  }, [showAppNotice, setSupportBlock, setSupportMode]);
  applyProjectJsonRef.current = applyProjectJsonToEditor;

  const estimateCurrentAutosaveBytes = useCallback(
    () => estimateAutosaveSnapshotBytes(layers, originalDataRef.current),
    [layers],
  );
  const autosaveState = useEditorAutosave({
    hasContent,
    processing,
    serializeProject: buildCurrentCloudProjectJson,
    estimateBytes: estimateCurrentAutosaveBytes,
    notify: showAppNotice,
  });
  const autosaveLabel = useMemo(() => {
    const time = autosaveState.savedAt
      ? new Date(autosaveState.savedAt).toLocaleTimeString(lang === 'ru' ? 'ru-RU' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
      })
      : '';
    switch (autosaveState.status) {
      case 'pending': return t('АВТОСОХРАНЕНИЕ ОЖИДАЕТ', 'AUTOSAVE PENDING');
      case 'saving': return t('СОХРАНЕНИЕ…', 'SAVING…');
      case 'saved': return t(`СОХРАНЕНО ${time}`, `SAVED ${time}`);
      case 'too-large': return t('АВТОСОХРАНЕНИЕ НЕДОСТУПНО', 'AUTOSAVE UNAVAILABLE');
      case 'error': return t('ОШИБКА АВТОСОХРАНЕНИЯ', 'AUTOSAVE ERROR');
      default: return '';
    }
  }, [autosaveState.savedAt, autosaveState.status, lang, t]);

  const applyImportedImageToEditor = useCallback((
    img: HTMLImageElement,
    grid: MapGrid,
    successMessage?: string,
  ) => {
    const importedImageData = imageToImageData(img);
    uploadedFileRef.current = null;
    uploadedImageRef.current = img;
    setMapGrid(grid);
    setSourceImage(img);
    setOriginalData(null);
    setCompareData(null);
    setUndoStack([]);
    setRedoStack([]);
    setLayerState(prev => ({
      ...prev,
      layers: prev.layers.map(layer => layer.id === prev.activeLayerId ? {
        ...layer,
        imageData: importedImageData,
        sourceImage: img,
        sourceFile: null,
        sourceUploadedImage: img,
        isDirty: true,
      } : layer),
    }));
    if (successMessage) showAppNotice(successMessage);
  }, [showAppNotice]);

  const cloudImportLoadedRef = useRef(false);
  const handleCloudImport = useCallback(async () => {
    const params = new URLSearchParams(window.location.search);
    const importId = params.get('companionImport');
    const versionId = params.get('artVersion');
    const artId = params.get('art');

    if (!importId && !versionId && !artId) return;

    setLoadedCloudVersionId(null);

    try {
      if (importId) {
        const scanImport = await getCompanionScanImport(importId);
        if (!scanImport.signedUrl) throw new Error('Scan import image is not available.');
        const img = await loadHtmlImage(scanImport.signedUrl);
        setCurrentCloudImportId(scanImport.importId);
        setCurrentCloudArtId(scanImport.createdArtId ?? null);
        setCurrentCloudTitle(scanImport.title);
        setCurrentCloudPrivacy('unlisted');
        applyImportedImageToEditor(
          img,
          scanImport.mapGrid,
          t('Импорт из мода открыт в редакторе.', 'Companion scan import opened in the editor.'),
        );
        trackEvent('cloud_reopen_completed', { source_kind: 'companion_import', content_kind: 'preview' });
        return;
      }

      if (versionId) {
        const downloaded = await downloadCompanionArtVersionProjectJson(versionId);
        if (artId && downloaded.version.artId !== artId) throw new Error('Cloud art version mismatch.');
        const ok = await applyProjectJsonToEditor(
          downloaded.projectJson,
          t('Облачный арт открыт в редакторе.', 'Cloud art opened in the editor.'),
        );
        if (!ok) throw new Error('Project file is incompatible.');
        setCurrentCloudImportId(null);
        setCurrentCloudArtId(downloaded.version.artId);
        setLoadedCloudVersionId(versionId);
        setCurrentCloudTitle(downloaded.version.title);
        setCurrentCloudPrivacy('unlisted');
        trackEvent('cloud_reopen_completed', { source_kind: 'version', content_kind: 'project' });
        return;
      }

      const downloaded = await downloadCompanionProjectJson(String(artId));
      const ok = await applyProjectJsonToEditor(
        downloaded.projectJson,
        t('Облачный арт открыт в редакторе.', 'Cloud art opened in the editor.'),
      );
      if (ok) {
        setCurrentCloudImportId(null);
        setCurrentCloudArtId(downloaded.manifest.artId);
        setCurrentCloudTitle(downloaded.manifest.title);
        setCurrentCloudPrivacy(downloaded.manifest.privacy);
        trackEvent('cloud_reopen_completed', { source_kind: 'art', content_kind: 'project' });
        return;
      }

      if (downloaded.manifest.previewUrl) {
        const previewImage = await loadHtmlImage(downloaded.manifest.previewUrl);
        setCurrentCloudImportId(null);
        setCurrentCloudArtId(downloaded.manifest.artId);
        setCurrentCloudTitle(downloaded.manifest.title);
        setCurrentCloudPrivacy(downloaded.manifest.privacy);
        applyImportedImageToEditor(
          previewImage,
          downloaded.manifest.grid,
          t(
            'Project-файл недоступен, поэтому открыт preview арта.',
            'Project data was unavailable, so the art preview was opened instead.',
          ),
        );
        trackEvent('cloud_reopen_completed', { source_kind: 'art', content_kind: 'preview_fallback' });
        return;
      }

      throw new Error('Project file is incompatible.');
    } catch (err) {
      console.error('Failed to load cloud import into editor', err);
      cloudImportLoadedRef.current = false;
      if (importId) {
        window.location.assign(`/cloud?import=${encodeURIComponent(importId)}`);
        return;
      }
      showAppNotice(t('Не удалось открыть данные из облака в редакторе.', 'Could not open cloud data in the editor.'), 'error');
    }
  }, [applyImportedImageToEditor, applyProjectJsonToEditor, showAppNotice, t, setLoadedCloudVersionId, setCurrentCloudImportId, setCurrentCloudArtId, setCurrentCloudTitle, setCurrentCloudPrivacy]);

  useEffect(() => {
    if (cloudImportLoadedRef.current) return;
    const params = new URLSearchParams(window.location.search);
    if (!params.get('companionImport') && !params.get('artVersion') && !params.get('art')) return;
    cloudImportLoadedRef.current = true;
    void handleCloudImport();
  }, [handleCloudImport, cloudUserEmail]);

  useEffect(() => {
    const target = document.querySelector<HTMLElement>('.support-btn');
    if (!target) return;
    let tracked = false;
    const send = () => {
      if (tracked) return;
      tracked = true;
      trackEvent('support_header_visible', { placement: 'editor_header' });
    };
    if (!('IntersectionObserver' in window)) {
      if (target.getClientRects().length > 0) send();
      return;
    }
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) {
        send();
        observer.disconnect();
      }
    }, { threshold: 0.5 });
    observer.observe(target);
    return () => observer.disconnect();
  }, []);

  return (
    <>
    <div className="app">
        <header className={`app-header${cloudMenuOpen ? ' is-cloud-menu-open' : ''}`}>
        <div className="header-inner">
          <a
            className="app-logo-link"
            href="/"
            title={t('Начать новый арт', 'Start a new art')}
            aria-label={t('Начать новый арт', 'Start a new art')}
            onClick={() => trackEvent('new_art_logo_clicked')}
          >
            <img className="app-logo" src="/logo-opt.png" width="128" height="128" alt="" fetchPriority="high" />
          </a>
          <div className="header-titles">
            <h1 className="app-title">MAPKLUSS</h1>
            <span className="app-tagline">MINECRAFT MAP ART GENERATOR</span>
          </div>
          <div className="header-spacer" />
          <div className={`header-cloud-actions${cloudMenuOpen ? ' is-open' : ''}`} aria-label="Облако и мод MapKluss" data-tour="cloud">
            <button
              ref={cloudMenuButtonRef}
              className={`cloud-link-btn cloud-account-btn cloud-menu-trigger${cloudUserEmail ? ' is-signed-in' : ''}`}
              onClick={() => setCloudMenuOpen(open => !open)}
              title={cloudUserEmail ? cloudUserEmail : t('Войти в аккаунт MapKluss', 'Sign in to MapKluss account')}
              aria-label={cloudUserEmail ? cloudUserEmail : t('Войти в аккаунт MapKluss', 'Sign in to MapKluss account')}
              aria-expanded={cloudMenuOpen}
            >
              <IconGlyph icon={mkIcons.user} /> <span>{t('Аккаунт', 'Account')}</span>
            </button>
            <div className="cloud-action-menu" role="menu" style={cloudMenuStyle} hidden={!cloudMenuOpen}>
                <button
                  className="cloud-action-menu-item"
                  onClick={() => {
                    setCloudMenuOpen(false);
                    if (cloudUserEmail) {
                      void refreshCloudUser();
                    } else {
                      void handleCloudSignInFromEditor();
                    }
                  }}
                  role="menuitem"
                >
                  <IconGlyph icon={cloudUserEmail ? mkIcons.userCheck : mkIcons.login} />
                  <span>{cloudUserEmail ? t('Проверить аккаунт', 'Check account') : t('Войти по почте', 'Email login')}</span>
                </button>
                <button
                  className="cloud-action-menu-item"
                  onClick={() => {
                    setCloudMenuOpen(false);
                    void handleSaveCurrentArtToCloud();
                  }}
                  disabled={cloudSaving || !hasContent}
                  title={currentCloudArtId ? t('Обновить арт в облаке', 'Update art in Cloud') : t('Сохранить арт в облако', 'Save art to Cloud')}
                  role="menuitem"
                >
                  <IconGlyph icon={mkIcons.saveEditor} />
                  <span>{cloudSaving ? t('Сохраняю...', 'Saving...') : currentCloudArtId ? t('Обновить арт', 'Update art') : t('Сохранить арт', 'Save art')}</span>
                </button>
                <button
                  className="cloud-action-menu-item"
                  onClick={() => {
                    setCloudMenuOpen(false);
                    setShowCloudArtsPanel(true);
                  }}
                  role="menuitem"
                >
                  <IconGlyph icon={mkIcons.projectEditor} />
                  <span>{t('Папка артов', 'Art folder')}</span>
                </button>
                <a
                  className="cloud-action-menu-item"
                  href="/cloud"
                  onClick={() => setCloudMenuOpen(false)}
                  role="menuitem"
                >
                  <IconGlyph icon={mkIcons.cloud} />
                  <span>{t('Облако и мод', 'Cloud and mod')}</span>
                </a>
                <a
                  className="cloud-action-menu-item"
                  href="https://github.com/SmetankaKluss/mapartforge"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setCloudMenuOpen(false)}
                  role="menuitem"
                >
                  <IconGlyph icon={mkIcons.github} />
                  <span>{t('Исходный код сайта', 'Website source code')}</span>
                </a>
                <a
                  className="cloud-action-menu-item"
                  href={lang === 'ru' ? '/classic/ru/' : '/classic/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setCloudMenuOpen(false)}
                  role="menuitem"
                >
                  <IconGlyph icon={mkIcons.palette} />
                  <span>{t('Классический редактор', 'Classic editor')}</span>
                </a>
                <LensController
                  cloudArtId={currentCloudArtId}
                  cloudVersionId={loadedCloudVersionId}
                  imageData={previewImageData}
                  grid={mapGrid}
                  mapMode={mapMode}
                  title={currentCloudTitle.trim() || t('Без названия', 'Untitled')}
                  processing={processing}
                  compareMode={compareMode}
                  t={t}
                />
              </div>
          </div>
          <a
            href={SUPPORT_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="support-btn"
            title={t('Поддержать разработку на Boosty', 'Support development on Boosty')}
            aria-label={t('Поддержать разработку на Boosty', 'Support development on Boosty')}
            onClick={() => trackEvent('support_header_clicked', { destination: 'boosty' })}
          >
            <IconGlyph icon={mkIcons.support} />
            <span>{t('Поддержать', 'Support')}</span>
          </a>
          <a className="classic-editor-link" href={lang === 'ru' ? '/classic/ru/' : '/classic/'} target="_blank" rel="noopener noreferrer" title={t('Классический редактор на основе MapartCraft', 'Classic editor based on MapartCraft')}>{t('Классика', 'Classic')}</a>
          <button className="header-icon-btn" onClick={() => { trackEvent('tutorial_opened', { tutorial_type: 'tour_selector', lang }); setTourSelectorIsWelcome(false); setShowTourSelector(true); }} title={t('Запустить интерактивный тур', 'Start guided tour')} aria-label={t('Гид', 'Guide')}><IconGlyph icon={mkIcons.guide} /></button>
          <a className="header-icon-btn" href="/wiki/" onClick={() => trackEvent('tutorial_opened', { tutorial_type: 'wiki', lang })} title={t('Открыть Wiki', 'Open Wiki')} aria-label="Wiki"><IconGlyph icon={mkIcons.wiki} /></a>
          <a className="header-icon-btn" href="https://github.com/SmetankaKluss/mapartforge" target="_blank" rel="noopener noreferrer" title={t('Исходный код сайта на GitHub', 'Website source code on GitHub')} aria-label={t('Открыть исходный код сайта на GitHub', 'Open website source code on GitHub')}><IconGlyph icon={mkIcons.github} /></a>
          <ThemeSelector lang={lang} />
          <button className="lang-toggle-btn" onClick={toggleLang} title={t('Switch to English', 'Переключить на русский')}>{lang === 'ru' ? 'EN' : 'RU'}</button>
          <a href="https://t.me/mapkluss" target="_blank" rel="noopener noreferrer" className="header-ver" title={t('Новости MapKluss', 'MapKluss news')}>{VERSION}</a>
        </div>
      </header>

      {showAnnouncement && (
        <div
          className="update-banner update-banner--companion"
          role="region"
          aria-label={t('Обновление MapKluss 1.35.0', 'MapKluss 1.35.0 update')}
        >
          <div className="update-banner-badge" aria-hidden="true">
            <IconGlyph icon={mkIcons.hammer} size={15} />
            <span>MAPKLUSS</span>
            <b>{t('НОВОЕ', 'NEW')}</b>
          </div>
          <UpdateBannerTicker
            headline="MAPKLUSS 1.35.0 · CLASSIC"
            detail={t('АККАУНТ И ОБЛАКО · 2D, 3D И TWO-LAYER', 'ACCOUNT AND CLOUD · 2D, 3D AND TWO-LAYER')}
          />
          <span className="update-banner-sr">
            {t('MapKluss Classic: привычный интерфейс с методами стройки MapKluss и сохранением в облако для вошедших пользователей.',
              'MapKluss Classic: a familiar workspace with MapKluss build methods and Cloud save for signed-in users.')}
          </span>
          <a
            className="update-banner-link"
            href={lang === 'ru' ? `${ANNOUNCEMENT.url}ru/` : ANNOUNCEMENT.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => {
              localStorage.setItem('mapkluss_seen_announcement', ANNOUNCEMENT.id);
              setShowAnnouncement(false);
            }}
          >
            <span>{t('ОТКРЫТЬ CLASSIC', 'OPEN CLASSIC')}</span>
            <IconGlyph icon={mkIcons.arrowLeft} size={13} />
          </a>
          <button
            className="update-banner-close"
            onClick={() => {
              localStorage.setItem('mapkluss_seen_announcement', ANNOUNCEMENT.id);
              setShowAnnouncement(false);
            }}
            title={t('Закрыть', 'Close')}
          >
            <IconGlyph icon={mkIcons.close} size={14} />
          </button>
        </div>
      )}

      {viewBanner && (
        <div className="view-banner">
          <span><i className="status-dot" aria-hidden="true" /> {t('ЗАГРУЖЕНО ПО ССЫЛКЕ', 'LOADED FROM LINK')}</span>
          <button className="view-banner-dismiss" onClick={() => setViewBanner(false)} title={t('Закрыть', 'Close')}><IconGlyph icon={mkIcons.close} size={14} /></button>
        </div>
      )}

      {paletteBanner && (
        <div className="view-banner palette-banner">
          <span><IconGlyph icon={mkIcons.paletteEditor} /> {t('ПАЛИТРА ЗАГРУЖЕНА ПО ССЫЛКЕ', 'PALETTE LOADED FROM LINK')}</span>
          <button className="view-banner-dismiss" onClick={() => setPaletteBanner(false)} title={t('Закрыть', 'Close')}><IconGlyph icon={mkIcons.close} size={14} /></button>
        </div>
      )}

      {appNotice && (
        <div
          className={`app-notice app-notice--${appNotice.tone}`}
          role={appNotice.tone === 'error' ? 'alert' : 'status'}
          aria-live={appNotice.tone === 'error' ? 'assertive' : 'polite'}
        >
          <span>{appNotice.message}</span>
          <button
            className="app-notice-close"
            onClick={() => setAppNotice(null)}
            aria-label={t('Закрыть уведомление', 'Close notification')}
            title={t('Закрыть', 'Close')}
          >
            <IconGlyph icon={mkIcons.close} size={14} />
          </button>
        </div>
      )}

      <div
        className={`app-body${leftPanelCollapsed ? ' left-panel-collapsed' : ''}${rightPanelCollapsed ? ' right-panel-collapsed' : ''} workbench-mode`}
        data-tab={mobileTab}
        style={{ '--panel-left': `${panelWidths.left}px`, '--panel-right': `${panelWidths.right}px` } as React.CSSProperties}
      >
        {/* ── LEFT PANEL ── */}
        <aside id="editor-settings-panel" className="panel panel-left" data-tour="settings-panel">
          <div className="panel-scroll">
            <ImageUpload ref={imageUploadRef} onImageLoaded={handleImageLoaded} onDatFile={handleDatFile} onGifFile={handleGifFile} />
            <div className="new-canvas-row">
              <button
                className="new-canvas-btn"
                onClick={() => { trackEvent('new_canvas_clicked'); setShowNewCanvasModal(true); }}
                disabled={processing}
                title={t('Создать пустой холст для рисования с нуля', 'Create blank canvas to draw from scratch')}
              >{t('Новый холст', 'New canvas')}</button>
              <button
                className="canvas-icon-btn"
                onClick={() => { trackEvent('save_project_clicked'); handleOpenSaveModal(); }}
                title={t('Сохранить проект', 'Save project')}
              ><IconGlyph icon={mkIcons.save} /></button>
              <button
                className="canvas-icon-btn"
                onClick={() => { trackEvent('projects_panel_opened'); setShowProjectsPanel(true); }}
                title={t('Мои проекты', 'My projects')}
              ><IconGlyph icon={mkIcons.project} /></button>
            </div>
            {sourceHasAlpha && (
              <div className="alpha-controls">
                <span className="alpha-label">{t('Прозрачность', 'Transparency')}</span>
                <div className="alpha-mode-btns">
                  <button
                    className={`alpha-mode-btn${bgMode === 'color' ? ' active' : ''}`}
                    onClick={() => setBgMode('color')}
                    title={t('Заполнить прозрачные области фоновым цветом', 'Fill transparent areas with background color')}
                  >{t('Фон', 'BG')}</button>
                  <button
                    className={`alpha-mode-btn${bgMode === 'transparent' ? ' active' : ''}`}
                    onClick={() => setBgMode('transparent')}
                    title={t('Оставить прозрачные области пустыми (воздух в экспорте)', 'Keep transparent areas empty (air in export)')}
                  >{t('Прозрачно', 'Transparent')}</button>
                  {bgMode === 'color' && (
                    <input
                      type="color"
                      className="alpha-color-picker"
                      value={bgColor}
                      onChange={e => setBgColor(e.target.value)}
                      title={t('Цвет заливки фона', 'Background fill color')}
                    />
                  )}
                </div>
              </div>
            )}
            {uploadedImageRef.current && (
              <div className="crop-section">
                <button
                  className="crop-tool-btn"
                  onClick={() => { trackEvent('crop_tool_opened', { map_wide: mapGrid.wide, map_tall: mapGrid.tall }); setShowCropModal(true); }}
                  disabled={processing}
                  title={t(`Обрезать изображение под пропорции карты ${pw}×${ph}`, `Crop image to map ratio ${pw}×${ph}`)}
                ><IconGlyph icon={mkIcons.crop} /> {t('Обрезать', 'Crop')}</button>
                <span className="crop-ratio-hint">{mapGrid.wide}:{mapGrid.tall}</span>
              </div>
            )}
            <Controls
              dithering={dithering}
              onDitheringChange={handleDitheringChange}
              colorMatch={colorMatch}
              onColorMatchChange={handleColorMatchChange}
              intensity={intensity}
              onIntensityChange={handleIntensityChange}
              onIntensityCommit={handleIntensityCommit}
              bnScale={bnScale}
              onBnScaleChange={handleBnScaleChange}
              klussParams={klussParams}
              onKlussParamsChange={handleKlussParamsChange}
              mapGrid={mapGrid}
              onMapGridChange={handleMapGridChange}
              mapMode={mapMode}
              buildTechnique={buildTechnique}
              onBuildModeChange={handleBuildModeChange}
              staircaseMode={staircaseMode}
              onStaircaseModeChange={handleStaircaseModeChange}
              processing={processing}
              isBlankCanvas={false}
              collapsedSections={collapsedSections}
              onToggleSection={handleToggleSection}
              t={t}
            />
            <div className="panel-section">
              <Adjustments
                adjustments={adjustments}
                sourceImage={sourceImage}
                onChange={handleAdjChange}
                onCommit={handleAdjCommit}
                disabled={processing || !showAdjustments}
                showAdjustments={showAdjustments}
                onToggleAdjustments={handleToggleAdjustments}
                collapsed={!!collapsedSections['adjustments']}
                onToggle={() => handleToggleSection('adjustments')}
              />
            </div>
          </div>
          <div className="panel-footer">
            <div className="workspace-quick-actions" aria-label={t('Рабочие действия редактора', 'Editor workspace actions')}>
              {hasContent && (
                <>
                  <button
                    className="workspace-action-btn"
                    title={t('Сбросить масштаб до 100%', 'Reset zoom to 100%')}
                    aria-label={t('Сбросить масштаб до 100%', 'Reset zoom to 100%')}
                    onClick={() => updateCanvasZoom(100)}
                  ><IconGlyph icon={mkIcons.zoomReset} /></button>
                  {!compareMode && (
                    <button
                      className={`workspace-action-btn${textureMode === 'block' ? ' active' : ''}`}
                      onClick={() => setTextureMode(mode => mode === 'block' ? 'pixel' : 'block')}
                      title={t('Текстуры блоков', 'Block textures')}
                      aria-label={t('Текстуры блоков', 'Block textures')}
                      aria-pressed={textureMode === 'block'}
                    ><IconGlyph icon={mkIcons.blockTextures} /></button>
                  )}
                  <button
                    className={`workspace-action-btn${showGrid ? ' active' : ''}`}
                    onClick={() => setShowGrid(value => !value)}
                    title={t('Сетка', 'Grid')}
                    aria-label={t('Сетка', 'Grid')}
                    aria-pressed={showGrid}
                  ><IconGlyph icon={mkIcons.grid} /></button>
                  <button
                    className={`workspace-action-btn${compareMode ? ' active' : ''}`}
                    onClick={() => handleCompareModeChange(!compareMode)}
                    title={t('Сравнение', 'Comparison')}
                    aria-label={t('Сравнение', 'Comparison')}
                    aria-pressed={compareMode}
                  ><IconGlyph icon={mkIcons.compare} /></button>
                  <button
                    className={`workspace-action-btn${showSplitLine ? ' active' : ''}`}
                    title={t('Показать/скрыть полоску сравнения', 'Show/hide split line')}
                    aria-label={t('Полоса сравнения', 'Comparison split')}
                    onClick={() => setShowSplitLine(value => !value)}
                    aria-pressed={showSplitLine}
                  ><IconGlyph icon={mkIcons.compare} /></button>
                  <button
                    className="workspace-action-btn"
                    title={t('Сбросить разделитель', 'Reset split to center')}
                    aria-label={t('Сбросить разделитель', 'Reset split to center')}
                    onClick={() => setSplitPos(50)}
                  ><IconGlyph icon={mkIcons.layoutCenter} /></button>
                  <button
                    className="workspace-action-btn"
                    onClick={() => setShowPerspective(true)}
                    title={t('Предпросмотр схематики и сцены', 'Schematic and scene preview')}
                    aria-label={t('Предпросмотр схематики и сцены', 'Schematic and scene preview')}
                  ><IconGlyph icon={mkIcons.view} /></button>
                </>
              )}
              <button
                className={`workspace-action-btn${showShortcuts ? ' active' : ''}`}
                onClick={() => setShowShortcuts(value => !value)}
                title={t('Клавиатурные сочетания', 'Keyboard shortcuts')}
                aria-label={t('Клавиатурные сочетания', 'Keyboard shortcuts')}
                aria-expanded={showShortcuts}
              ><IconGlyph icon={mkIcons.keyboard} /></button>
              <button
                className={`workspace-action-btn workspace-action-btn-artist${editorMode === 'artist' ? ' active' : ''}`}
                onClick={() => {
                  setEditorMode(mode => {
                    const next = mode === 'simple' ? 'artist' : 'simple';
                    trackEvent('artist_mode_toggled', { enabled: next === 'artist' });
                    return next;
                  });
                }}
                title={editorMode === 'artist' ? t('Выключить режим художника', 'Exit artist mode') : t('Режим художника: слои и расширенные инструменты', 'Artist mode: layers & advanced tools')}
                aria-label={editorMode === 'artist' ? t('Выключить режим художника', 'Exit artist mode') : t('Режим художника', 'Artist mode')}
                aria-pressed={editorMode === 'artist'}
              ><IconGlyph icon={mkIcons.artist} /></button>
            </div>
            {showShortcuts && (
              <div className="shortcuts-panel">
                <div className="shortcuts-panel-title">{t('ГОРЯЧИЕ КЛАВИШИ', 'KEYBOARD SHORTCUTS')}</div>
                <div className="shortcut-row"><kbd>Ctrl+Z</kbd><span>{t('Отменить', 'Undo')}</span></div>
                <div className="shortcut-row"><kbd>Ctrl+Y</kbd><span>{t('Повторить', 'Redo')}</span></div>
                <div className="shortcut-row"><kbd>Ctrl+S</kbd><span>{t('Экспорт PNG', 'Export PNG')}</span></div>
                <div className="shortcut-row"><kbd>Ctrl+Shift+S</kbd><span>{t('Экспорт .litematic', 'Export .litematic')}</span></div>
                <div className="shortcuts-divider" />
                <div className="shortcut-row"><kbd>Z</kbd><span>{t('Сетка', 'Grid')}</span></div>
                <div className="shortcut-row"><kbd>O</kbd><span>{t('Сброс разделителя', 'Reset split')}</span></div>
                <div className="shortcut-row"><kbd>C</kbd><span>{t('Режим сравнения', 'Compare mode')}</span></div>
                <div className="shortcut-row"><kbd>1 – 9</kbd><span>{t('Выбор дизеринга', 'Select dithering')}</span></div>
                <div className="shortcuts-divider" />
                <div className="shortcut-row"><kbd>E</kbd><span>{t('Пипетка', 'Eyedropper')}</span></div>
                <div className="shortcut-row"><kbd>B</kbd><span>{t('Кисть', 'Brush')}</span></div>
                <div className="shortcut-row"><kbd>F</kbd><span>{t('Заливка', 'Fill')}</span></div>
                <div className="shortcut-row"><kbd>X</kbd><span>{t('Ластик', 'Eraser')}</span></div>
                <div className="shortcut-row"><kbd>T</kbd><span>{t('Текст', 'Text')}</span></div>
                <div className="shortcut-row"><kbd>V</kbd><span>{t('Перемещение слоя', 'Move layer')}</span></div>
                <div className="shortcut-row"><kbd>R</kbd><span>{t('Прямоугольное выделение', 'Rectangular selection')}</span></div>
                <div className="shortcut-row"><kbd>L</kbd><span>{t('Лассо', 'Lasso')}</span></div>
                <div className="shortcut-row"><kbd>W</kbd><span>{t('Волшебная палочка', 'Magic wand')}</span></div>
                <div className="shortcut-row"><kbd>P</kbd><span>{t('Паттерн', 'Pattern tile')}</span></div>
                <div className="shortcut-row"><kbd>G</kbd><span>{t('Градиент', 'Gradient')}</span></div>
                <div className="shortcut-row"><kbd>Shift + клик</kbd><span>{t('Прямая линия кистью', 'Straight brush line')}</span></div>
                <div className="shortcut-row"><kbd>Shift + ЛКМ</kbd><span>{t('Пипетка по ходу курсора', 'Sample along the cursor')}</span></div>
                <div className="shortcut-row"><kbd>Ctrl+A</kbd><span>{t('Выделить всё', 'Select all')}</span></div>
                <div className="shortcut-row"><kbd>Ctrl+D</kbd><span>{t('Снять выделение', 'Deselect')}</span></div>
                <div className="shortcut-row"><kbd>Ctrl+I</kbd><span>{t('Инвертировать выделение', 'Invert selection')}</span></div>
                <div className="shortcut-row"><kbd>Space + ЛКМ</kbd><span>{t('Временно перемещать холст', 'Temporarily pan canvas')}</span></div>
                <div className="shortcut-row"><kbd>Esc</kbd><span>{t('Снять инструмент', 'Deselect tool')}</span></div>
              </div>
            )}
            <button
              className={`reset-defaults-btn${resetDefaultsPending ? ' pending' : ''}`}
              disabled={processing}
              title={resetDefaultsPending ? t('Нажми ещё раз для подтверждения', 'Click again to confirm reset') : t('Сбросить все настройки', 'Reset all settings to defaults')}
              onClick={() => {
                if (!resetDefaultsPending) {
                  setResetDefaultsPending(true);
                  resetDefaultsTimerRef.current = setTimeout(() => setResetDefaultsPending(false), 2000);
                } else {
                  if (resetDefaultsTimerRef.current) clearTimeout(resetDefaultsTimerRef.current);
                  setResetDefaultsPending(false);
                  handleResetDefaults();
                }
              }}
            >
              <IconGlyph icon={mkIcons.reset} className="reset-icon" /> {resetDefaultsPending ? t('Точно?', 'Sure?') : t('Сбросить всё', 'Reset All')}
            </button>
          </div>
        </aside>

        <div
          className="panel-resizer panel-resizer-left"
          role="separator"
          aria-orientation="vertical"
          aria-label={t('Изменить ширину панели настроек', 'Resize settings panel')}
          tabIndex={0}
          onPointerDown={event => handlePanelResizeStart('left', event)}
          onPointerMove={handlePanelResizeMove}
          onPointerUp={handlePanelResizeEnd}
          onPointerCancel={handlePanelResizeEnd}
          onKeyDown={event => handlePanelResizeKeyDown('left', event)}
        />

        {/* ── CENTER PANEL ── */}
        <main className="panel panel-center" ref={previewSectionRef}>
          <button
            className="panel-collapse-toggle panel-collapse-toggle-left"
            onClick={() => setLeftPanelCollapsed(value => !value)}
            title={leftPanelCollapsed
              ? t('Развернуть панель настроек', 'Expand settings panel')
              : t('Свернуть панель настроек', 'Collapse settings panel')}
            aria-label={leftPanelCollapsed
              ? t('Развернуть панель настроек', 'Expand settings panel')
              : t('Свернуть панель настроек', 'Collapse settings panel')}
            aria-expanded={!leftPanelCollapsed}
            aria-controls="editor-settings-panel"
          >
            <IconGlyph icon={leftPanelCollapsed ? mkIcons.chevronRight : mkIcons.chevronLeft} />
          </button>
          <button
            className="panel-collapse-toggle panel-collapse-toggle-right"
            onClick={() => setRightPanelCollapsed(value => !value)}
            title={rightPanelCollapsed
              ? t('Развернуть панель палитры', 'Expand palette panel')
              : t('Свернуть панель палитры', 'Collapse palette panel')}
            aria-label={rightPanelCollapsed
              ? t('Развернуть панель палитры', 'Expand palette panel')
              : t('Свернуть панель палитры', 'Collapse palette panel')}
            aria-expanded={!rightPanelCollapsed}
            aria-controls="editor-palette-panel"
          >
            <IconGlyph icon={rightPanelCollapsed ? mkIcons.chevronLeft : mkIcons.chevronRight} />
          </button>
          <div className="toolbar" data-tour="toolbar">

            {/* LEFT: undo/redo — always visible */}
            <div className="toolbar-group">
              <button className="tool-btn" onClick={handleUndo} disabled={!hasContent || undoStack.length === 0} title={t('Отменить (Ctrl+Z)', 'Undo (Ctrl+Z)')} aria-label={t('Отменить', 'Undo')}><IconGlyph icon={mkIcons.undo} /></button>
              <button className="tool-btn" onClick={handleRedo} disabled={!hasContent || redoStack.length === 0} title={t('Повторить (Ctrl+Y)', 'Redo (Ctrl+Y)')}><IconGlyph icon={mkIcons.redo} /></button>
            </div>
            <div className="toolbar-sep" />

            {/* TOOLS: select / eyedropper / brush / fill — only when image loaded */}
            {!compareMode && imageData && (
              <div className="toolbar-paint-tools">
                {/* Tool buttons */}
                <div className="toolbar-group">
                  <button className={`tool-btn${activeTool === null ? ' active' : ''}`} onClick={() => setActiveTool(null)} title={t('Курсор / перемещение холста (Esc)', 'Cursor / pan canvas (Esc)')} aria-label={t('Курсор', 'Cursor')} aria-pressed={activeTool === null} aria-keyshortcuts="Escape">
                    <IconGlyph icon={mkIcons.select} />
                  </button>
                  <button className={`tool-btn${activeTool === 'eyedropper' ? ' active' : ''}`} onClick={() => setActiveTool(t => t === 'eyedropper' ? null : 'eyedropper')} title={t('Пипетка (E)', 'Eyedropper (E)')} aria-label={t('Пипетка', 'Eyedropper')} aria-pressed={activeTool === 'eyedropper'} aria-keyshortcuts="E">
                    <IconGlyph icon={mkIcons.eyedropper} />
                  </button>
                  <button className={`tool-btn${activeTool === 'brush' ? ' active' : ''}`} onClick={() => setActiveTool(t => t === 'brush' ? null : 'brush')} title={t('Кисть (B)', 'Brush (B)')} aria-label={t('Кисть', 'Brush')} aria-pressed={activeTool === 'brush'} aria-keyshortcuts="B" disabled={activeLayerLocked}>
                    <IconGlyph icon={mkIcons.brush} />
                  </button>
                  <button className={`tool-btn${activeTool === 'fill' ? ' active' : ''}`} onClick={() => setActiveTool(t => t === 'fill' ? null : 'fill')} title={t('Заливка (F). Без блока — прозрачный', 'Fill (F). No block = transparent')} aria-label={t('Заливка', 'Fill')} aria-pressed={activeTool === 'fill'} aria-keyshortcuts="F" disabled={activeLayerLocked}>
                    <IconGlyph icon={mkIcons.fill} />
                  </button>
                  <button className={`tool-btn${activeTool === 'eraser' ? ' active' : ''}`} onClick={() => setActiveTool(t => t === 'eraser' ? null : 'eraser')} title={t('Ластик (X)', 'Eraser (X)')} aria-label={t('Ластик', 'Eraser')} aria-pressed={activeTool === 'eraser'} aria-keyshortcuts="X" disabled={activeLayerLocked}>
                    <IconGlyph icon={mkIcons.eraser} />
                  </button>
                  <button className={`tool-btn${activeTool === 'text' ? ' active' : ''}`} onClick={() => setActiveTool(tool => tool === 'text' ? null : 'text')} title={t('Текст (T)', 'Text (T)')} aria-label={t('Текст', 'Text')} aria-pressed={activeTool === 'text'} aria-keyshortcuts="T" disabled={activeLayerLocked}>
                    <IconGlyph icon={mkIcons.text} />
                  </button>
                  {/* pattern tool hidden — work in progress */}
                </div>

                {/* Pattern blocks — hidden while text/pattern tools are WIP */}
                {SHOW_PATTERN_BLOCKS && editorMode === 'artist' && activeTool === 'pattern' && (
                  <div className="toolbar-group pattern-blocks-group" style={{ position: 'relative', flexWrap: 'wrap', gap: 3 }}>
                    {patternBlocks.map((pb, idx) => (
                      <div key={idx} className="pattern-block-chip" style={{ position: 'relative' }}>
                        {pb.baseId === -1 ? (
                          <span className="paint-swatch-icon block-picker-icon-transparent pattern-chip-swatch" onClick={() => setShowPatternPicker(idx)} title={t('Сменить блок', 'Change block')} />
                        ) : (
                          <span className="paint-swatch-icon pattern-chip-swatch" style={{ backgroundImage: `url(${SPRITE_URL})`, backgroundPosition: `-${pb.blockId * 32}px -${pb.csId * 32}px` }} onClick={() => setShowPatternPicker(idx)} title={pb.displayName} />
                        )}
                        <button className="pattern-chip-remove" onClick={() => setPatternBlocks(prev => prev.filter((_, i) => i !== idx))} disabled={patternBlocks.length <= 1} title={t('Удалить', 'Remove')} aria-label={t('Удалить', 'Remove')}><IconGlyph icon={mkIcons.close} /></button>
                        {showPatternPicker === idx && (
                          <BlockPickerPopup
                            blockSelection={blockSelection}
                            current={pb}
                            onSelect={b => { setPatternBlocks(prev => prev.map((x, i) => i === idx ? b : x)); setShowPatternPicker(null); }}
                            onClose={() => setShowPatternPicker(null)}
                            mapMode={mapMode}
                          />
                        )}
                      </div>
                    ))}
                    <div style={{ position: 'relative' }}>
                      <button className="tool-btn" title={t('Добавить блок', 'Add block')} aria-label={t('Добавить блок', 'Add block')} onClick={() => setShowPatternPicker(-1)}><IconGlyph icon={mkIcons.plus} /></button>
                      {showPatternPicker === -1 && (
                        <BlockPickerPopup
                          blockSelection={blockSelection}
                          current={null}
                          onSelect={b => { setPatternBlocks(prev => [...prev, b]); setShowPatternPicker(null); }}
                          onClose={() => setShowPatternPicker(null)}
                          mapMode={mapMode}
                        />
                      )}
                    </div>
                  </div>
                )}

                {editorMode === 'artist' && (
                  <>
                    <div className="toolbar-sep" />
                    <div className="toolbar-group">
                      <button
                        className={`tool-btn${activeTool === 'move' ? ' active' : ''}`}
                        onClick={() => setActiveTool(t => t === 'move' ? null : 'move')}
                        title={t('Переместить слой (V)', 'Move layer (V)')}
                        aria-label={t('Переместить слой', 'Move layer')} aria-pressed={activeTool === 'move'} aria-keyshortcuts="V" disabled={activeLayerLocked}
                      ><IconGlyph icon={mkIcons.move} /></button>
                      <button
                        className={`tool-btn${activeTool === 'select-rect' ? ' active' : ''}`}
                        onClick={() => setActiveTool(t => t === 'select-rect' ? null : 'select-rect')}
                        title={t('Прямоугольное выделение (R)', 'Rect select (R)')}
                        aria-label={t('Прямоугольное выделение', 'Rectangular selection')} aria-pressed={activeTool === 'select-rect'} aria-keyshortcuts="R"
                      ><IconGlyph icon={mkIcons.selectRect} /></button>
                      <button
                        className={`tool-btn${activeTool === 'select-lasso' ? ' active' : ''}`}
                        onClick={() => setActiveTool(t => t === 'select-lasso' ? null : 'select-lasso')}
                        title={t('Лассо (L)', 'Lasso (L)')}
                        aria-label={t('Лассо', 'Lasso')} aria-pressed={activeTool === 'select-lasso'} aria-keyshortcuts="L"
                      ><IconGlyph icon={mkIcons.lasso} /></button>
                      <button
                        className={`tool-btn${activeTool === 'select-magic' ? ' active' : ''}`}
                        onClick={() => setActiveTool(t => t === 'select-magic' ? null : 'select-magic')}
                        title={t('Волшебная палочка (W)', 'Magic wand (W)')}
                        aria-label={t('Волшебная палочка', 'Magic wand')} aria-pressed={activeTool === 'select-magic'} aria-keyshortcuts="W"
                      ><IconGlyph icon={mkIcons.wand} /></button>
                    </div>
                    {/* Pattern-tile tool */}
                    <div className="toolbar-sep" />
                    <div className="toolbar-group">
                      <button
                        className={`tool-btn${activeTool === 'pattern-tile' ? ' active' : ''}`}
                        onClick={() => setActiveTool(prev => prev === 'pattern-tile' ? null : 'pattern-tile')}
                        title={t('Паттерн-кисть (P)', 'Pattern brush (P)')}
                        aria-label={t('Паттерн-кисть', 'Pattern brush')} aria-pressed={activeTool === 'pattern-tile'} aria-keyshortcuts="P" disabled={activeLayerLocked}
                      ><IconGlyph icon={mkIcons.pattern} /></button>
                    </div>

                    {/* Gradient tool */}
                    <div className="toolbar-group" style={{ position: 'relative' }}>
                      <button
                        className={`tool-btn${activeTool === 'gradient' ? ' active' : ''}`}
                        onClick={() => setActiveTool(prev => prev === 'gradient' ? null : 'gradient')}
                        title={t('Градиент (G)', 'Gradient (G)')}
                        aria-label={t('Градиент', 'Gradient')} aria-pressed={activeTool === 'gradient'} aria-keyshortcuts="G" disabled={activeLayerLocked}
                      ><IconGlyph icon={mkIcons.gradient} /></button>
                    </div>
                  </>
                )}
                <div className="toolbar-sep" />
              </div>
            )}

            {/* SPACER */}
            <div className="toolbar-spacer" />

            {/* ZOOM — only when content */}
            {hasContent && (
              <div className="toolbar-group">
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={0.1}
                  value={canvasZoomToSlider(zoom)}
                  className="zoom-slider"
                  onChange={event => updateCanvasZoom(sliderToCanvasZoom(Number(event.target.value)))}
                  title={t('Масштаб (Ctrl/⌘ + колесо)', 'Zoom (Ctrl/⌘ + wheel)')}
                  aria-label={t('Масштаб холста', 'Canvas zoom')}
                />
                <NumInput
                  value={zoom}
                  min={MIN_CANVAS_ZOOM}
                  max={MAX_CANVAS_ZOOM}
                  step={0.1}
                  decimals={1}
                  onCommit={updateCanvasZoom}
                  ariaLabel={t('Масштаб холста в процентах', 'Canvas zoom percentage')}
                />
                <span className="toolbar-label-unit">%</span>
              </div>
            )}

            {/* TABLET DRAWER TOGGLE */}
            <div className="toolbar-sep tablet-right-sep" />
            <button
              className={`tool-btn tablet-right-toggle${tabletRightOpen ? ' active' : ''}`}
              onClick={() => setTabletRightOpen(v => !v)}
              title={t('Палитра и экспорт', 'Palette & Export')}
              aria-label={t('Палитра и экспорт', 'Palette & Export')}
              aria-expanded={tabletRightOpen}
              aria-controls="editor-palette-panel"
            ><IconGlyph icon={mkIcons.package} /></button>

          </div>

          {!compareMode && imageData && (
            <div className="editor-tool-context" role="region" aria-label={t('Настройки активного инструмента', 'Active tool settings')} data-tour="tool-context">
              <div className="editor-tool-context-summary">
                <span className="editor-tool-context-icon" aria-hidden="true"><IconGlyph icon={activeToolUi.icon} /></span>
                <span className="editor-tool-context-copy">
                  <strong>{activeToolUi.name}</strong>
                  <span>{activeToolUi.hint}</span>
                </span>
                <kbd>{activeToolUi.key}</kbd>
              </div>

              {toolUsesSharedPaintBlock && (
                <div className="editor-tool-shared-paint-block">
                  <span className="editor-tool-setting-label">{t('Материал', 'Material')}</span>
                  <button
                    type="button"
                    className="editor-tool-shared-paint-button"
                    onClick={() => setShowBlockPicker(value => !value)}
                    aria-expanded={showBlockPicker}
                    aria-label={paintBlock
                      ? t(`Выбранный материал: ${paintBlock.displayName}, цвет ${paintBlock.colourName}. Изменить`, `Selected material: ${paintBlock.displayName}, colour ${paintBlock.colourName}. Change`)
                      : t('Выбрать материал', 'Choose material')}
                    title={paintBlock
                      ? t(`${paintBlock.displayName} · ${paintBlock.colourName}`, `${paintBlock.displayName} · ${paintBlock.colourName}`)
                      : t('Выбрать материал', 'Choose material')}
                    disabled={activeLayerLocked}
                  >
                    {paintBlock?.baseId === -1 ? (
                      <span className="paint-swatch-icon-wrap"><span className="paint-swatch-icon block-picker-icon-transparent" /></span>
                    ) : paintBlock ? (
                      <span className="paint-swatch-icon-wrap"><span className="paint-swatch-icon" style={{ backgroundImage: `url(${SPRITE_URL})`, backgroundPosition: `-${paintBlock.blockId * 32}px -${paintBlock.csId * 32}px` }} /></span>
                    ) : (
                      <span className="editor-tool-shared-paint-empty" aria-hidden="true" />
                    )}
                    <span className="editor-tool-shared-paint-copy">
                      <strong>{paintBlock?.displayName ?? t('Блок не выбран', 'No block selected')}</strong>
                      <small>{paintBlock?.colourName ?? t('Выбери материал или возьми его пипеткой', 'Choose a material or sample it')}</small>
                    </span>
                    <IconGlyph icon={mkIcons.chevronDown} />
                  </button>
                  {showBlockPicker && (
                    <BlockPickerPopup
                      blockSelection={blockSelection}
                      current={paintBlock}
                      onSelect={block => { setPaintBlock(block); setShowBlockPicker(false); }}
                      onClose={() => setShowBlockPicker(false)}
                      mapMode={mapMode}
                    />
                  )}
                </div>
              )}

              {activeLayerLocked && (
                <div className="editor-tool-lock" role="status">
                  <IconGlyph icon={mkIcons.lock} />
                  <span>{t('Слой защищён от изменений', 'Layer protected from changes')}</span>
                  <button type="button" onClick={() => activeLayer && handleToggleLock(activeLayer.id)}>
                    {t('Разблокировать', 'Unlock')}
                  </button>
                </div>
              )}

              {(activeTool === 'brush' || activeTool === 'eraser' || (activeTool === 'pattern-tile' && patternAnchorMode !== 'brush')) && (
                <label className="editor-tool-setting editor-tool-brush-size">
                  <span>{t('Размер', 'Size')}</span>
                  <input
                    type="range"
                    min={0}
                    max={BRUSH_SIZES.length - 1}
                    step={1}
                    value={Math.max(0, BRUSH_SIZES.indexOf(brushSize))}
                    onChange={event => setBrushSize(BRUSH_SIZES[Number(event.target.value)])}
                    disabled={activeLayerLocked}
                  />
                  <output>{brushSize}px</output>
                </label>
              )}

              {mapMode === '3d' && (activeTool === 'brush' || activeTool === 'fill') && paintBlock && paintBlock.baseId !== -1 && (
                <div className="editor-tool-setting editor-tool-shades" role="group" aria-label={t('Оттенок карты', 'Map shade')}>
                  <span>{t('Оттенок', 'Shade')}</span>
                  {([0, 1, 2] as const).map(shade => {
                    const shadeNames = [t('Тёмный', 'Dark'), t('Средний', 'Mid'), t('Светлый', 'Bright')];
                    const color = activePalette.colors.find(item => item.baseId === paintBlock.baseId && item.shade === shade);
                    return (
                      <button
                        key={shade}
                        type="button"
                        className={`editor-tool-shade${paintBlock.shade === shade ? ' active' : ''}`}
                        style={{ '--shade-color': color ? `rgb(${color.r},${color.g},${color.b})` : 'var(--text-muted)' } as React.CSSProperties}
                        aria-label={shadeNames[shade]}
                        aria-pressed={paintBlock.shade === shade}
                        onClick={() => setPaintBlock(block => block ? { ...block, shade } : block)}
                      />
                    );
                  })}
                </div>
              )}

              {activeTool === 'select-magic' && (
                <div className="editor-tool-options" role="group" aria-label={t('Настройки волшебной палочки', 'Magic wand settings')}>
                  {(['similar', 'exact', 'alpha'] as const).map(mode => (
                    <button key={mode} type="button" className={magicWandMode === mode ? 'active' : ''} aria-pressed={magicWandMode === mode} onClick={() => setMagicWandMode(mode)}>
                      {mode === 'similar' ? t('Похожие', 'Similar') : mode === 'exact' ? t('Точные', 'Exact') : t('Прозрачные', 'Alpha')}
                    </button>
                  ))}
                  <span className="editor-tool-options-separator" />
                  <button type="button" className={magicWandContiguous ? 'active' : ''} aria-pressed={magicWandContiguous} onClick={() => setMagicWandContiguous(true)}>{t('Смежные', 'Contiguous')}</button>
                  <button type="button" className={!magicWandContiguous ? 'active' : ''} aria-pressed={!magicWandContiguous} onClick={() => setMagicWandContiguous(false)}>{t('Весь слой', 'Whole layer')}</button>
                  {magicWandMode === 'similar' && (
                    <label className="editor-tool-setting">
                      <span>{t('Допуск', 'Tolerance')}</span>
                      <input type="range" min={0.005} max={0.12} step={0.005} value={magicWandTolerance} onChange={event => setMagicWandTolerance(Number(event.target.value))} />
                      <output>{magicWandTolerance.toFixed(3)}</output>
                    </label>
                  )}
                </div>
              )}

              {selectionMask && (
                <div className="editor-selection-actions" role="group" aria-label={t('Действия с выделением', 'Selection actions')}>
                  <span className="editor-selection-count">{selectedPixelCount.toLocaleString()} {t('пикс.', 'px')}</span>
                  <button type="button" onClick={handleDeleteSelection} disabled={activeLayerLocked}><IconGlyph icon={mkIcons.trash} />{t('Удалить', 'Delete')}</button>
                  <button type="button" onClick={handleFillSelection} disabled={activeLayerLocked || !paintBlock || paintBlock.baseId === -1}><IconGlyph icon={mkIcons.fill} />{t('Залить', 'Fill')}</button>
                  <button type="button" onClick={handleInvertSelection}><IconGlyph icon={mkIcons.invert} />{t('Инвертировать', 'Invert')}</button>
                  <button type="button" onClick={handleMoveSelectionToLayer} disabled={activeLayerLocked}><IconGlyph icon={mkIcons.layer} />{t('На новый слой', 'To new layer')}</button>
                  <button type="button" onClick={() => setSelectionMask(null)}><IconGlyph icon={mkIcons.deselect} />{t('Снять', 'Deselect')}</button>
                </div>
              )}

              {activeTool === 'pattern-tile' && (
                <div className="editor-tool-options">
                  <button type="button" onClick={() => setShowPatternEditor(true)}><IconGlyph icon={mkIcons.settings} />{t('Редактировать паттерн', 'Edit pattern')}</button>
                  <button type="button" className={patternAnchorMode === 'brush' ? 'active' : ''} aria-pressed={patternAnchorMode === 'brush'} onClick={() => setPatternAnchorMode(mode => mode === 'brush' ? 'canvas' : 'brush')}><IconGlyph icon={mkIcons.anchor} />{patternAnchorMode === 'brush' ? t('Якорь: кисть', 'Anchor: brush') : t('Якорь: холст', 'Anchor: canvas')}</button>
                  <button type="button" onClick={() => activePattern && exportPattern(activePattern)}><IconGlyph icon={mkIcons.export} />{t('Экспорт', 'Export')}</button>
                  <label className="editor-tool-file-button"><IconGlyph icon={mkIcons.import} />{t('Импорт', 'Import')}<input type="file" accept=".json" onChange={event => { const file = event.target.files?.[0]; if (file) importPattern(file); event.target.value = ''; }} /></label>
                </div>
              )}

              {activeTool === 'gradient' && (
                <div className="editor-gradient-context">
                  <span className="editor-tool-setting-label">{t('Цвета', 'Colors')}</span>
                  {[...gradientStops.map((stop, index) => ({ stop, index }))].sort((a, b) => a.stop.t - b.stop.t).map(({ stop, index }, sortedIndex, sortedStops) => {
                    const color = activePalette.colors.find(item => item.baseId === stop.block.baseId && item.shade === stop.block.shade)
                      ?? activePalette.colors.find(item => item.baseId === stop.block.baseId);
                    return (
                      <div key={index} className="editor-gradient-stop">
                        {sortedIndex > 0 && (
                          <button type="button" className="editor-gradient-move" aria-label={t('Переместить цвет влево', 'Move color left')} onClick={() => moveGradientStop(index, -1)}><IconGlyph icon={mkIcons.chevronLeft} /></button>
                        )}
                        <button
                          type="button"
                          className={`editor-gradient-swatch${showGradientStopPicker === index ? ' active' : ''}`}
                          style={{ '--stop-color': color ? `rgb(${color.r},${color.g},${color.b})` : 'var(--text-muted)' } as React.CSSProperties}
                          aria-label={`${stop.block.displayName}, ${Math.round(stop.t * 100)}%`}
                          onClick={() => setShowGradientStopPicker(value => value === index ? null : index)}
                        />
                        {sortedIndex < sortedStops.length - 1 && (
                          <button type="button" className="editor-gradient-move" aria-label={t('Переместить цвет вправо', 'Move color right')} onClick={() => moveGradientStop(index, 1)}><IconGlyph icon={mkIcons.chevronRight} /></button>
                        )}
                        {gradientStops.length > 2 && sortedIndex > 0 && sortedIndex < sortedStops.length - 1 && (
                          <button type="button" className="editor-gradient-remove" aria-label={t('Удалить цвет градиента', 'Remove gradient color')} onClick={() => setGradientStops(previous => previous.filter((_, itemIndex) => itemIndex !== index))}><IconGlyph icon={mkIcons.close} /></button>
                        )}
                        {showGradientStopPicker === index && (
                          <BlockPickerPopup blockSelection={blockSelection} current={stop.block} onSelect={block => { setGradientStops(previous => previous.map((item, itemIndex) => itemIndex === index ? { ...item, block } : item)); setShowGradientStopPicker(null); }} onClose={() => setShowGradientStopPicker(null)} mapMode={mapMode} />
                        )}
                      </div>
                    );
                  })}
                  {gradientStops.length < 6 && (
                    <div className="editor-gradient-stop editor-gradient-add">
                      <button type="button" className="editor-gradient-add-button" aria-label={t('Добавить цвет градиента', 'Add gradient color')} onClick={() => setShowGradientAddPicker(value => !value)}><IconGlyph icon={mkIcons.plus} /></button>
                      {showGradientAddPicker && (
                        <BlockPickerPopup
                          blockSelection={blockSelection}
                          current={null}
                          onSelect={block => {
                            setGradientStops(previous => {
                              if (previous.length === 0) return [{ t: 0, block }];
                              if (previous.length === 1) return [...previous, { t: 1, block }];
                              const sorted = [...previous].sort((a, b) => a.t - b.t);
                              let widestGap = 0;
                              let gapStart = 0;
                              for (let index = 0; index < sorted.length - 1; index++) {
                                const gap = sorted[index + 1].t - sorted[index].t;
                                if (gap > widestGap) { widestGap = gap; gapStart = sorted[index].t; }
                              }
                              return [...previous, { t: gapStart + widestGap / 2, block }];
                            });
                            setShowGradientAddPicker(false);
                          }}
                          onClose={() => setShowGradientAddPicker(false)}
                          mapMode={mapMode}
                        />
                      )}
                    </div>
                  )}
                  <button type="button" className={`editor-gradient-dither${gradientDithering === 'ordered' ? ' active' : ''}`} aria-pressed={gradientDithering === 'ordered'} onClick={() => setGradientDithering(value => value === 'ordered' ? 'none' : 'ordered')}><IconGlyph icon={mkIcons.grid} />{t('Дизеринг', 'Dither')}</button>
                </div>
              )}
            </div>
          )}

          {compareMode && hasContent && (
            <div className="compare-selectors">
              <div className="compare-selector">
                <label className="compare-selector-label">{t('ЛЕВЫЙ', 'LEFT')}</label>
                <select
                  className="compare-selector-select"
                  value={compareLeft}
                  onChange={e => handleCompareSideChange('left', e.target.value as DitheringMode)}
                  disabled={processing}
                >
                  {compareLeft === 'kluss' && <option value="kluss" disabled>KlussDither (legacy)</option>}
                  {ALL_MODES.filter(m => m !== 'kluss').map(m => <option key={m} value={m}>{DITHERING_LABELS[m]}</option>)}
                </select>
              </div>
              <span className="compare-vs">VS</span>
              <div className="compare-selector">
                <label className="compare-selector-label">{t('ПРАВЫЙ', 'RIGHT')}</label>
                <select
                  className="compare-selector-select"
                  value={compareRight}
                  onChange={e => handleCompareSideChange('right', e.target.value as DitheringMode)}
                  disabled={processing}
                >
                  {compareRight === 'kluss' && <option value="kluss" disabled>KlussDither (legacy)</option>}
                  {ALL_MODES.filter(m => m !== 'kluss').map(m => <option key={m} value={m}>{DITHERING_LABELS[m]}</option>)}
                </select>
              </div>
            </div>
          )}

          <div
            ref={canvasAreaRef}
            className={`canvas-area${!hasContent ? ' canvas-area-clickable' : ''}${hasContent && (compareMode || activeTool === null) ? ' canvas-area-pan-ready' : ''}${hasContent && isSpacePanActive ? ' canvas-area-space-pan-ready' : ''}${isCanvasPanning ? ' canvas-area-panning' : ''}`}
            data-tour="canvas"
            onClickCapture={handleCanvasClickCapture}
            onPointerDownCapture={handleCanvasPointerDown}
            onPointerMove={handleCanvasPointerMove}
            onPointerUp={finishCanvasPan}
            onPointerCancel={finishCanvasPan}
            onLostPointerCapture={finishCanvasPan}
          >
            {!hasContent && (
              <button
                type="button"
                className="canvas-empty-upload-target"
                onClick={() => imageUploadRef.current?.openPicker()}
                aria-label={t('Открыть выбор изображения', 'Open image picker')}
              />
            )}
            <span className="corner corner-tl" />
            <span className="corner corner-tr" />
            <span className="corner corner-bl" />
            <span className="corner corner-br" />
            {!compareMode && editorMode === 'artist' && finalPreview?.has3D && finalPreview.shadeWarnings.some(Boolean) && (
              <div className={`shade-warning-hint${showShadeWarnings ? ' active' : ''}`}>
                {t('Ctrl: показать проблемные пиксели', 'Ctrl: show shade problem pixels')}
              </div>
            )}

            <div className="canvas-inner">
              {compareMode ? (
                <CompareView
                  leftData={compareData?.left   ?? null}
                  rightData={compareData?.right ?? null}
                  leftLabel={DITHERING_LABELS[compareLeft]}
                  rightLabel={DITHERING_LABELS[compareRight]}
                  width={pw} height={ph} scale={rasterScale} viewScale={displayScale} showGrid={showGrid}
                  splitPos={splitPos} onSplitPosChange={setSplitPos}
                />
              ) : (
                <PreviewCanvas
                  mode={textureMode}
                  imageData={previewImageData ?? imageData} paintData={imageData} originalData={originalData}
                  materialData={compositeImageData}
                  showOriginal={false} showGrid={showGrid}
                  width={pw} height={ph} scale={rasterScale} viewScale={displayScale}
                  cp={activePalette} blockSelection={blockSelection}
                  activeTool={activeTool}
                  paintBlock={paintBlock}
                  patternBlocks={patternBlocks}
                  brushSize={brushSize}
                  activeTextMeta={activeLayer?.isText ? activeLayer.text ?? null : null}
                  activeTextLocked={activeLayerLocked}
                  textLayers={layers
                    .filter(layer => layer.visible && layer.isText && layer.text)
                    .map(layer => ({ id: layer.id, text: layer.text!, locked: layer.locked }))}
                  otherLayersData={otherLayersData}
                  onRemoveBlock={handleRemoveBlock}
                  onImageUpdate={handleImageUpdate}
                  onToolChange={setActiveTool}
                  onPaintBlockChange={setPaintBlock}
                  onTextCreate={handleTextCreate}
                  onTextUpdate={handleTextUpdate}
                  onTextBeginEdit={handleTextBeginEdit}
                  onTextLayerSelect={id => setLayerState(previous => ({ ...previous, activeLayerId: id }))}
                  splitPos={imageData && originalData && showSplitLine ? splitPos : undefined}
                  onSplitPosChange={setSplitPos}
                  selectionMask={selectionMask}
                  onSelectionChange={setSelectionMask}
                  magicWandTolerance={magicWandTolerance}
                  magicWandContiguous={magicWandContiguous}
                  magicWandMode={magicWandMode}
                  activePattern={activePattern}
                  patternAnchorMode={patternAnchorMode}
                  gradientStops={gradientStops}
                  gradientDithering={gradientDithering}
                  warningMask={finalPreview?.shadeWarnings ?? null}
                  showWarningMask={editorMode === 'artist' && showShadeWarnings}
                  viewportPanning={isCanvasPanning}
                  editingDisabled={Boolean(activeLayer?.locked)}
                />
              )}
            </div>

            {processing && (
              <div className="processing-overlay">
                <div className="processing-overlay-inner">
                  <div className="processing-spinner" />
                  <span className="processing-label">{t('ОБРАБОТКА…', 'PROCESSING…')} {DITHERING_LABELS[dithering].toUpperCase()}</span>
                  <span className="processing-pct">{processingProgress}%</span>
                  {showCancel && (
                    <button className="processing-cancel-btn" onClick={handleCancelProcessing}><IconGlyph icon={mkIcons.close} size={14} /> {t('ОТМЕНА', 'CANCEL')}</button>
                  )}
                </div>
                <div className="processing-bar-track">
                  <div className="processing-bar-fill" style={{ width: `${processingProgress}%` }} />
                </div>
              </div>
            )}
          </div>

        </main>

        {showPatternEditor && activePattern && (
          <PatternEditorPopup
            pattern={activePattern}
            paintBlock={paintBlock}
            cp={activePalette}
            blockSelection={blockSelection}
            mapMode={mapMode}
            onSave={p => setSavedPatterns(prev => prev.map(x => x.id === p.id ? p : x))}
            onClose={() => setShowPatternEditor(false)}
          />
        )}

        <div
          className="panel-resizer panel-resizer-right"
          role="separator"
          aria-orientation="vertical"
          aria-label={t('Изменить ширину панели палитры', 'Resize palette panel')}
          tabIndex={0}
          onPointerDown={event => handlePanelResizeStart('right', event)}
          onPointerMove={handlePanelResizeMove}
          onPointerUp={handlePanelResizeEnd}
          onPointerCancel={handlePanelResizeEnd}
          onKeyDown={event => handlePanelResizeKeyDown('right', event)}
        />

        {/* ── RIGHT PANEL ── */}
        {tabletRightOpen && <div className="tablet-drawer-backdrop" onClick={() => setTabletRightOpen(false)} />}
        <aside id="editor-palette-panel" className={`panel panel-right${tabletRightOpen ? ' drawer-open' : ''}${editorMode === 'artist' ? ' artist-mode' : ''}`} data-tour="palette-panel">
          <div className="panel-scroll">
            {editorMode === 'artist' && (
              <>
                <LayersPanel
                  layers={layers}
                  activeLayerId={activeLayerId}
                  onSetActive={id => setLayerState(prev => ({ ...prev, activeLayerId: id }))}
                  onToggleVisible={handleToggleLayerVisible}
                  onAdd={handleAddLayer}
                  onDelete={handleDeleteLayer}
                  onRename={handleRenameLayer}
                  onMoveUp={handleMoveLayerUp}
                  onMoveDown={handleMoveLayerDown}
                  onOpacityChange={handleOpacityChange}
                  onToggleLock={handleToggleLock}
                  onMoveLayer={handleMoveLayer}
                  onMergeDown={handleMergeDown}
                  onMergeVisible={handleMergeVisible}
                  groups={layerGroups}
                  onCreateGroup={handleCreateGroup}
                  onDeleteGroup={handleDeleteGroup}
                  onToggleGroupCollapse={handleToggleGroupCollapse}
                />
                <div className="project-btns">
                  <button className="project-btn" onClick={handleSaveProject} title={t('Скачать проект (.mapkluss)', 'Download project (.mapkluss)')}>
                    <IconGlyph icon={mkIcons.saveEditor} /> {t('Сохранить проект', 'Save project')}
                  </button>
                  <button className="project-btn" onClick={handleLoadProject} title={t('Загрузить проект (.mapkluss)', 'Load project (.mapkluss)')}>
                    <IconGlyph icon={mkIcons.uploadEditor} /> {t('Загрузить проект', 'Load project')}
                  </button>
                </div>
              </>
            )}
            <div className="mobile-palette-content">
              {workbenchMode && (
                <MaterialsList
                  compact
                  imageData={compareMode ? (compareData?.left ?? null) : compositeImageData}
                  cp={activePalette}
                  blockSelection={blockSelection}
                  mapGrid={mapGrid}
                  onFocusPalette={handleFocusPaletteBlock}
                  onExcludeFromPalette={handleRemoveBlock}
                  onReplaceInPalette={handleReplaceBlock}
                  minecraftVersion={minecraftVersion}
                  platformMode={platformMode}
                />
              )}
              <div className="version-selector-row" data-tour="minecraft-version">
                <span className="version-selector-label">{t('Версия', 'Version')}</span>
                <select
                  className="version-selector-select"
                  value={minecraftVersion}
                  onChange={e => handleMinecraftVersionChange(e.target.value as MinecraftVersion)}
                >
                  {(buildTechnique === 'suppression_two_layer' ? SUPPRESSION_TARGET_VERSIONS : VALID_VERSIONS).map(v => (
                    <option key={v} value={v}>{getVersionLabel(v)}</option>
                  ))}
                </select>
              </div>
              <div className="version-selector-row">
                <span className="version-selector-label">{t('Платформа', 'Platform')}</span>
                {isPlatformLockedForBuildTechnique(buildTechnique) ? (
                  <div
                    className="version-selector-lock"
                    title={t('Two-layer работает только в Java Edition', 'Two-layer is Java Edition only')}
                    aria-label={t('Платформа Java закреплена для Two-layer', 'Java platform is locked for Two-layer')}
                  >Java</div>
                ) : (
                  <select
                    className="version-selector-select"
                    value={platformMode}
                    onChange={e => handlePlatformModeChange(e.target.value as PlatformMode)}
                  >
                    <option value="java">Java</option>
                    <option value="bedrock">Bedrock</option>
                  </select>
                )}
              </div>
              <PaletteEditor
                blockSelection={blockSelection}
                onSelectionChange={handleSelectionChange}
                paletteSize={activePalette.colors.length}
                disabled={processing}
                minecraftVersion={minecraftVersion}
                platformMode={platformMode}
                suppressionMode={buildTechnique === 'suppression_two_layer'}
                compact={workbenchMode}
                focusBlock={paletteFocus}
              />
              <div className="panel-divider"></div>
              {mapMode === '3d' && (
                <div className={`support-block-section${buildTechnique === 'suppression_two_layer' ? ' support-block-section--suppression' : ''}`}>
                  <div className="support-block-section-title">
                    {buildTechnique === 'suppression_two_layer'
                      ? t('Блок перепада высоты', 'Height-step block')
                      : t('Опорный блок (3D)', 'Support block (3D)')}
                  </div>
                  {buildTechnique === 'suppression_two_layer' && (
                    <div className="suppression-filler-help">
                      {t(
                        'Это часть двухслойного арта для нужного оттенка, а не основание или разметка.',
                        'This is part of the two-layer art for the required shade, not a base or marker.',
                      )}
                    </div>
                  )}
                  <div className="support-block-grid">
                    {SUPPORT_BLOCKS_PALETTE
                      .filter(b => buildTechnique !== 'suppression_two_layer' || isSuppressionSafeBlockName(b.nbt))
                      .map(b => (
                      <button
                        key={b.nbt}
                        className={`support-block-item${supportBlock === b.nbt ? ' active' : ''}`}
                        onClick={() => setSupportBlock(b.nbt)}
                        title={t(b.ru, b.en)}
                      >
                        <span
                          className="support-block-sprite"
                          style={{
                            backgroundImage: `url(${SPRITE_URL})`,
                            backgroundPosition: `-${b.blockId * 32}px -${b.csId * 32}px`,
                          }}
                        />
                        <span className="support-block-item-label">{t(b.ru, b.en)}</span>
                      </button>
                      ))}
                    {buildTechnique !== 'suppression_two_layer' && (
                      <div className="support-none-depth">
                      <button
                        className={`support-block-item support-none-btn${supportBlock === 'air' ? ' active' : ''}`}
                        onClick={() => setSupportBlock('air')}
                        title={t('Без опорных блоков', 'No support blocks')}
                      >
                        <span className="support-block-no-icon">∅</span>
                        <span className="support-block-item-label">{t('Нет', 'None')}</span>
                      </button>
                      <div className={`support-depth-group${supportBlock === 'air' ? ' disabled' : ''}`}>
                        <span className="support-mode-label">{t('Глубина', 'Depth')}</span>
                        {([1, 2] as const).map(m => (
                          <button
                            key={m}
                            className={`support-mode-btn${supportMode === m ? ' active' : ''}`}
                            onClick={() => setSupportMode(m)}
                            title={getSupportModeTitles(t)[m]}
                            disabled={supportBlock === 'air'}
                          >{SUPPORT_MODE_LABELS[m]}</button>
                        ))}
                      </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="mobile-export-content">
              <MaterialsList
                imageData={compareMode ? (compareData?.left ?? null) : compositeImageData}
                cp={activePalette}
                blockSelection={blockSelection}
                mapGrid={mapGrid}
                mapMode={mapMode}
                staircaseMode={staircaseMode}
                supportBlock={buildTechnique === 'suppression_two_layer' ? 'air' : supportBlock}
                supportMode={buildTechnique === 'suppression_two_layer' ? undefined : supportMode}
                onFocusPalette={handleFocusPaletteBlock}
                onExcludeFromPalette={handleRemoveBlock}
                onReplaceInPalette={handleReplaceBlock}
                minecraftVersion={minecraftVersion}
                platformMode={platformMode}
              />
            </div>
          </div>
          <div className="panel-footer mobile-export-content">
            <ExportPanel
              imageData={compositeImageData}
              previewImageData={previewImageData}
              compareData={compareData}
              compareMode={compareMode}
              dithering={dithering}
              compareLeft={compareLeft}
              compareRight={compareRight}
              mapGrid={mapGrid}
              mapMode={mapMode}
              staircaseMode={staircaseMode}
              activePalette={activePalette}
              blockSelection={blockSelection}
              disabled={processing}
              supportBlock={supportBlock}
              supportMode={supportMode}
              artistMode={editorMode === 'artist'}
              hybridLayers={layers.filter(l => l.visible && l.imageData).map(l => ({
                imageData: l.imageData!,
                mapMode: l.mapMode ?? '2d',
                staircaseMode: l.staircaseMode ?? 'optimized',
              }))}
              activeLayerExport={activeLayer?.imageData ? {
                imageData: activeLayer.imageData,
                mapMode: activeLayer.mapMode ?? '2d',
                staircaseMode: activeLayer.staircaseMode ?? 'optimized',
              } : undefined}
              sourceImage={sourceImage}
              intensity={intensity}
              adjustments={adjustments}
              bnScale={bnScale}
              platformMode={platformMode}
              minecraftVersion={minecraftVersion}
              buildTechnique={buildTechnique}
              onCreateTracker={compositeImageData ? () => setTrackerMaterials(sessionMaterials) : undefined}
              onExportGifPack={gifProject ? handleExportGifLitematicPack : undefined}
              onExportCompleted={() => {
                if (platformMode !== 'java' || minecraftContinuationDismissedRef.current) return;
                setMinecraftContinuation({ source: 'export', minecraftVersion });
              }}
            />
          </div>
        </aside>

        {/* ── MOBILE TAB BAR ── */}
        <div className="mobile-tab-bar">
          <button className={`mobile-tab-btn${mobileTab === 'settings' ? ' active' : ''}`} onClick={() => setMobileTab('settings')}>
            <IconGlyph icon={mkIcons.sliders} className="mobile-tab-icon" />
            <span className="mobile-tab-label">{t('Настройки', 'Settings')}</span>
          </button>
          <button className={`mobile-tab-btn${mobileTab === 'palette' ? ' active' : ''}`} onClick={() => setMobileTab('palette')}>
            <IconGlyph icon={mkIcons.palette} className="mobile-tab-icon" />
            <span className="mobile-tab-label">{t('Палитра', 'Palette')}</span>
          </button>
          <button className={`mobile-tab-btn${mobileTab === 'export' ? ' active' : ''}`} onClick={() => setMobileTab('export')}>
            <IconGlyph icon={mkIcons.download} className="mobile-tab-icon" />
            <span className="mobile-tab-label">{t('Экспорт', 'Export')}</span>
          </button>
        </div>
      </div>

      {/* ── STATUS BAR ── */}
      <div className="status-bar">
        <span><i className="status-dot" aria-hidden="true" /> {DITHERING_LABELS[dithering].toUpperCase()}</span>
        <span><i className="status-dot" aria-hidden="true" /> {mapGrid.wide}×{mapGrid.tall} MAPS</span>
        <span><i className="status-dot" aria-hidden="true" /> {activePalette.colors.length} COLORS</span>
        <span><i className="status-dot" aria-hidden="true" /> {editorBuildMode(mapMode, buildTechnique).replace('suppression_two_layer', 'TWO-LAYER').toUpperCase()}</span>
        <span><i className="status-dot" aria-hidden="true" /> {zoom}%</span>
        {hasContent && <span><i className="status-dot" aria-hidden="true" /> {pw}×{ph}px</span>}
        {autosaveLabel && (
          <span
            className={`status-autosave status-autosave-${autosaveState.status}`}
            role={autosaveState.status === 'error' || autosaveState.status === 'too-large' ? 'alert' : 'status'}
          >
            <i className="status-dot" aria-hidden="true" /> {autosaveLabel}
          </span>
        )}
        <span className="status-spacer" />
        <nav className="status-links" aria-label={t('Полезные страницы', 'Useful pages')}>
          <a href="/examples/">{t('Примеры', 'Examples')}</a>
          <a href="/wiki/">Wiki</a>
          <a href="/minecraft-map-art-generator/">{t('Гайд', 'Guide')}</a>
        </nav>
        <span className="status-credit">Made by SmetankaKluss</span>
        <a className="status-tg" href="https://t.me/SmetankaKluss" target="_blank" rel="noopener noreferrer">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor" aria-hidden="true">
            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.248l-1.97 9.269c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L8.32 14.173l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.496.413z"/>
          </svg>
          @SmetankaKluss
        </a>
      </div>
    </div>

    {/* ── Crop modal ── */}
    {showCropModal && uploadedImageRef.current && (
      <CropModal
        sourceImage={uploadedImageRef.current}
        targetW={pw} targetH={ph}
        onApply={handleCropApply}
        onCancel={() => setShowCropModal(false)}
      />
    )}

    {/* ── New Canvas modal ── */}
    {showNewCanvasModal && (
      <NewCanvasModal
        currentGrid={mapGrid}
        paletteColors={activePalette.colors}
        onConfirm={handleCreateBlankCanvas}
        onClose={() => setShowNewCanvasModal(false)}
      />
    )}

    {/* ── Save project modal ── */}
    {showSaveModal && (
      <SaveProjectModal
        thumbnail={saveThumbnail}
        defaultName={`${mapGrid.wide}×${mapGrid.tall} — ${new Date().toLocaleDateString()}`}
        onSave={(name) => { handleSaveProjectToHistory(name); setShowSaveModal(false); }}
        onClose={() => setShowSaveModal(false)}
      />
    )}

    {/* ── Projects panel ── */}
    {showProjectsPanel && (
      <ProjectsPanel
        onLoad={(id) => handleLoadProjectFromHistory(id)}
        onClose={() => setShowProjectsPanel(false)}
      />
    )}

    {/* ── Cloud arts folder ── */}
    {showCloudArtsPanel && (
      <CloudArtsPanel
        onClose={() => setShowCloudArtsPanel(false)}
        defaultEmail={cloudUserEmail}
        onOpenArt={(artId) => {
          setShowCloudArtsPanel(false);
          const nextUrl = new URL(window.location.href);
          nextUrl.searchParams.delete('companionImport');
          nextUrl.searchParams.delete('artVersion');
          nextUrl.searchParams.set('art', artId);
          window.history.replaceState(null, '', nextUrl.toString());
          cloudImportLoadedRef.current = false;
          void handleCloudImport();
        }}
      />
    )}

    {showCloudSaveModal && (
      <CloudSaveModal
        defaultTitle={currentCloudTitle || `MapKluss_${mapGrid.wide}x${mapGrid.tall}_${new Date().toISOString().slice(0, 10)}`}
        defaultPrivacy={currentCloudPrivacy}
        isUpdate={Boolean(currentCloudArtId)}
        mapGrid={mapGrid}
        busy={cloudSaving}
        onSave={(input) => void handleConfirmCloudSave(input)}
        onClose={() => { if (!cloudSaving) setShowCloudSaveModal(false); }}
      />
    )}

    {minecraftContinuation && (
      <ContinueInMinecraftPrompt
        minecraftVersion={minecraftContinuation.minecraftVersion}
        source={minecraftContinuation.source}
        onSaveToCloud={() => {
          setMinecraftContinuation(null);
          void handleSaveCurrentArtToCloud();
        }}
        onClose={() => {
          minecraftContinuationDismissedRef.current = true;
          setMinecraftContinuation(null);
        }}
      />
    )}

    {/* ── Perspective preview modal ── */}
    {showPerspective && (
      <Suspense fallback={null}>
        <PerspectiveModal
          imageData={compareMode ? (compareData?.left ?? previewImageData) : (previewImageData ?? compositeImageData)}
          cp={activePalette}
          blockSelection={blockSelection}
          mapMode={mapMode}
          staircaseMode={staircaseMode}
          supportMode={supportMode}
          supportBlock={supportBlock}
          mapGrid={mapGrid}
          previewMode={previewMode}
          onPreviewModeChange={setPreviewMode}
          onClose={() => setShowPerspective(false)}
        />
      </Suspense>
    )}

    {/* ── Build tracker modal ── */}
    {trackerMaterials && compositeImageData && (
      <BuildTrackerModal
        materials={trackerMaterials}
        imageData={compositeImageData}
        previewImageData={previewImageData ?? undefined}
        mapGrid={mapGrid}
        cp={exportRef.current.activePalette}
        blockGroups={exportRef.current.blockSelection as BlockSelection}
        onClose={() => setTrackerMaterials(null)}
      />
    )}

    {/* ── GIF export modal ── */}
    {gifFrames && (
      <Suspense fallback={null}>
        <GifModal
          gifFrames={gifFrames}
          mapGrid={mapGrid}
          palette={activePalette}
          dithering={dithering}
          intensity={intensity}
          klussParams={klussParams}
          adjustments={effectiveAdjustments}
          bnScale={bnScale}
          blockSelection={blockSelection}
          onClose={() => setGifFrames(null)}
          onOpenAsProject={handleOpenAsGifProject}
        />
      </Suspense>
    )}

    {/* ── GIF Filmstrip ── */}
    {gifProject && (
      <GifFilmstrip
        project={gifProject}
        onFrameSelect={handleGifFrameSelect}
        onConfigChange={handleGifProjectConfigChange}
        onClose={handleCloseGifProject}
      />
    )}

    {/* ── Tour selector modal ── */}
    {showTourSelector && (
      <TourSelector
        lang={lang}
        hasArtwork={hasContent}
        isWelcome={tourSelectorIsWelcome}
        onClose={closeTourSelector}
        onSelect={tourType => {
          setShowTourSelector(false);
          setTourSelectorIsWelcome(false);
          startTour(tourType);
        }}
      />
    )}
    </>
  );
}
