// MapKluss modification, 2026-09-23: standalone Vite build at /classic/.
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: '/classic/',
  plugins: [react()],
  build: { assetsInlineLimit: 0 },
});
