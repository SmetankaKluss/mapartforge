// MapKluss modification, 2026-09-23: fork navigation; original generator unchanged.
import { Link } from 'react-router-dom';
import './header.css';

export default function Header({ getLocaleString, countryCode }) {
  const languagePath = ![undefined, 'en'].includes(countryCode) ? `${countryCode}/` : '';
  return (
    <div className="header">
      <h3>
        <Link to={`/${languagePath}faq`}>{getLocaleString('FAQ/FAQ')}</Link>
        <a href="https://youtu.be/j-4RXPkJKU8" target="_blank" rel="noopener noreferrer">{getLocaleString('FAQ/VIDEO-TUTORIAL')}</a>
        <a href="https://github.com/rebane2001/mapartcraft" target="_blank" rel="noopener noreferrer">MapartCraft</a>
        <a href="/classic/mapkluss-classic-source.zip" download>{countryCode === 'ru' ? 'Исходный код' : 'Source code'}</a>
        <a className="studioLink" href="/">{countryCode === 'ru' ? 'Редактор MapKluss' : 'MapKluss editor'} ↗</a>
      </h3>
    </div>
  );
}
