import { buildComputedPalette } from './mapklussCore/dithering';
import { PALETTE } from './mapklussCore/palette';
import { sanitizeSelectionForSuppression } from './mapklussCore/suppressionPalette';
import { COLOUR_ROWS, type BlockSelection } from './mapklussCore/paletteBlocks';
import { isBlockAvailableOnPlatform } from './mapklussCore/platformMode';
import { isBlockAvailable } from './mapklussCore/versionPresets';
import type { MinecraftVersion } from './mapklussCore/versionPresets';

function classicSelection(selectedBlocks: Record<string, string>): BlockSelection {
  return Object.fromEntries(
    Object.entries(selectedBlocks).map(([row, id]) => [Number(row), id === '-1' ? [] : [Number(id)]]),
  );
}

export function classicMapKlussSelection(
  selectedBlocks: Record<string, string>, minecraftVersion: MinecraftVersion, shades: 1 | 3,
) {
  const selected = classicSelection(selectedBlocks);
  const resolved: BlockSelection = {};
  const replacements = [];
  for (const row of COLOUR_ROWS) {
    const requested = selected[row.csId]?.[0];
    if (requested === undefined) { resolved[row.csId] = []; continue; }
    const available = row.blocks.filter(block =>
      isBlockAvailable(block.nbtName, minecraftVersion)
      && isBlockAvailableOnPlatform(block.nbtName, 'java'),
    );
    const block = available.find(entry => entry.blockId === requested) ?? available[0];
    resolved[row.csId] = block ? [block.blockId] : [];
    if (block?.blockId !== requested) {
      replacements.push({
        color: row.colourName,
        from: row.blocks.find(entry => entry.blockId === requested)?.displayName ?? String(requested),
        to: block?.displayName ?? 'excluded',
      });
    }
  }
  const colors = PALETTE.filter(color =>
    (shades === 1 ? color.shade === 1 : color.shade <= 2)
    && (resolved[color.baseId - 1]?.length ?? 0) > 0,
  );
  return { selection: resolved, replacements, colors };
}

export function classicTwoLayerSelection(
  selectedBlocks: Record<string, string>,
  minecraftVersion: MinecraftVersion,
) {
  const selected = classicSelection(selectedBlocks);
  const safe = sanitizeSelectionForSuppression(selected, minecraftVersion, 'java');
  const replacements = Object.entries(selected).filter(([row, ids]) =>
    ids.length > 0 && safe[Number(row)]?.[0] !== ids[0],
  ).map(([row, ids]) => {
    const colourRow = COLOUR_ROWS.find(entry => entry.csId === Number(row));
    return {
      color: colourRow?.colourName ?? `#${Number(row) + 1}`,
      from: colourRow?.blocks.find(block => block.blockId === ids[0])?.displayName ?? String(ids[0]),
      to: colourRow?.blocks.find(block => block.blockId === safe[Number(row)]?.[0])?.displayName ?? 'excluded',
    };
  });
  const colors = PALETTE.filter(color => color.shade <= 2 && (safe[color.baseId - 1]?.length ?? 0) > 0);
  return { safe, replacements, colors };
}

export function classicTwoLayerPalette(
  selectedBlocks: Record<string, string>,
  minecraftVersion: MinecraftVersion,
  matchMode: 'oklab' | 'rgb',
) {
  const selection = classicTwoLayerSelection(selectedBlocks, minecraftVersion);
  return { ...selection, palette: buildComputedPalette(selection.colors, matchMode) };
}
