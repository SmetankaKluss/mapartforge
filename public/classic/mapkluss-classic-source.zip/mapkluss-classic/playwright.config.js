import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests',
  timeout: 60000,
  use: { baseURL: process.env.CLASSIC_TEST_URL || 'http://127.0.0.1:5302', headless: true, channel: process.env.PLAYWRIGHT_CHANNEL },
  webServer: process.env.CLASSIC_TEST_URL ? undefined : { command: 'npm run preview', url: 'http://127.0.0.1:5302/classic/', reuseExistingServer: true },
});
