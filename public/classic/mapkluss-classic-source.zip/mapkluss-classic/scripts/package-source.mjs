// MapKluss Classic addition, 2026-09-23. GPL-3.0-only.
import { readFile, readdir, mkdir, writeFile, copyFile, stat, lstat } from 'node:fs/promises';
import path from 'node:path';
import JSZip from 'jszip';

const root = process.cwd();
const zip = new JSZip();
const stamp = new Date('2026-09-23T00:00:00Z');
async function addTree(relative) {
  const absolute = path.join(root, relative);
  const info = await lstat(absolute);
  if (info.isSymbolicLink()) throw new Error(`Source archive refuses symlink: ${relative}`);
  if (info.isDirectory()) {
    for (const name of (await readdir(absolute)).sort()) await addTree(`${relative}/${name}`);
  } else {
    zip.file(`mapkluss-classic/${relative}`, await readFile(absolute), { date: stamp });
  }
}

// Whitelist sources, never archive credentials, caches, .git or generated dist.
for (const entry of ['src', 'public', 'scripts', 'tests', 'tools', 'docs', 'DESIGN.md', 'LICENSE', 'README.md',
  'UPSTREAM-README.md', 'THIRD-PARTY-NOTICES.txt', 'PRODUCT.md', 'package.json',
  'package-lock.json', 'vite.config.js', 'playwright.config.js', 'index.html']) await addTree(entry);

await copyFile('LICENSE', 'dist/LICENSE.txt');
await copyFile('THIRD-PARTY-NOTICES.txt', 'dist/THIRD-PARTY-NOTICES.txt');
const lock = JSON.parse(await readFile('package-lock.json', 'utf8'));
for (const [location, pkg] of Object.entries(lock.packages)) {
  if (!location || pkg.dev) continue;
  const names = await readdir(location);
  for (const file of names.filter(name => /^(license|licence|copying|notice)([.-]|$)/i.test(name))) {
    if (!(await stat(path.join(location, file))).isFile()) continue;
    const relative = `licenses/npm/${location.replaceAll('node_modules/', '')}/${file}`;
    await mkdir(path.dirname(`dist/${relative}`), { recursive: true });
    await copyFile(path.join(location, file), `dist/${relative}`);
    zip.file(`mapkluss-classic/${relative}`, await readFile(path.join(location, file)), { date: stamp });
  }
}
zip.forEach((name, entry) => { entry.date = stamp; });
await writeFile('dist/mapkluss-classic-source.zip', await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));

// Static hosting must serve every language and FAQ on a direct visit/refresh.
const locales = (await readdir('src/locale', { withFileTypes: true })).filter(entry => entry.isDirectory()).map(entry => entry.name);
for (const route of ['faq', ...locales.flatMap(locale => [locale, `${locale}/faq`])]) {
  await mkdir(`dist/${route}`, { recursive: true });
  await copyFile('dist/index.html', `dist/${route}/index.html`);
  await copyFile('dist/index.html', `dist/${route}.html`);
}
const packageVersion = JSON.parse(await readFile('package.json', 'utf8')).version;
await writeFile('dist/classic-manifest.json', JSON.stringify({ name: 'MapKluss Classic', version: packageVersion, upstream: '0f24df5d7a913f978bdd4738de95bc11461d497e', license: 'GPL-3.0-only', source: 'mapkluss-classic-source.zip' }, null, 2));
console.log('Packaged GPL source, dependency notices and static routes.');
