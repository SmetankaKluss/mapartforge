# MapKluss Classic Cloud bridge source

Copyright 2026 SmetankaKluss. Original MIT license: LICENSE.
Included with the GPL-3.0-only Classic application; MIT notices are preserved.
See ../mapkluss-classic/LICENSE for the combined application's GPL terms.

This source is packaged from the same host checkout as the browser bridge.
The complete src tree is included to preserve transitive modules and assets.
No account credentials or private server configuration are required to build.

## Rebuild

Use Node.js 22.12 or newer. From this directory run:

    npm ci
    npx vite build --config classic-cloud.vite.config.mjs

The output is dist/classic-cloud-api.js and its generated chunks. Serve those
alongside Classic at the site root. The build uses the same code but does not
share chunk boundaries with the full Studio build. Cloud operations additionally
require a configured MapKluss-compatible API and a signed-in account; building
does not provide access to the hosted service or other users' data.
