import React, { Component } from 'react';

const DITHERING = {
  0: 'none', 1: 'floyd-steinberg', 2: 'yliluoma2', 3: 'yliluoma2',
  4: 'blue-noise', 5: 'stucki', 6: 'stucki', 7: 'floyd-steinberg',
  8: 'stucki', 9: 'atkinson', 10: 'jjn', 11: 'blue-noise',
  12: 'yliluoma2', 13: 'kluss',
};

let bridgePromise;
const SHARED_AUTH_STORAGE_KEY = 'sb-opxgnyadxybceldaokdi-auth-token';

function hasSharedSession() {
  try {
    return Boolean(JSON.parse(window.localStorage.getItem(SHARED_AUTH_STORAGE_KEY))?.access_token);
  } catch {
    return false;
  }
}

function cloudBridge() {
  if (!bridgePromise) bridgePromise = import(/* @vite-ignore */ '/classic-cloud-api.js').then(() => {
    if (!window.MapKlussClassicCloud) throw new Error('Cloud bridge did not initialize.');
    return window.MapKlussClassicCloud;
  });
  return bridgePromise;
}

export default class ClassicCloud extends Component {
  state = { account: null, checking: true, busy: false, message: '', savedId: null };
  mounted = false;

  componentDidMount() {
    this.mounted = true;
    window.addEventListener('focus', this.onWindowFocus);
    window.addEventListener('storage', this.onStorageChange);
    if (hasSharedSession()) this.checkAccount();
    else this.setState({ checking: false });
  }

  componentWillUnmount() {
    this.mounted = false;
    window.removeEventListener('focus', this.onWindowFocus);
    window.removeEventListener('storage', this.onStorageChange);
  }

  onWindowFocus = () => {
    if (!this.state.account && !this.state.checking && hasSharedSession()) this.checkAccount();
  };

  onStorageChange = (event) => {
    if (event.key !== SHARED_AUTH_STORAGE_KEY) return;
    if (hasSharedSession()) this.checkAccount();
    else this.setState({ account: null, checking: false });
  };

  checkAccount = async () => {
    this.setState({ checking: true, message: '' });
    try {
      const bridge = await cloudBridge();
      const account = await bridge.getClassicCloudAccount();
      if (this.mounted) this.setState({ account, checking: false });
    } catch (error) {
      bridgePromise = null;
      if (this.mounted) this.setState({ checking: false, message: this.isRu() ? 'Облако сейчас недоступно. Повтори проверку.' : 'Cloud is unavailable. Try checking again.' });
    }
  };

  isRu() { return this.props.countryCode === 'ru'; }

  save = async () => {
    const {
      currentMaterialsData, selectedBlocks, optionValue_twoLayerVersion, optionValue_buildTechnique,
      optionValue_mapSize_x, optionValue_mapSize_y, optionValue_betterColour,
      optionValue_dithering, optionValue_ditheringIntensity, optionValue_supportBlock,
      uploadedImage_baseFilename,
    } = this.props;
    if (!this.state.account || !currentMaterialsData.pixelsData || this.state.busy || this.saveInFlight || optionValue_buildTechnique === 'standard') return;
    this.saveInFlight = true;
    try {
    const [{ resolveClassicSupportBlock }, { classicMapKlussSelection, classicTwoLayerSelection }] = await Promise.all([
      import('../../classicSupportBlock'),
      import('../../classicTwoLayerSelection'),
    ]);
    const twoLayer = optionValue_buildTechnique === 'suppression_two_layer';
    const supportBlock = optionValue_buildTechnique === 'mapkluss_2d'
      ? 'stone' : resolveClassicSupportBlock(optionValue_supportBlock, optionValue_twoLayerVersion);
    if (!supportBlock) {
      this.setState({ message: this.isRu() ? 'Выбери безопасный опорный блок из подсказок.' : 'Choose a safe support block from suggestions.' });
      return;
    }
    const mode = twoLayer || optionValue_buildTechnique === 'mapkluss_3d' ? '3d' : '2d';
    const resolved = twoLayer
      ? classicTwoLayerSelection(selectedBlocks, optionValue_twoLayerVersion)
      : classicMapKlussSelection(selectedBlocks, optionValue_twoLayerVersion, mode === '2d' ? 1 : 3);
    const selection = twoLayer ? resolved.safe : resolved.selection;
    if (!resolved.colors.length) {
      this.setState({ message: this.isRu() ? 'Выбери хотя бы один доступный блок.' : 'Select at least one available block.' });
      return;
    }
    if (resolved.replacements.length && !window.confirm(this.isRu()
      ? `Для ${optionValue_twoLayerVersion} будут заменены недоступные блоки (${resolved.replacements.length}). Сохранить с заменами?`
      : `${resolved.replacements.length} unavailable blocks will be replaced for ${optionValue_twoLayerVersion}. Save with replacements?`)) return;

    const title = (uploadedImage_baseFilename || 'Classic art').trim().slice(0, 80);
    const colorMatch = optionValue_betterColour ? 'oklab' : 'rgb';
    this.setState({ busy: true, message: this.isRu() ? 'Сохраняем в облако…' : 'Saving to Cloud…', savedId: null });
      const bridge = await cloudBridge();
      const savedId = await bridge.saveClassicToCloud({
        title,
        pixels: new Uint8ClampedArray(currentMaterialsData.pixelsData),
        grid: { wide: optionValue_mapSize_x, tall: optionValue_mapSize_y },
        colors: resolved.colors,
        blockSelection: selection,
        mode,
        buildTechnique: twoLayer ? 'suppression_two_layer' : 'standard',
        minecraftVersion: optionValue_twoLayerVersion,
        supportBlock,
        dithering: DITHERING[optionValue_dithering] || 'none',
        intensity: optionValue_ditheringIntensity,
        bnScale: this.props.optionValue_bnScale,
        colorMatch,
      });
      if (this.mounted) this.setState({ busy: false, savedId, message: this.isRu() ? 'Сохранено в облаке MapKluss.' : 'Saved to MapKluss Cloud.' });
    } catch (error) {
      if (this.mounted) this.setState({ busy: false, message: `${this.isRu() ? 'Не удалось сохранить' : 'Could not save'}: ${error.message || String(error)}` });
    } finally {
      this.saveInFlight = false;
    }
  };

  render() {
    const { account, checking, busy, message, savedId } = this.state;
    const { currentMaterialsData, mapPreviewWorker_inProgress, optionValue_buildTechnique } = this.props;
    const ru = this.isRu();
    return <section className="classicCloud section" aria-label={ru ? 'Облако MapKluss' : 'MapKluss Cloud'}>
      <h2>{ru ? 'Облако MapKluss' : 'MapKluss Cloud'}</h2>
      <div className="classicCloudAccount">
        <span>{checking ? (ru ? 'Проверка аккаунта…' : 'Checking account…') : account ? account.email || (ru ? 'Аккаунт подключён' : 'Account connected') : (ru ? 'Вход не выполнен' : 'Not signed in')}</span>
        <button type="button" onClick={this.checkAccount} disabled={checking || busy}>{ru ? 'Проверить' : 'Check'}</button>
      </div>
      {account ? <button className="classicCloudSave" type="button" onClick={this.save} disabled={busy || checking || mapPreviewWorker_inProgress || !currentMaterialsData.pixelsData || optionValue_buildTechnique === 'standard'}>
        {busy ? (ru ? 'Сохранение…' : 'Saving…') : (ru ? 'Сохранить арт в облако' : 'Save art to Cloud')}
      </button> : <a className="classicCloudSignIn" href="/cloud" target="_blank" rel="noopener noreferrer">{ru ? 'Войти в аккаунт' : 'Sign in to account'}</a>}
      {account && optionValue_buildTechnique === 'standard' && <p className="classicCloudHint">{ru ? 'Для сохранения выбери способ стройки MapKluss 2D, 3D или Two-layer.' : 'Choose MapKluss 2D, 3D, or Two-layer to save.'}</p>}
      <a className="classicCloudLibrary" href={savedId ? `/?art=${encodeURIComponent(savedId)}` : '/cloud'} target="_blank" rel="noopener noreferrer">
        {savedId ? (ru ? 'Открыть арт в редакторе' : 'Open art in editor') : (ru ? 'Открыть библиотеку' : 'Open library')}
      </a>
      {message && <p className="classicCloudMessage" role="status">{message}</p>}
    </section>;
  }
}
