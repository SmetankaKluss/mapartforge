/** Classic keeps exports local; the Studio background cloud archive is not used here. */
export function downloadExportBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = Object.assign(document.createElement('a'), { href: url, download: filename });
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
