// MapKluss Classic interface palettes. Artwork and block colours are never themed.
export const CLASSIC_THEME_STORAGE_KEY = 'mapkluss_classic_ui_theme';
export const CLASSIC_THEMES = [
  { id: 'classic', label: 'MapKluss Classic', scheme: 'dark', colors: ['#111116', '#202027', '#ededf1', '#b8b8c4', '#83ed95', '#a0f2ba', '#122519', '#c3b0ff', '#777780', '#ffb4b4', '#50b775'] },
  { id: 'deep-ocean', label: 'Deep Ocean', scheme: 'dark', colors: ['#07141b', '#112a35', '#d9eef2', '#a9c8cf', '#31d8e8', '#62e3ee', '#04171b', '#8cecf3', '#4f7480', '#ff7180', '#20b9c9'] },
  { id: 'ember-forge', label: 'Ember Forge', scheme: 'dark', colors: ['#15100f', '#2c201b', '#f2ded4', '#c9aa9c', '#ff784d', '#ff946f', '#1b0904', '#ffb66f', '#895c49', '#ff7180', '#dd5631'] },
  { id: 'amethyst', label: 'Amethyst', scheme: 'dark', colors: ['#100e18', '#231c33', '#ebe3f7', '#c1b4d8', '#bc94ff', '#cfb1ff', '#130922', '#dbc6ff', '#705b8c', '#ff7898', '#986bdc'] },
  { id: 'acid-grove', label: 'Acid Grove', scheme: 'dark', colors: ['#07100a', '#132718', '#e7f5b8', '#b7ce91', '#c8ff3d', '#d8ff72', '#122000', '#f7ffb8', '#6f9951', '#ff668a', '#a4db20'] },
  { id: 'cobalt-pulse', label: 'Cobalt Pulse', scheme: 'dark', colors: ['#080b1a', '#18203c', '#e9edff', '#b7c0e8', '#8fa6ff', '#afbdff', '#090d25', '#e2e7ff', '#687ab4', '#ff6f91', '#6d82df'] },
  { id: 'signal-white', label: 'Signal White', scheme: 'light', colors: ['#dfe3e1', '#cbd2ce', '#111713', '#334039', '#095b2c', '#075a2b', '#ffffff', '#004fc4', '#3f4d45', '#971e30', '#044a23'] },
  { id: 'cobalt-print', label: 'Cobalt Print', scheme: 'light', colors: ['#cbd7f0', '#afc1e8', '#0d1735', '#253866', '#143793', '#102f82', '#ffffff', '#8c2f00', '#304a85', '#7a182b', '#0c266b'] },
  { id: 'solar-punch', label: 'Solar Punch', scheme: 'light', colors: ['#e7d84c', '#d7c83b', '#201a05', '#453b0c', '#51249d', '#431b86', '#ffffff', '#004c96', '#4b4208', '#81182b', '#35136e'] },
  { id: 'rose-oxide', label: 'Rose Oxide', scheme: 'light', colors: ['#d9a5b5', '#c98ea2', '#28101a', '#321924', '#420c25', '#35081d', '#ffffff', '#004f83', '#4d2334', '#450b14', '#260512'] },
];

const COLOR_TOKENS = ['bg', 'control', 'text', 'muted', 'accent', 'hover', 'on-accent', 'focus', 'border', 'error', 'progress'];

export function readClassicTheme() {
  const applied = document.documentElement.dataset.classicTheme;
  if (CLASSIC_THEMES.some(theme => theme.id === applied)) return applied;
  try {
    const stored = localStorage.getItem(CLASSIC_THEME_STORAGE_KEY) ?? localStorage.getItem('mapkluss_ui_theme');
    return CLASSIC_THEMES.some(theme => theme.id === stored) ? stored : 'classic';
  } catch {
    return 'classic';
  }
}

export function applyClassicTheme(id, persist = false) {
  const theme = CLASSIC_THEMES.find(option => option.id === id) ?? CLASSIC_THEMES[0];
  const root = document.documentElement;
  root.dataset.classicTheme = theme.id;
  root.style.colorScheme = theme.scheme;
  COLOR_TOKENS.forEach((token, index) => root.style.setProperty(`--classic-${token}`, theme.colors[index]));
  if (persist) {
    try {
      localStorage.setItem(CLASSIC_THEME_STORAGE_KEY, theme.id);
    } catch {
      // Storage can be disabled; the selected theme still works in this tab.
    }
  }
}
