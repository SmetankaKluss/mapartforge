import { useState, useEffect } from 'react';
import type { PaintBlock } from './previewCanvasShared';
import type { ComputedPalette } from '../lib/dithering';
import type { PatternDefinition } from '../lib/patternTool';
import { resizePattern } from '../lib/patternTool';
import type { BlockSelection } from '../lib/paletteBlocks';
import { IconGlyph } from './IconGlyph';
import { mkIcons } from './mkIcons';
import { useLocale } from '../lib/useLocale';
import { useDraggablePanel } from './useDraggablePanel';

interface Props {
  pattern: PatternDefinition;
  paintBlock: PaintBlock | null;
  cp: ComputedPalette;
  blockSelection: BlockSelection;
  mapMode?: '2d' | '3d';
  onSave: (p: PatternDefinition) => void;
  onClose: () => void;
}

function getBlockColor(block: PaintBlock, cp: ComputedPalette): string {
  const c = cp.colors.find(c => c.baseId === block.baseId && c.shade === block.shade)
    ?? cp.colors.find(c => c.baseId === block.baseId);
  return c ? `rgb(${c.r},${c.g},${c.b})` : 'transparent';
}

export function PatternEditorPopup({ pattern: initialPattern, paintBlock, cp, blockSelection, mapMode, onSave, onClose }: Props) {
  const { t } = useLocale();
  void blockSelection;
  void mapMode;
  const [pattern, setPattern] = useState<PatternDefinition>(initialPattern);
  const [widthInput, setWidthInput] = useState(String(initialPattern.width));
  const [heightInput, setHeightInput] = useState(String(initialPattern.height));
  const [isErasing, setIsErasing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const { panelRef, draggedStyle, isDragged, onDragHandlePointerDown } = useDraggablePanel();

  // Close on Escape only (no outside-click close — allows other popups to stay open)
  useEffect(() => {
    function onKey(e: KeyboardEvent) { if (e.key === 'Escape') onClose(); }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  function applySize() {
    const w = Math.max(1, Math.min(16, parseInt(widthInput) || pattern.width));
    const h = Math.max(1, Math.min(16, parseInt(heightInput) || pattern.height));
    if (w !== pattern.width || h !== pattern.height) {
      setPattern(resizePattern(pattern, w, h));
      setWidthInput(String(w));
      setHeightInput(String(h));
    }
  }

  function paintCell(idx: number, erase: boolean) {
    setPattern(prev => {
      const pixels = [...prev.pixels];
      pixels[idx] = erase ? null : (paintBlock && paintBlock.baseId !== -1 ? paintBlock : null);
      return { ...prev, pixels };
    });
  }

  function handleCellMouseDown(idx: number, e: React.MouseEvent) {
    e.preventDefault();
    const erase = e.button === 2 || !paintBlock || paintBlock.baseId === -1;
    setIsErasing(erase);
    setIsDragging(true);
    paintCell(idx, erase);
  }

  function handleCellMouseEnter(idx: number, e: React.MouseEvent) {
    if (!isDragging) return;
    e.preventDefault();
    paintCell(idx, isErasing);
  }

  function handleMouseUp() { setIsDragging(false); }

  const CELL_SIZE = Math.max(20, Math.min(48, Math.floor(240 / Math.max(pattern.width, pattern.height))));

  return (
    <div
      ref={panelRef}
      className={`pattern-editor-popup${isDragged ? ' is-dragged' : ''}`}
      style={draggedStyle}
      onMouseUp={handleMouseUp}
      onContextMenu={e => e.preventDefault()}
      role="dialog"
      aria-modal="false"
      aria-labelledby="pattern-editor-title"
    >
      <div
        className="pattern-editor-header"
        onPointerDown={onDragHandlePointerDown}
      >
        <span className="pattern-editor-title" id="pattern-editor-title">{t('Редактор паттерна', 'Pattern editor')}</span>
        <button className="pattern-editor-close" onClick={onClose} aria-label={t('Закрыть', 'Close')}><IconGlyph icon={mkIcons.close} /></button>
      </div>

      {/* Size controls */}
      <div className="pattern-editor-size-row">
        <label htmlFor="pattern-width" title={t('Ширина', 'Width')}>{t('Ш', 'W')}</label>
        <input
          id="pattern-width"
          aria-label={t('Ширина паттерна', 'Pattern width')}
          type="number" min={1} max={16} value={widthInput}
          onChange={e => setWidthInput(e.target.value)}
          onBlur={applySize}
          onKeyDown={e => e.key === 'Enter' && applySize()}
          className="pattern-editor-size-input"
        />
        <label htmlFor="pattern-height" title={t('Высота', 'Height')}>{t('В', 'H')}</label>
        <input
          id="pattern-height"
          aria-label={t('Высота паттерна', 'Pattern height')}
          type="number" min={1} max={16} value={heightInput}
          onChange={e => setHeightInput(e.target.value)}
          onBlur={applySize}
          onKeyDown={e => e.key === 'Enter' && applySize()}
          className="pattern-editor-size-input"
        />
        <button className="pattern-editor-apply-btn" onClick={applySize}>{t('Применить', 'Apply')}</button>
      </div>

      {/* Pixel grid */}
      <div
        className="pattern-editor-grid"
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${pattern.width}, ${CELL_SIZE}px)`,
          gap: 1,
          userSelect: 'none',
        }}
      >
        {pattern.pixels.map((block, idx) => (
          <button
            key={idx}
            type="button"
            className="pattern-editor-cell"
            style={{
              width: CELL_SIZE,
              height: CELL_SIZE,
              background: block && block.baseId !== -1
                ? getBlockColor(block, cp)
                : undefined,
              cursor: 'crosshair',
            }}
            onMouseDown={e => { if (e.button === 0 || e.button === 2) handleCellMouseDown(idx, e); }}
            onMouseEnter={e => handleCellMouseEnter(idx, e)}
            onClick={() => paintCell(idx, false)}
            onKeyDown={e => {
              if (e.key === 'Backspace' || e.key === 'Delete') {
                e.preventDefault();
                paintCell(idx, true);
              }
            }}
            aria-label={t(
              `Ячейка ${Math.floor(idx / pattern.width) + 1}, ${idx % pattern.width + 1}: ${block?.displayName ?? 'пусто'}`,
              `Cell ${Math.floor(idx / pattern.width) + 1}, ${idx % pattern.width + 1}: ${block?.displayName ?? 'empty'}`,
            )}
          />
        ))}
      </div>

      {/* Info row */}
      <div className="pattern-editor-info">
        <span className="pattern-editor-hint">{t('ЛКМ — красить, ПКМ или Delete — стереть', 'LMB paints; RMB or Delete erases')}</span>
        <span className="pattern-editor-dims">{pattern.width}×{pattern.height}</span>
      </div>

      {/* Actions */}
      <div className="pattern-editor-actions">
        <button className="pattern-editor-clear-btn" onClick={() => setPattern(p => ({ ...p, pixels: Array(p.width * p.height).fill(null) }))}>
          {t('Очистить', 'Clear')}
        </button>
        <button className="pattern-editor-save-btn" onClick={() => { onSave(pattern); onClose(); }}>
          {t('Сохранить паттерн', 'Save pattern')}
        </button>
      </div>
    </div>
  );
}
