# Classic Route

Independent /classic/ GPLv3 application, not a Studio display mode.
Desktop: palette left, preview center, settings/downloads right, materials below.
Mobile: preserve upstream reading order, including the long palette before
preview and settings. Do not replace it with a newly arranged dashboard.

Preserve presets, NBT/map.dat, materials and online preview. The familiar
settings area also exposes MapKluss 2D/3D Litematic, Two-layer Companion ZIP
and the MapKluss dithering modes. Version 1.2 adds an account panel and
private Cloud save for MapKluss 2D/3D/Two-layer methods through the host site's
same-origin MIT Cloud bridge. The resulting one-layer v4 project can open in
Studio and Companion. It does not retain the original source-image reprocessing
or reopen arbitrary multi-layer Cloud projects in Classic. Standalone Classic
uses a disabled bridge stub. No brushes or Lens controls.
Header: MapKluss Classic, flags, FAQ, tutorial, upstream/source, return to Studio.
Footer: authors, corresponding source archive, GPLv3, third-party notices.
Use the original textures and real generated artwork with local Play/Tektur.

Visual checks: 2026-09-25 at 1440x1000 and 390x844. Preview zoom resizes the
document with the upstream 2x initial scale and 20% steps; panel wrapping and
small-preview controls remain usable. Large previews intentionally overflow
the document, never an inner scroll viewport. Expanded numeric fields fit 100.
Local browser verification only, not production deployment.
