// MapKluss Classic addition, 2026-09-23. GPL-3.0-only.
import { version } from '../../package.json';
export default function ClassicFooter({ russian }) {
  return (
    <footer className="classicFooter">
      <span>MapKluss Classic {version} · {russian ? "На основе" : "Based on"} <a href="https://github.com/rebane2001/mapartcraft">MapartCraft</a> · rebane2001 &amp; contributors</span>
      <span>
        <a href="/classic/mapkluss-classic-source.zip" download>{russian ? "Исходный код" : "Source code"}</a>
        <a href="/classic/LICENSE.txt">GPLv3</a>
        <a href="/classic/THIRD-PARTY-NOTICES.txt">{russian ? "Авторы и лицензии" : "Credits & licenses"}</a>
        <a href="https://rebane2001.com/mapartcraft/supporters" target="_blank" rel="noopener noreferrer">{russian ? "Поддержать автора MapartCraft" : "Support the MapartCraft author"}</a>
      </span>
    </footer>
  );
}
