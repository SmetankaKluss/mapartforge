import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import JSZip from 'jszip';
import NBTReader from '../src/components/mapart/nbtReader.js';
import packageInfo from '../package.json' with { type: 'json' };

test('support destinations, current version and license links remain usable on mobile', async ({ page, request }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/classic/ru/');
  await expect(page.locator('.classicFooter')).toContainText(`MapKluss Classic ${packageInfo.version}`);
  const support = page.locator('a[href="https://boosty.to/klussforge"]');
  await expect(support).toContainText('Поддержать MapKluss');
  await expect(support).toHaveAttribute('rel', 'noopener noreferrer');
  await expect(page.getByRole('link', { name: 'Поддержать автора MapartCraft' })).toHaveAttribute('href', 'https://rebane2001.com/mapartcraft/supporters');
  await page.locator('.classicFooter').scrollIntoViewIfNeeded();
  expect(await page.locator('#materialtable tr').first().locator('th').nth(1).evaluate(cell => parseFloat(getComputedStyle(cell).paddingInlineStart))).toBeGreaterThanOrEqual(16);
  await page.screenshot({ path: 'test-results/classic-license-mobile.png' });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  for (const resource of ['LICENSE.txt', 'THIRD-PARTY-NOTICES.txt', 'mapkluss-classic-source.zip']) {
    expect((await request.get(`/classic/${resource}`)).ok()).toBe(true);
  }
  const zip = await JSZip.loadAsync(await (await request.get('/classic/mapkluss-classic-source.zip')).body());
  expect(Object.keys(zip.files).some(name => /(^|\/)(\.env[^/]*|.*\.(pem|key|p12))$/i.test(name))).toBe(false);
  if (process.env.CLASSIC_EXPECT_CLOUD_SOURCE === '1') {
    for (const file of ['src/classicCloudBridge.ts', 'src/lib/companionCloud.ts', 'package-lock.json', 'LICENSE', 'README.md', 'classic-cloud.vite.config.mjs']) {
      expect(zip.file(`mapkluss-cloud-bridge/${file}`), file).not.toBeNull();
    }
  }
  expect(errors).toEqual([]);
});

function parseNBT(bytes) {
  const raw = gunzipSync(bytes);
  const reader = new NBTReader();
  reader.loadBuffer(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength));
  return reader.getData().value;
}

function litematicPalette(bytes) {
  const regions = parseNBT(bytes).Regions.value;
  return Object.values(regions)[0].value.BlockStatePalette.value.value.map(entry => entry.Name.value);
}

async function download(page, name) {
  const event = page.waitForEvent('download');
  await page.getByRole('button', { name, exact: true }).click();
  const result = await event;
  return { bytes: await readFile(await result.path()), name: result.suggestedFilename() };
}

test('upload, palette, NBT, split ZIP, map.dat, source archive and responsive layout', async ({ page, request }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  page.on('response', response => { if (response.status() >= 400) errors.push(`${response.status()} ${response.url()}`); });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto('/classic/ru');
  await page.waitForLoadState('networkidle');
  await expect(page.getByRole('heading', { name: 'MapKluss Classic', exact: true, level: 1 })).toBeVisible();
  await expect(page.locator('.mapCanvas')).toBeVisible();
  await page.locator('#presets').selectOption({ label: 'Все блоки' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  await expect.poll(() => page.locator('.mapCanvas').evaluate(canvas => {
    const data = canvas.getContext('2d').getImageData(0, 0, 128, 128).data;
    return new Set(Array.from({length: data.length / 4}, (_, i) => `${data[i*4]},${data[i*4+1]},${data[i*4+2]}`)).size;
  })).toBeGreaterThan(30);
  const joined = await download(page, 'СКАЧАТЬ');
  expect(joined.name).toMatch(/\.nbt$/);
  const nbt = parseNBT(joined.bytes);
  expect(nbt.size.value.value[0]).toBe(128);
  expect(nbt.size.value.value[2]).toBe(129);
  expect(nbt.blocks.value.value.length).toBeGreaterThan(16384);
  await page.mouse.move(10, 10);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.screenshot({ path: 'test-results/classic-desktop.png' });

  await page.locator('.settingsAndDownloads input[type=number]').nth(0).fill('2');
  await page.locator('.settingsAndDownloads input[type=number]').nth(0).blur();
  await expect(page.locator('.mapCanvas')).toHaveAttribute('width', '256');
  const split = await download(page, 'СКАЧАТЬ УЧАСТОК 1х1 .ZIP');
  const zip = await JSZip.loadAsync(split.bytes);
  const entries = Object.values(zip.files).filter(file => !file.dir);
  expect(entries).toHaveLength(2);
  for (const entry of entries) expect(parseNBT(await entry.async('nodebuffer')).size.value.value[0]).toBe(128);

  await page.getByRole('button', { name: 'ПОСМОТРЕТЬ ОНЛАЙН', exact: true }).click();
  await expect(page.locator('.viewOnline2DContainer canvas')).toBeVisible();
  await page.screenshot({ path: 'test-results/classic-online.png' });
  // Return through a full reload to also verify locale routing and cookie scope.
  await page.reload();
  await page.locator('#presets').selectOption({ label: 'Все блоки' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  await page.getByLabel('Режим', { exact: true }).selectOption({ label: 'Datafile (map.dat)' });
  const dat = await download(page, 'СКАЧАТЬ');
  expect(dat.name).toMatch(/\.dat$/);
  expect(parseNBT(dat.bytes).data.value.colors.value).toHaveLength(16384);

  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: 'test-results/classic-mobile.png' });
  await page.locator('.settingsAndDownloads').scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'test-results/classic-mobile-settings.png' });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  const sourceResponse = await request.get('/classic/mapkluss-classic-source.zip');
  expect(sourceResponse.ok()).toBe(true);
  const source = await JSZip.loadAsync(await sourceResponse.body());
  expect(source.file('mapkluss-classic/LICENSE')).not.toBeNull();
  expect(source.file('mapkluss-classic/package-lock.json')).not.toBeNull();
  expect(source.file('mapkluss-classic/scripts/package-source.mjs')).not.toBeNull();
  expect(errors).toEqual([]);
});

test('direct language and FAQ routes', async ({ page }) => {
  for (const url of ['/classic', '/classic/', '/classic/ru', '/classic/ru/', '/classic/es/', '/classic/ru/faq', '/classic/ru/faq/']) {
    await page.goto(url);
    await expect(page.locator('h1')).toBeVisible();
    expect(await page.title()).toBe('MapKluss Classic');
  }
});

test('oversized input and unsafe support blocks are rejected before export', async ({ page }) => {
  await page.goto('/classic/ru/');
  const size = page.locator('.settingsAndDownloads input[type=number]').first();
  await size.fill('17');
  await size.blur();
  await expect(size).toHaveValue('1');
  await expect(page.locator('.mapCanvas')).toHaveAttribute('width', '128');
  await page.locator('input[type=file]').setInputFiles({
    name: 'large.png', mimeType: 'image/png', buffer: Buffer.alloc(10 * 1024 * 1024 + 1),
  });
  await expect(page.getByRole('alert')).toContainText('10 МБ');
  await page.locator('#presets').selectOption({ label: 'Все блоки' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  await page.locator('#classicBuildTechnique').selectOption('suppression_two_layer');
  await page.locator('.blockToAddSuggestions').locator('xpath=preceding-sibling::input[1]').fill('lava');
  await page.getByRole('button', { name: 'Скачать Two-layer ZIP' }).click();
  await expect(page.getByRole('alert')).toContainText('безопасный временный блок');
});

test('preview fits its own column and MapKluss Two-layer exports a Companion bundle', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto('/classic/ru/');
  await page.getByLabel('Смешивание', { exact: true }).selectOption({ label: 'Без смешения' });
  await page.locator('#presets').selectOption({ label: 'Все блоки' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  const surface = page.locator('.previewSurface');
  await expect.poll(async () => {
    const { width } = await surface.boundingBox();
    const viewport = await page.locator('.previewViewport').boundingBox();
    return Math.round(width - viewport.width);
  }).toBe(0);

  const before = await page.locator('.mapCanvas').evaluate(canvas => canvas.toDataURL());
  await page.getByLabel('Смешивание', { exact: true }).selectOption({ label: 'Blue Noise' });
  await expect.poll(() => page.locator('.mapCanvas').evaluate(canvas => canvas.toDataURL())).not.toBe(before);
  await page.locator('#classicBuildTechnique').selectOption('suppression_two_layer');
  const button = page.getByRole('button', { name: 'Скачать Two-layer ZIP' });
  await expect(button).toBeEnabled();
  await page.screenshot({ path: 'test-results/classic-two-layer-desktop.png' });
  page.once('dialog', dialog => dialog.accept());
  const file = await download(page, 'Скачать Two-layer ZIP');
  expect(file.name).toMatch(/_1x1_two_layer\.zip$/);
  const zip = await JSZip.loadAsync(file.bytes);
  const planEntry = Object.values(zip.files).find(entry => entry.name.endsWith('_suppression_plan.json'));
  const schematicEntry = Object.values(zip.files).find(entry => entry.name.endsWith('_suppression.litematic'));
  expect(planEntry).toBeTruthy();
  expect(schematicEntry).toBeTruthy();
  const plan = JSON.parse(await planEntry.async('text'));
  expect(plan.schema).toBe('mapkluss.suppression-plan');
  expect(plan.method).toBe('two_layer');
  expect(plan.target.minecraftVersion).toBe('1.21.4');
  expect(Buffer.from(plan.targetMapBytesB64, 'base64')).toHaveLength(128 * 128);
  expect(plan.materials.totalBlocks).toBeGreaterThan(128 * 128);
  expect(litematicPalette(await schematicEntry.async('nodebuffer')).length).toBeGreaterThan(10);
  expect(gunzipSync(await schematicEntry.async('nodebuffer')).length).toBeGreaterThan(1000);
  expect(errors).toEqual([]);

  await page.setViewportSize({ width: 390, height: 844 });
  await surface.scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'test-results/classic-two-layer-mobile.png' });
  await expect.poll(async () => {
    const { width } = await surface.boundingBox();
    const viewport = await page.locator('.previewViewport').boundingBox();
    return Math.round(width - viewport.width);
  }).toBe(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test('preview zoom resizes document layout without clipping or changing map pixels', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto('/classic/ru/');
  await page.locator('#presets').selectOption({ label: 'Все блоки' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  await expect(page.getByRole('button', { name: 'СКАЧАТЬ', exact: true })).toBeEnabled();
  const canvas = page.locator('.mapCanvas');
  await expect.poll(() => canvas.evaluate(node => {
    const data = node.getContext('2d').getImageData(0, 0, 128, 128).data;
    return new Set(Array.from({ length: data.length / 4 }, (_, i) => `${data[i * 4]},${data[i * 4 + 1]},${data[i * 4 + 2]}`)).size;
  })).toBeGreaterThan(30);
  const originalPixels = await canvas.evaluate(node => node.toDataURL());
  expect((await canvas.boundingBox()).width).toBeCloseTo(256, 1);
  for (let i = 0; i < 8; i++) await page.locator('.previewZoomButton').first().click();
  const zoomedWidth = 256 * 1.2 ** 8;
  expect((await canvas.boundingBox()).width).toBeCloseTo(zoomedWidth, 1);
  expect(await canvas.evaluate((node, original) => node.toDataURL() === original, originalPixels)).toBe(true);
  await expect(canvas).toHaveAttribute('width', '128');
  await expect(page.locator('.previewViewport')).toHaveCSS('overflow-x', 'visible');
  const preview = await page.locator('.mapPreviewDiv').boundingBox();
  const controls = await page.locator('.mapResolutionAndZoom').boundingBox();
  expect(controls.width).toBeCloseTo(preview.width, 1);
  await page.locator('.mapPreviewDiv').scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'test-results/classic-page-zoom-desktop.png' });
  await page.locator('.previewZoomButton').last().click();
  expect((await canvas.boundingBox()).width).toBeCloseTo(zoomedWidth / 1.2, 1);

  await page.getByRole('spinbutton').first().fill('2');
  await page.getByRole('spinbutton').first().blur();
  await expect(canvas).toHaveAttribute('width', '256');
  expect((await canvas.boundingBox()).width).toBeCloseTo(zoomedWidth / 1.2 * 2, 1);
  await page.locator('.settingsDiv input[type=checkbox]').first().check();
  await expect(page.locator('.gridOverlay')).toHaveCSS('background-size', '50% 100%');
  expect((await page.locator('.gridOverlay').boundingBox()).width).toBeCloseTo((await canvas.boundingBox()).width, 1);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.locator('.mapPreviewDiv').scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'test-results/classic-page-zoom-mobile.png' });
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeGreaterThan(390);
  await expect(page.locator('.previewViewport')).toHaveCSS('overflow-x', 'visible');
  const imageBounds = await canvas.boundingBox();
  const settingsBounds = await page.locator('.settingsAndDownloads').boundingBox();
  expect(settingsBounds.y >= imageBounds.y + imageBounds.height || settingsBounds.x >= imageBounds.x + imageBounds.width).toBe(true);
  await page.reload();
  for (let i = 0; i < 8; i++) await page.locator('.previewZoomButton').last().click();
  const smallPreview = await page.locator('.mapPreviewDiv').boundingBox();
  const smallCanvas = await canvas.boundingBox();
  const smallControls = await page.locator('.mapResolutionAndZoom').boundingBox();
  expect(smallCanvas.width).toBeLessThan(100);
  expect(smallPreview.width).toBeGreaterThan(smallCanvas.width);
  expect(smallControls.width).toBeCloseTo(smallPreview.width, 1);
  for (const summary of await page.locator('.settingsDiv summary').all()) await summary.click();
  await page.locator('.settingsAndDownloads').scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'test-results/classic-expanded-settings-mobile.png' });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  expect(errors).toEqual([]);
});

test('MapKluss 2D and 3D use their own Litematic engine, including tiled export', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  page.on('dialog', dialog => dialog.accept());
  await page.goto('/classic/ru/');
  await page.locator('#presets').selectOption({ label: 'Все блоки' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  await page.locator('#classicBuildTechnique').selectOption('mapkluss_2d');
  const flat = page.getByRole('button', { name: 'Скачать MapKluss 2D' });
  await expect(flat).toBeEnabled();
  const flatFile = await download(page, 'Скачать MapKluss 2D');
  expect(flatFile.name).toMatch(/_2d\.litematic$/);
  expect(gunzipSync(flatFile.bytes).length).toBeGreaterThan(1000);
  expect(litematicPalette(flatFile.bytes).length).toBeGreaterThan(10);

  await page.locator('#classicBuildTechnique').selectOption('mapkluss_3d');
  await page.getByRole('spinbutton').first().fill('2');
  await page.getByRole('spinbutton').first().press('Tab');
  const staircase = page.getByRole('button', { name: 'Скачать MapKluss 3D' });
  await expect(staircase).toBeEnabled();
  const tiledFile = await download(page, 'Скачать MapKluss 3D');
  expect(tiledFile.name).toMatch(/_2x1_3d\.zip$/);
  const tiledZip = await JSZip.loadAsync(tiledFile.bytes);
  const litematics = Object.values(tiledZip.files).filter(entry => entry.name.endsWith('.litematic'));
  expect(litematics).toHaveLength(2);
  for (const tile of litematics) expect(litematicPalette(await tile.async('nodebuffer')).length).toBeGreaterThan(10);

  await page.locator('#classicBuildTechnique').selectOption('suppression_two_layer');
  await expect(page.getByRole('button', { name: 'Скачать Two-layer ZIP' })).toBeEnabled();
  const twoLayerFile = await download(page, 'Скачать Two-layer ZIP');
  const twoLayerZip = await JSZip.loadAsync(twoLayerFile.bytes);
  const manifestEntry = twoLayerZip.file('SHA256.json');
  expect(manifestEntry).toBeTruthy();
  const manifest = JSON.parse(await manifestEntry.async('text'));
  expect(manifest.tiles).toHaveLength(2);
  expect(Object.values(twoLayerZip.files).filter(entry => entry.name.endsWith('_suppression.litematic'))).toHaveLength(2);
  expect(errors).toEqual([]);
});

test('preset sharing stays on Classic and survives reload', async ({ page, context }) => {
  await page.goto('/classic/ru/');
  await page.locator('#presets').selectOption({ label: 'Оттенки серого' });
  page.once('dialog', dialog => dialog.accept('QA grayscale'));
  await page.getByRole('button', { name: 'Сохранить', exact: true }).click();
  await page.reload();
  await page.locator('#presets').selectOption('QA grayscale');
  let shareUrl;
  page.once('dialog', async dialog => { shareUrl = dialog.defaultValue(); await dialog.dismiss(); });
  await page.getByRole('button', { name: 'Поделиться', exact: true }).click();
  await expect.poll(() => shareUrl).toContain('/classic/ru/?preset=');
  const selection = await page.locator('input[type=radio]:checked').evaluateAll(items => items.map(item => [item.name, item.value]));
  await page.goto(shareUrl);
  expect(await page.locator('input[type=radio]:checked').evaluateAll(items => items.map(item => [item.name, item.value]))).toEqual(selection);
  expect((await context.cookies()).filter(cookie => cookie.name.startsWith('mapartcraft_')).every(cookie => cookie.path === '/classic')).toBe(true);
});

test('3D online viewer renders and moves', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('/classic/ru/');
  await page.locator('#presets').selectOption({ label: 'Все блоки' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  await page.getByRole('button', { name: 'ПОСМОТРЕТЬ ОНЛАЙН', exact: true }).click();
  await page.getByRole('heading', { name: '3D', exact: true }).click();
  const canvas = page.locator('canvas').last();
  await expect(canvas).toBeVisible();
  // Screenshot capture synchronizes with the WebGL compositor.
  const before = await canvas.screenshot({ path: 'test-results/classic-3d.png' });
  const uniqueColors = await page.evaluate(async dataUrl => {
    const image = new Image(); image.src = dataUrl; await image.decode();
    const sample = document.createElement('canvas'); sample.width = image.width; sample.height = image.height;
    const ctx = sample.getContext('2d'); ctx.drawImage(image, 0, 0);
    const data = ctx.getImageData(0, 0, sample.width, sample.height).data;
    const colors = new Set();
    for (let i = 0; i < data.length; i += 16) colors.add(`${data[i]},${data[i+1]},${data[i+2]}`);
    return colors.size;
  }, `data:image/png;base64,${before.toString('base64')}`);
  expect(uniqueColors).toBeGreaterThan(50);
  await canvas.click({ position: { x: 100, y: 100 } });
  await page.keyboard.down('w');
  await page.waitForTimeout(500);
  await page.keyboard.up('w');
  const after = await canvas.screenshot({ path: 'test-results/classic-3d-moved.png' });
  expect(after.equals(before)).toBe(false);
  expect(errors).toEqual([]);
});
