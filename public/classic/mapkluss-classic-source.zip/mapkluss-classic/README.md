# MapKluss Classic

An independently built, GPLv3-licensed fork of MapartCraft by rebane2001 and
contributors. Upstream source and credits are preserved in UPSTREAM-README.md.
Upstream revision: 0f24df5d7a913f978bdd4738de95bc11461d497e.

## Build and run

Node.js 22.12+ and npm are required. Run `npm ci`, then `npm run dev`.
Open http://127.0.0.1:5300/classic/ru for Russian or /classic/ for English.
Run `npm run build` to generate dist, including the corresponding source ZIP,
GPL license, third-party notices and per-language/FAQ static entry points.
Deploy the entire dist directory at /classic/. Never omit the source archive.
The old build.sh/buildSources scripts are upstream historical references, not
the build process for this fork. `npm test` runs browser regression tests.

## MapKluss modifications

- Vite replaces Create React App; JSX source extensions renamed accordingly.
- Standalone /classic/ route, branded title/navigation/footer and MapKluss styling.
- Self-hosted Play and Tektur fonts and original block textures; no brushes.
- Preview starts at two CSS pixels per map pixel, with MapartCraft's 20% zoom
  steps. The canvas resizes page content and panels wrap naturally; oversized
  previews scroll with the document rather than inside a nested viewport.
- MapKluss color matching and all eight MapKluss dithering modes replace the
  Classic pixel quantizer. MapKluss 2D/3D Litematic and Two-layer Companion ZIP
  are selectable beside the original NBT and map.dat exports.
- Two-layer validates block safety, previews safe color choices and confirms
  any block substitutions before download.
- On the MapKluss site, the Classic account panel uses the shared account and
  same-origin Cloud bridge to save converted MapKluss 2D/3D/Two-layer art as a
  private, editable one-layer project. Standalone builds use an offline stub.
- Image and grid limits, plus version-aware support-block validation, prevent
  oversized or unsafe exports.
- Preset share URLs stay on the fork; cookies are scoped to /classic.
- Corrected one duplicated comma in the upstream Spanish locale JSON.
- Build includes complete application source, dependency lock and license notices.

Original authors retain their copyrights. MapKluss modifications copyright 2026
SmetankaKluss. This fork is distributed under GPL-3.0-only, without warranty.
See LICENSE. Third-party assets retain their respective licenses and ownership.
The ported MapKluss processing and export modules retain their MIT notice in
public/licenses/MapKluss-MIT.txt.
