import { test, expect } from '@playwright/test';

test('main site links open standalone Classic on desktop and mobile', async ({ page }) => {
  test.skip(!process.env.CLASSIC_SITE_URL, 'Requires the independently built main site.');
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(process.env.CLASSIC_SITE_URL);
  await expect(page.locator('.classic-editor-link')).toBeVisible();
  await page.screenshot({ path: 'test-results/site-desktop.png' });
  const desktopPopup = page.waitForEvent('popup');
  await page.locator('.classic-editor-link').click();
  const classic = await desktopPopup;
  await expect(classic.getByRole('heading', { name: 'MapKluss Classic', exact: true, level: 1 })).toBeVisible();
  await classic.close();
  await page.setViewportSize({ width: 390, height: 844 });
  const link = page.locator('.header-titles .classic-editor-link');
  await expect(link).toBeVisible();
  await page.screenshot({ path: 'test-results/site-mobile.png', animations: 'disabled' });
  const mobilePopup = page.waitForEvent('popup');
  await link.click();
  const classicMobile = await mobilePopup;
  await expect(classicMobile.getByRole('heading', { name: 'MapKluss Classic', exact: true, level: 1 })).toBeVisible();
  await classicMobile.close();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  expect(errors).toEqual([]);
});

test('Classic Cloud uses the shared account and saves the converted map', async ({ page }) => {
  test.skip(!process.env.CLASSIC_SITE_URL, 'Requires the integrated main site.');
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.route('**/classic-cloud-api.js', route => route.fulfill({
    contentType: 'text/javascript',
    body: `window.MapKlussClassicCloud = {
      getClassicCloudAccount: async () => ({ userId: 'test-user', email: 'builder@example.test' }),
      saveClassicToCloud: async input => { window.__classicCloudSaved = input; return '11111111-1111-4111-8111-111111111111'; }
    };`,
  }));
  await page.goto('/classic/ru/');
  await page.getByRole('button', { name: 'Проверить' }).click();
  await expect(page.locator('.classicCloudAccount')).toContainText('builder@example.test');
  await page.locator('#presets').selectOption({ label: 'Коврики' });
  await page.locator('input[type=file]').setInputFiles('tests/fixtures/starry-night.webp');
  await page.locator('#classicBuildTechnique').selectOption('mapkluss_2d');
  await page.getByLabel('Blue Noise scale', { exact: true }).selectOption('2');
  await expect(page.getByRole('button', { name: 'Сохранить арт в облако' })).toBeEnabled();
  await page.getByRole('button', { name: 'Сохранить арт в облако' }).click();
  await expect(page.locator('.classicCloudMessage')).toContainText('Сохранено в облаке');
  expect(await page.evaluate(() => ({
    grid: window.__classicCloudSaved.grid,
    pixels: window.__classicCloudSaved.pixels.length,
    selection: Object.values(window.__classicCloudSaved.blockSelection).some(row => row.length > 0),
    technique: window.__classicCloudSaved.buildTechnique,
    bnScale: window.__classicCloudSaved.bnScale,
  }))).toEqual({ grid: { wide: 1, tall: 1 }, pixels: 128 * 128 * 4, selection: true, technique: 'standard', bnScale: 2 });
  await expect(page.locator('.classicCloudLibrary')).toHaveAttribute('href', '/?art=11111111-1111-4111-8111-111111111111');
  expect(errors).toEqual([]);
});

test('integrated Cloud bridge initializes its callable API', async ({ page, request }) => {
  test.skip(!process.env.CLASSIC_SITE_URL, 'Requires the integrated main site.');
  const response = await request.get('/classic-cloud-api.js');
  expect(response.ok()).toBe(true);
  expect(await response.text()).toContain('MapKlussClassicCloud');
  await page.goto('/classic/ru/');
  await page.getByRole('button', { name: 'Проверить' }).click();
  await expect(page.locator('.classicCloudAccount')).not.toContainText('Проверка аккаунта');
  expect(await page.evaluate(() => [
    typeof window.MapKlussClassicCloud?.getClassicCloudAccount,
    typeof window.MapKlussClassicCloud?.saveClassicToCloud,
  ])).toEqual(['function', 'function']);
});

test('Classic guest stays lightweight until Cloud is requested', async ({ page }) => {
  test.skip(!process.env.CLASSIC_SITE_URL, 'Requires the integrated main site.');
  const cloudRequests = [];
  page.on('request', request => {
    if (request.url().includes('classic-cloud-api.js')) cloudRequests.push(request.url());
  });
  await page.goto('/classic/ru/');
  await expect(page.locator('.classicCloudAccount')).toContainText('Вход не выполнен');
  expect(cloudRequests).toEqual([]);
});
