import { test, expect } from '@playwright/test';
import { CLASSIC_THEMES, CLASSIC_THEME_STORAGE_KEY } from '../src/classicThemes.js';

function contrast(first, second) {
  const luminance = value => {
    const rgb = value.match(/[\d.]+/g).slice(0, 3).map(channel => {
      const normalized = Number(channel) / 255;
      return normalized <= 0.04045 ? normalized / 12.92 : ((normalized + 0.055) / 1.055) ** 2.4;
    });
    return rgb[0] * 0.2126 + rgb[1] * 0.7152 + rgb[2] * 0.0722;
  };
  const values = [luminance(first), luminance(second)].sort((a, b) => b - a);
  return (values[0] + 0.05) / (values[1] + 0.05);
}

for (const width of [1440, 390]) {
  test(`Classic themes stay readable and persist at ${width}px`, async ({ page }) => {
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
    await page.setViewportSize({ width, height: 1000 });
    await page.goto('/classic/ru/');
    const selector = page.getByRole('combobox', { name: 'Тема', exact: true });
    await expect(selector).toBeVisible();
    for (const theme of CLASSIC_THEMES) {
      await selector.selectOption(theme.id);
      await expect(page.locator('html')).toHaveAttribute('data-classic-theme', theme.id);
      const styles = await page.evaluate(() => {
        const root = getComputedStyle(document.documentElement);
        const body = getComputedStyle(document.body);
        const link = getComputedStyle(document.querySelector('.classicCloudSignIn'));
        const field = getComputedStyle(document.querySelector('.classicThemeSelector select'));
        const hint = getComputedStyle(document.querySelector('.classicCloudAccount span'));
        return { bg: root.backgroundColor, text: body.color, linkText: link.color, linkBg: link.backgroundColor, fieldText: field.color, fieldBg: field.backgroundColor, muted: hint.color };
      });
      for (const [foreground, background] of [[styles.text, styles.bg], [styles.linkText, styles.linkBg], [styles.fieldText, styles.fieldBg], [styles.muted, styles.bg]]) {
        expect(contrast(foreground, background), `${theme.id}: ${foreground} on ${background}`).toBeGreaterThanOrEqual(4.5);
      }
      await page.locator('.classicCloudSignIn').hover();
      const hover = await page.locator('.classicCloudSignIn').evaluate(node => ({ color: getComputedStyle(node).color, bg: getComputedStyle(node).backgroundColor }));
      expect(contrast(hover.color, hover.bg)).toBeGreaterThanOrEqual(4.5);
      await page.mouse.move(0, 0);
      await selector.scrollIntoViewIfNeeded();
      const bounds = await selector.boundingBox();
      expect(bounds.x).toBeGreaterThanOrEqual(0);
      expect(bounds.x + bounds.width).toBeLessThanOrEqual(width);
    }
    await page.reload();
    await expect(selector).toHaveValue('rose-oxide');
    expect(await page.evaluate(key => localStorage.getItem(key), CLASSIC_THEME_STORAGE_KEY)).toBe('rose-oxide');
    await selector.selectOption('signal-white');
    await page.screenshot({ path: `test-results/classic-theme-light-${width}.png`, fullPage: true });
    await selector.selectOption('classic');
    await page.screenshot({ path: `test-results/classic-theme-dark-${width}.png`, fullPage: true });
    expect(errors).toEqual([]);
  });
}

test('Classic inherits a supported host theme without changing the host preference', async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem('mapkluss_ui_theme', 'cobalt-print'));
  await page.goto('/classic/');
  const selector = page.getByRole('combobox', { name: 'Theme', exact: true });
  await expect(selector).toHaveValue('cobalt-print');
  await selector.selectOption('signal-white');
  expect(await page.evaluate(() => localStorage.getItem('mapkluss_ui_theme'))).toBe('cobalt-print');
});

test('Classic theme selection works when storage is unavailable', async ({ page }) => {
  await page.addInitScript(() => Object.defineProperty(window, 'localStorage', { get() { throw new Error('Storage blocked'); } }));
  await page.goto('/classic/');
  const selector = page.getByRole('combobox', { name: 'Theme', exact: true });
  await expect(selector).toHaveValue('classic');
  await selector.selectOption('signal-white');
  await expect(page.locator('html')).toHaveAttribute('data-classic-theme', 'signal-white');
});
