import React, { Component } from "react";

import BlockImage from "../blockImage";

import "./autoCompleteInputBlockToAdd.css";

class AutoCompleteInputBlockToAdd extends Component {
  state = { suggestionSelected: true, mapklussNames: [], namesVersion: null };

  componentDidUpdate(prevProps) {
    if (prevProps.mapklussVersion !== this.props.mapklussVersion && this.props.mapklussVersion) {
      this.loadMapklussNames(this.props.mapklussVersion);
    }
  }

  loadMapklussNames = async (version) => {
    try {
      const { availableClassicSupportBlocks } = await import('../../../classicSupportBlock');
      if (this.props.mapklussVersion === version) {
        this.setState({ mapklussNames: availableClassicSupportBlocks(version), namesVersion: version });
      }
    } catch {
      this.setState({ mapklussNames: [], namesVersion: null });
    }
  };

  getRelevantSuggestions = () => {
    const { coloursJSON, value, optionValue_version, mapklussVersion } = this.props;
    if (mapklussVersion) {
      return (this.state.namesVersion === mapklussVersion ? this.state.mapklussNames : [])
        .filter(name => name.includes(value))
        .slice(0, 30)
        .map(blockName => ({ blockName }));
    }
    let suggestions_prefix = [];
    let suggestions_includes = [];

    for (const [colourSetId, colourSet] of Object.entries(coloursJSON)) {
      for (const [blockId, block] of Object.entries(colourSet.blocks)) {
        if (!(optionValue_version.MCVersion in block.validVersions)) {
          continue;
        }
        let blockNBTData = block.validVersions[optionValue_version.MCVersion];
        if (typeof blockNBTData === "string") {
          // this is of the form eg "&1.12.2"
          blockNBTData = block.validVersions[blockNBTData.slice(1)];
        }
        if (!block.supportBlockMandatory) {
          // no gravity affected blocks etc for support / noobline
          if (blockNBTData.NBTName.startsWith(value)) {
            suggestions_prefix.push({
              blockName: blockNBTData.NBTName,
              colourSetId,
              blockId,
            });
          } else if (blockNBTData.NBTName.includes(value)) {
            suggestions_includes.push({
              blockName: blockNBTData.NBTName,
              colourSetId,
              blockId,
            });
          }
        }
      }
    }
    return suggestions_prefix.concat(suggestions_includes);
  };

  handleTextChange = (e) => {
    const newValue = e.target.value.replace(" ", "_").toLowerCase();
    this.props.setValue(newValue);
  };

  onSuggestionClicked = (suggestion) => {
    this.props.setValue(suggestion.blockName);
    this.setState({ suggestionSelected: true });
  };

  onFocus = () => {
    this.setState({ suggestionSelected: false });
    if (this.props.mapklussVersion && this.state.namesVersion !== this.props.mapklussVersion) {
      this.loadMapklussNames(this.props.mapklussVersion);
    }
  };

  render() {
    const { coloursJSON, value } = this.props;
    const { suggestionSelected } = this.state;

    const relevantSuggestions = this.getRelevantSuggestions();

    return (
      <React.Fragment>
        <input type="text" value={value} onChange={this.handleTextChange} onFocus={this.onFocus} onClick={this.onFocus} />
        <table className={"blockToAddSuggestions"} style={{ display: suggestionSelected || relevantSuggestions.length === 0 ? "none" : "table" }}>
          <tbody>
            {relevantSuggestions.map((suggestion) => (
              <tr
                className={"blockToAddSuggestion"}
                key={suggestion.blockName}
                onClick={() => this.onSuggestionClicked(suggestion)}
              >
                {suggestion.colourSetId !== undefined && <th>
                  <BlockImage coloursJSON={coloursJSON} colourSetId={suggestion.colourSetId} blockId={suggestion.blockId} />
                </th>}
                <th>{suggestion.blockName}</th>
              </tr>
            ))}
          </tbody>
        </table>
      </React.Fragment>
    );
  }
}

export default AutoCompleteInputBlockToAdd;
