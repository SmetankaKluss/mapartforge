# MapKluss Classic Design System

## Direction
A dense Minecraft map-art workspace, preserving the MapartCraft workflow.
Real block textures and generated previews are the primary visuals. No hero,
marketing sections, floating section cards or decorative illustrations.

## Tokens
- Background #111116; preview #09090d; controls #202027.
- Text #ededf1; muted #b8b8c4; divider #45454f; control border #565662.
- Accent #83ed95; action #81dda0; action hover #a0f2ba; progress #50b775.
- Action text #122519; return navigation and focus #c3b0ff.
- Local Play 15px/1.5 body; local Tektur headings, 26px brand / 22px narrow.
- Letter spacing 0; controls 3px radius; block images 2px radius.

## Layout and Controls
Unframed wrapping regions with 18px gaps, full page width, padding
20px 24px. At <=700px use 14px 12px padding and available-width regions.
Use MapartCraft's intrinsic preview size: 256 CSS pixels per map initially,
with 20% zoom steps. Zoom and map dimensions resize the page content; panels
wrap naturally and oversized previews use document scrolling, never a nested
preview scrollbar. The grid and zoom controls follow the whole canvas.
Preserve 32px texture-atlas geometry. Primary actions are 300px wide subject to available
width, minimum 38px tall, with upstream progress fill. Keyboard focus is a 2px
violet outline with 2px offset. See docs/classic-route.md for workflow placement.
