import { COLOUR_ROWS } from './mapklussCore/paletteBlocks';
import { isBlockAvailable } from './mapklussCore/versionPresets';
import type { MinecraftVersion } from './mapklussCore/versionPresets';
import { isBlockAvailableOnPlatform } from './mapklussCore/platformMode';
import { isSuppressionSafeBlockName } from './mapklussCore/suppressionPalette';

export function availableClassicSupportBlocks(version: MinecraftVersion): string[] {
  const names = new Set<string>();
  for (const row of COLOUR_ROWS) {
    for (const block of row.blocks) {
      if (!block.supportBlockMandatory
        && isSuppressionSafeBlockName(block.nbtName)
        && isBlockAvailable(block.nbtName, version)
        && isBlockAvailableOnPlatform(block.nbtName, 'java')) {
        names.add(block.nbtName.replace(/^minecraft:/, ''));
      }
    }
  }
  return [...names].sort();
}

export function resolveClassicSupportBlock(value: string, version: MinecraftVersion): string | null {
  const normalized = value.trim().replace(/^minecraft:/, '');
  return availableClassicSupportBlocks(version).includes(normalized) ? normalized : null;
}
